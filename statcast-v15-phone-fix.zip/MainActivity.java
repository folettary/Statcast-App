package com.folettary.statcastcompare;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.LinearGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.Shader;
import android.graphics.drawable.GradientDrawable;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebView;
import android.widget.*;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.text.DecimalFormat;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class MainActivity extends Activity {
    private static final int STATCAST_START_YEAR = 2015;
    private static final int NAVY = Color.rgb(10, 23, 55);
    private static final int NAVY_2 = Color.rgb(21, 53, 97);
    private static final int TEAL = Color.rgb(13, 178, 163);
    private static final int TEAL_DARK = Color.rgb(0, 125, 115);
    private static final int SALMON = Color.rgb(255, 122, 107);
    private static final int AMBER = Color.rgb(255, 190, 89);
    private static final int BG = Color.rgb(242, 246, 251);
    private static final int INK = Color.rgb(22, 29, 43);
    private static final int MUTED = Color.rgb(94, 105, 124);
    private static final int LINE = Color.rgb(221, 229, 241);
    private static final int CARD = Color.WHITE;

    private final ExecutorService io = Executors.newFixedThreadPool(8);
    private final Handler main = new Handler(Looper.getMainLooper());
    private final Map<String, String> textCache = Collections.synchronizedMap(new HashMap<>());
    private final Map<String, Bitmap> imageCache = Collections.synchronizedMap(new HashMap<>());
    private final Map<String, ArrayList<BitmapCallback>> imageWaiters = Collections.synchronizedMap(new HashMap<>());
    private final Map<Integer, ArrayList<LeaderboardEntry>> leaderboardCache = Collections.synchronizedMap(new HashMap<>());
    private final Map<Integer, ArrayList<LeaderboardEntry>> pitchingLeaderboardCache = Collections.synchronizedMap(new HashMap<>());

    private LinearLayout root;
    private LinearLayout form;
    private Button playerModeButton;
    private Button teamModeButton;
    private Button singleViewButton;
    private Button headToHeadButton;
    private Button expectedViewButton;
    private EditText searchInput;
    private ListView suggestionsList;
    private Spinner teamSpinner;
    private TextView compareSelectorLabel;
    private EditText compareSearchInput;
    private ListView compareSuggestionsList;
    private Spinner compareTeamSpinner;
    private LinearLayout comparePreviewBox;
    private Spinner seasonSpinner;
    private Spinner rankMetricSpinner;
    private Button metricPickerButton;
    private LinearLayout selectedPreviewBox;
    private Button compareButton;
    private Button standingsButton;
    private ProgressBar loading;
    private TextView statusView;
    private TextView errorView;
    private LinearLayout filterBox;
    private LinearLayout resultsBox;
    private LinearLayout headerBox;
    private LinearLayout metricBox;
    private LinearLayout standingsBox;
    private Button copyButton;
    private final ArrayList<Metric> rankMetrics = new ArrayList<>();

    private final ArrayList<Player> allPlayers = new ArrayList<>();
    private final ArrayList<Player> filteredPlayers = new ArrayList<>();
    private final ArrayList<Player> filteredComparePlayers = new ArrayList<>();
    private final ArrayList<Team> allTeams = new ArrayList<>();
    private PlayerSuggestionAdapter suggestionsAdapter;
    private PlayerSuggestionAdapter compareSuggestionsAdapter;
    private ArrayAdapter<String> teamAdapter;
    private ArrayAdapter<String> compareTeamAdapter;
    private Player selectedPlayer;
    private Player comparePlayer;
    private Team selectedTeam;
    private Team compareTeam;
    private boolean teamMode = false;
    private boolean headToHeadMode = false;
    private boolean expectedMode = false;
    private Comparison lastComparison;
    private HeadToHeadComparison lastHeadToHead;
    private String lastStandingsText = "";
    private boolean rankingsModeActive = false;

    private final LinkedHashSet<String> selectedMetricKeys = new LinkedHashSet<>();
    private final Map<String, CheckBox> metricChecks = new LinkedHashMap<>();
    private boolean updatingMetricChecks = false;

    private final Metric[] metrics = new Metric[] {
            // Hitter standard stats
            new Metric("avg", "AVG", "", 3, true, "standard", "Standard Hitting", "hit"),
            new Metric("obp", "OBP", "", 3, true, "standard", "Standard Hitting", "hit"),
            new Metric("slg", "SLG", "", 3, true, "standard", "Standard Hitting", "hit"),
            new Metric("ops", "OPS", "", 3, true, "standard", "Standard Hitting", "hit"),
            new Metric("hr", "HR", "", 0, true, "count", "Standard Hitting", "hit"),
            new Metric("rbi", "RBI", "", 0, true, "count", "Standard Hitting", "hit"),
            new Metric("r", "Runs", "", 0, true, "count", "Standard Hitting", "hit"),
            new Metric("sb", "SB", "", 0, true, "count", "Standard Hitting", "hit"),

            // Hitter Statcast stats
            new Metric("wOBA", "wOBA", "", 3, true, "expected", "Statcast Hitting", "hit"),
            new Metric("xwOBA", "xwOBA", "", 3, true, "expected", "Statcast Hitting", "hit"),
            new Metric("luck", "Luck", "", 3, true, "luck", "Statcast Hitting", "hit"),
            new Metric("xBA", "xBA", "", 3, true, "expected", "Statcast Hitting", "hit"),
            new Metric("xSLG", "xSLG", "", 3, true, "expected", "Statcast Hitting", "hit"),
            new Metric("avgEV", "Avg EV", " mph", 1, true, "contact", "Contact Quality", "hit"),
            new Metric("avgLA", "Launch Angle", "°", 1, null, "contact", "Contact Quality", "hit"),
            new Metric("hardHitPct", "Hard-Hit %", "%", 1, true, "rate", "Contact Quality", "hit"),
            new Metric("barrelPct", "Barrel %", "%", 1, true, "rate", "Contact Quality", "hit"),
            new Metric("sweetSpotPct", "Sweet-Spot %", "%", 1, true, "rate", "Contact Quality", "hit"),
            new Metric("kPct", "K %", "%", 1, false, "rate", "Plate Discipline", "hit"),
            new Metric("bbPct", "BB %", "%", 1, true, "rate", "Plate Discipline", "hit"),

            // Pitching standard stats
            new Metric("era", "ERA", "", 2, false, "pitching", "Standard Pitching", "pitch"),
            new Metric("whip", "WHIP", "", 2, false, "pitching", "Standard Pitching", "pitch"),
            new Metric("k9", "K/9", "", 1, true, "pitching", "Standard Pitching", "pitch"),
            new Metric("bb9", "BB/9", "", 1, false, "pitching", "Standard Pitching", "pitch"),
            new Metric("kbb", "K/BB", "", 2, true, "pitching", "Standard Pitching", "pitch"),
            new Metric("pitchK", "SO", "", 0, true, "count", "Standard Pitching", "pitch"),
            new Metric("pitchBB", "BB", "", 0, false, "count", "Standard Pitching", "pitch"),
            new Metric("saves", "SV", "", 0, true, "count", "Standard Pitching", "pitch"),
            new Metric("ip", "IP", "", 1, true, "pitching", "Standard Pitching", "pitch")
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        selectedMetricKeys.addAll(metricKeysForPreset("core"));
        buildUi();
        loadTeamsAndPlayers();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(12), dp(14), dp(28));
        scroll.addView(root, new ScrollView.LayoutParams(-1, -2));
        setContentView(scroll);

        LinearLayout appBar = new LinearLayout(this);
        appBar.setOrientation(LinearLayout.HORIZONTAL);
        appBar.setGravity(Gravity.CENTER_VERTICAL);
        appBar.setPadding(dp(14), dp(12), dp(14), dp(12));
        appBar.setBackground(roundedGradient(new int[] { Color.rgb(7, 20, 46), Color.rgb(14, 54, 92), Color.rgb(0, 112, 110) }, 22));
        appBar.setElevation(dp(4));
        root.addView(appBar, matchWrap());

        TextView monogram = text("SC", 16, Color.WHITE, true);
        monogram.setGravity(Gravity.CENTER);
        monogram.setLetterSpacing(0.08f);
        monogram.setBackground(roundedStroke(Color.argb(34, 255, 255, 255), Color.argb(90, 255, 255, 255), 18, 1));
        LinearLayout.LayoutParams monoLp = new LinearLayout.LayoutParams(dp(44), dp(44));
        monoLp.setMargins(0, 0, dp(11), 0);
        appBar.addView(monogram, monoLp);

        LinearLayout titleColApp = new LinearLayout(this);
        titleColApp.setOrientation(LinearLayout.VERTICAL);
        appBar.addView(titleColApp, new LinearLayout.LayoutParams(0, -2, 1));
        TextView title = text("Statcast Compare", 23, Color.WHITE, true);
        title.setLetterSpacing(0.01f);
        titleColApp.addView(title);
        TextView subtitle = text("Standard + Statcast · hitters, pitchers, teams, rankings", 12, Color.rgb(217, 230, 245), false);
        subtitle.setPadding(0, dp(2), 0, 0);
        titleColApp.addView(subtitle);

        LinearLayout badgeStack = new LinearLayout(this);
        badgeStack.setOrientation(LinearLayout.VERTICAL);
        badgeStack.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        TextView liveBadge = text("LIVE", 11, Color.WHITE, true);
        liveBadge.setGravity(Gravity.CENTER);
        liveBadge.setPadding(dp(9), dp(5), dp(9), dp(5));
        liveBadge.setLetterSpacing(0.12f);
        liveBadge.setBackground(roundedStroke(Color.argb(40, 255, 255, 255), Color.argb(92, 255, 255, 255), 14, 1));
        badgeStack.addView(liveBadge);
        TextView versionBadge = text("v15", 11, Color.rgb(213, 238, 236), true);
        versionBadge.setGravity(Gravity.CENTER);
        versionBadge.setPadding(0, dp(3), 0, 0);
        badgeStack.addView(versionBadge);
        appBar.addView(badgeStack);

        form = verticalCard(26, null);
        form.setPadding(dp(13), dp(13), dp(13), dp(13));
        LinearLayout.LayoutParams formLp = matchWrap();
        formLp.setMargins(0, dp(12), 0, 0);
        root.addView(form, formLp);

        LinearLayout commandHeader = new LinearLayout(this);
        commandHeader.setOrientation(LinearLayout.HORIZONTAL);
        commandHeader.setGravity(Gravity.CENTER_VERTICAL);
        form.addView(commandHeader, matchWrap());
        LinearLayout commandText = new LinearLayout(this);
        commandText.setOrientation(LinearLayout.VERTICAL);
        commandHeader.addView(commandText, new LinearLayout.LayoutParams(0, -2, 1));
        commandText.addView(text("Start here", 18, INK, true));
        commandText.addView(text("1 Pick player/team · 2 Choose profile or rankings · 3 Switch stats anytime", 12, MUTED, false));

        metricPickerButton = compactControlButton("Stats", false);
        commandHeader.addView(metricPickerButton, new LinearLayout.LayoutParams(dp(128), dp(40)));
        updateMetricPickerLabel();

        LinearLayout modeShell = new LinearLayout(this);
        modeShell.setOrientation(LinearLayout.HORIZONTAL);
        modeShell.setPadding(dp(4), dp(4), dp(4), dp(4));
        modeShell.setBackground(rounded(Color.rgb(238, 243, 249), 18));
        LinearLayout.LayoutParams modeShellLp = matchWrap();
        modeShellLp.setMargins(0, dp(12), 0, dp(10));
        form.addView(modeShell, modeShellLp);
        playerModeButton = pillButton("Player", true);
        teamModeButton = pillButton("Team", false);
        modeShell.addView(playerModeButton, weightLp());
        modeShell.addView(teamModeButton, weightLp());

        LinearLayout viewShell = new LinearLayout(this);
        viewShell.setOrientation(LinearLayout.HORIZONTAL);
        viewShell.setPadding(dp(4), dp(4), dp(4), dp(4));
        viewShell.setBackground(rounded(Color.rgb(238, 243, 249), 18));
        LinearLayout.LayoutParams viewShellLp = matchWrap();
        viewShellLp.setMargins(0, 0, 0, dp(10));
        form.addView(viewShell, viewShellLp);
        singleViewButton = pillButton("Profile", true);
        headToHeadButton = pillButton("Compare", false);
        expectedViewButton = pillButton("Actual vs xStats", false);
        viewShell.addView(singleViewButton, weightLp());
        viewShell.addView(headToHeadButton, weightLp());
        viewShell.addView(expectedViewButton, weightLp());

        TextView searchLabel = sectionEyebrow("1 · PICK WHO TO ANALYZE");
        form.addView(searchLabel);

        searchInput = new EditText(this);
        searchInput.setHint("Search player — Soto, Judge, Ohtani, Skenes…");
        searchInput.setSingleLine(true);
        searchInput.setTextSize(16);
        searchInput.setTextColor(INK);
        searchInput.setHintTextColor(Color.rgb(124, 135, 153));
        searchInput.setPadding(dp(14), dp(11), dp(14), dp(11));
        searchInput.setBackground(roundedStroke(Color.WHITE, Color.rgb(202, 215, 232), 18, 1));
        LinearLayout.LayoutParams inputLp = matchWrap();
        inputLp.setMargins(0, dp(6), 0, dp(8));
        form.addView(searchInput, inputLp);

        suggestionsList = new ListView(this);
        suggestionsAdapter = new PlayerSuggestionAdapter(filteredPlayers);
        suggestionsList.setAdapter(suggestionsAdapter);
        suggestionsList.setVisibility(View.GONE);
        suggestionsList.setDividerHeight(1);
        suggestionsList.setBackground(roundedStroke(Color.WHITE, Color.rgb(226, 233, 243), 16, 1));
        form.addView(suggestionsList, new LinearLayout.LayoutParams(-1, dp(154)));

        teamSpinner = new Spinner(this);
        teamAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, new ArrayList<>());
        teamSpinner.setAdapter(teamAdapter);
        teamSpinner.setVisibility(View.GONE);
        teamSpinner.setBackground(roundedStroke(Color.WHITE, Color.rgb(202, 215, 232), 18, 1));
        teamSpinner.setPadding(dp(10), dp(8), dp(10), dp(8));
        LinearLayout.LayoutParams teamLp = matchWrap();
        teamLp.setMargins(0, dp(6), 0, dp(8));
        form.addView(teamSpinner, teamLp);

        selectedPreviewBox = new LinearLayout(this);
        selectedPreviewBox.setOrientation(LinearLayout.HORIZONTAL);
        selectedPreviewBox.setGravity(Gravity.CENTER_VERTICAL);
        selectedPreviewBox.setPadding(dp(9), dp(9), dp(9), dp(9));
        selectedPreviewBox.setVisibility(View.GONE);
        selectedPreviewBox.setBackground(roundedGradient(new int[] { Color.rgb(249, 252, 255), Color.rgb(239, 248, 249) }, 18));
        LinearLayout.LayoutParams previewLp = matchWrap();
        previewLp.setMargins(0, dp(2), 0, dp(10));
        form.addView(selectedPreviewBox, previewLp);

        compareSelectorLabel = sectionEyebrow("2 · PICK WHO TO COMPARE AGAINST");
        compareSelectorLabel.setVisibility(View.GONE);
        form.addView(compareSelectorLabel);

        compareSearchInput = new EditText(this);
        compareSearchInput.setHint("Search second player…");
        compareSearchInput.setSingleLine(true);
        compareSearchInput.setTextSize(16);
        compareSearchInput.setTextColor(INK);
        compareSearchInput.setHintTextColor(Color.rgb(124, 135, 153));
        compareSearchInput.setPadding(dp(14), dp(11), dp(14), dp(11));
        compareSearchInput.setBackground(roundedStroke(Color.WHITE, Color.rgb(202, 215, 232), 18, 1));
        compareSearchInput.setVisibility(View.GONE);
        LinearLayout.LayoutParams compareInputLp = matchWrap();
        compareInputLp.setMargins(0, dp(6), 0, dp(8));
        form.addView(compareSearchInput, compareInputLp);

        compareSuggestionsList = new ListView(this);
        compareSuggestionsAdapter = new PlayerSuggestionAdapter(filteredComparePlayers);
        compareSuggestionsList.setAdapter(compareSuggestionsAdapter);
        compareSuggestionsList.setVisibility(View.GONE);
        compareSuggestionsList.setDividerHeight(1);
        compareSuggestionsList.setBackground(roundedStroke(Color.WHITE, Color.rgb(226, 233, 243), 16, 1));
        form.addView(compareSuggestionsList, new LinearLayout.LayoutParams(-1, dp(154)));

        compareTeamSpinner = new Spinner(this);
        compareTeamAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, new ArrayList<>());
        compareTeamSpinner.setAdapter(compareTeamAdapter);
        compareTeamSpinner.setVisibility(View.GONE);
        compareTeamSpinner.setBackground(roundedStroke(Color.WHITE, Color.rgb(202, 215, 232), 18, 1));
        compareTeamSpinner.setPadding(dp(10), dp(8), dp(10), dp(8));
        LinearLayout.LayoutParams compareTeamLp = matchWrap();
        compareTeamLp.setMargins(0, dp(6), 0, dp(8));
        form.addView(compareTeamSpinner, compareTeamLp);

        comparePreviewBox = new LinearLayout(this);
        comparePreviewBox.setOrientation(LinearLayout.HORIZONTAL);
        comparePreviewBox.setGravity(Gravity.CENTER_VERTICAL);
        comparePreviewBox.setPadding(dp(9), dp(9), dp(9), dp(9));
        comparePreviewBox.setVisibility(View.GONE);
        comparePreviewBox.setBackground(roundedGradient(new int[] { Color.rgb(249, 252, 255), Color.rgb(239, 248, 249) }, 18));
        LinearLayout.LayoutParams comparePreviewLp = matchWrap();
        comparePreviewLp.setMargins(0, dp(2), 0, dp(10));
        form.addView(comparePreviewBox, comparePreviewLp);

        LinearLayout controlsCard = new LinearLayout(this);
        controlsCard.setOrientation(LinearLayout.VERTICAL);
        controlsCard.setPadding(dp(10), dp(10), dp(10), dp(10));
        controlsCard.setBackground(roundedStroke(Color.rgb(248, 251, 254), Color.rgb(227, 234, 244), 20, 1));
        LinearLayout.LayoutParams controlsLp = matchWrap();
        controlsLp.setMargins(0, dp(3), 0, 0);
        form.addView(controlsCard, controlsLp);

        LinearLayout seasonRankRow = new LinearLayout(this);
        seasonRankRow.setOrientation(LinearLayout.HORIZONTAL);
        controlsCard.addView(seasonRankRow, matchWrap());
        LinearLayout seasonCol = new LinearLayout(this);
        seasonCol.setOrientation(LinearLayout.VERTICAL);
        seasonCol.addView(sectionEyebrow("SEASON"));
        seasonSpinner = new Spinner(this);
        ArrayList<String> years = new ArrayList<>();
        int currentYear = Calendar.getInstance().get(Calendar.YEAR);
        for (int y = currentYear; y >= STATCAST_START_YEAR; y--) years.add(String.valueOf(y));
        ArrayAdapter<String> yearAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, years);
        seasonSpinner.setAdapter(yearAdapter);
        seasonSpinner.setBackground(roundedStroke(Color.WHITE, Color.rgb(213, 223, 236), 14, 1));
        seasonCol.addView(seasonSpinner, matchWrap());

        LinearLayout rankCol = new LinearLayout(this);
        rankCol.setOrientation(LinearLayout.VERTICAL);
        rankCol.addView(sectionEyebrow("RANKINGS VIEW"));
        rankMetricSpinner = new Spinner(this);
        rebuildRankMetricSpinner();
        rankMetricSpinner.setBackground(roundedStroke(Color.WHITE, Color.rgb(213, 223, 236), 14, 1));
        rankCol.addView(rankMetricSpinner, matchWrap());
        seasonRankRow.addView(seasonCol, weightLp());
        seasonRankRow.addView(rankCol, weightLp());

        LinearLayout actionRow = new LinearLayout(this);
        actionRow.setOrientation(LinearLayout.HORIZONTAL);
        actionRow.setPadding(0, dp(8), 0, 0);
        compareButton = primaryActionButton("Profile");
        LinearLayout.LayoutParams btnLp = new LinearLayout.LayoutParams(0, dp(50), 1);
        btnLp.setMargins(0, 0, dp(5), 0);
        actionRow.addView(compareButton, btnLp);

        standingsButton = secondaryActionButton("Rankings");
        LinearLayout.LayoutParams stLp = new LinearLayout.LayoutParams(0, dp(50), 1);
        stLp.setMargins(dp(5), 0, 0, 0);
        actionRow.addView(standingsButton, stLp);
        controlsCard.addView(actionRow, matchWrap());

        statusView = text("Loading MLB teams and active players…", 12, MUTED, false);
        statusView.setPadding(dp(2), dp(9), dp(2), 0);
        form.addView(statusView);

        filterBox = new LinearLayout(this);
        filterBox.setOrientation(LinearLayout.VERTICAL);
        filterBox.setVisibility(View.GONE);

        loading = new ProgressBar(this);
        loading.setVisibility(View.GONE);
        LinearLayout.LayoutParams loadLp = new LinearLayout.LayoutParams(dp(38), dp(38));
        loadLp.gravity = Gravity.CENTER_HORIZONTAL;
        loadLp.setMargins(0, dp(10), 0, 0);
        form.addView(loading, loadLp);

        errorView = text("", 14, Color.rgb(180, 54, 70), false);
        errorView.setPadding(dp(2), dp(10), dp(2), 0);
        errorView.setVisibility(View.GONE);
        form.addView(errorView);

        resultsBox = new LinearLayout(this);
        resultsBox.setOrientation(LinearLayout.VERTICAL);
        resultsBox.setVisibility(View.GONE);
        LinearLayout.LayoutParams resultsLp = matchWrap();
        resultsLp.setMargins(0, dp(12), 0, 0);
        root.addView(resultsBox, resultsLp);

        headerBox = new LinearLayout(this);
        headerBox.setOrientation(LinearLayout.VERTICAL);
        resultsBox.addView(headerBox, matchWrap());

        copyButton = compactControlButton("Copy table", false);
        copyButton.setVisibility(View.GONE);

        metricBox = new LinearLayout(this);
        metricBox.setOrientation(LinearLayout.VERTICAL);
        resultsBox.addView(metricBox, matchWrap());

        standingsBox = new LinearLayout(this);
        standingsBox.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams standingsLp = matchWrap();
        standingsLp.setMargins(0, dp(14), 0, 0);
        root.addView(standingsBox, standingsLp);

        TextView notes = text("Tip: Profile and Rankings are separate views. Pick a player/team, then use Profile for comparison bars or Rankings for leaderboards and selected-player ranks across all stats.", 10, Color.rgb(112, 123, 142), false);
        notes.setGravity(Gravity.CENTER);
        notes.setLineSpacing(dp(2), 1.0f);
        notes.setPadding(dp(8), dp(12), dp(8), 0);
        root.addView(notes);

        wireEvents();
    }


    private TextView heroPill(String label) {
        TextView tv = text(label, 12, Color.WHITE, true);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(dp(8), dp(9), dp(8), dp(9));
        tv.setBackground(roundedStroke(Color.argb(38, 255, 255, 255), Color.argb(80, 255, 255, 255), 16, 1));
        return tv;
    }

    private Button pillButton(String label, boolean active) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextSize(14);
        b.setMinHeight(0);
        b.setMinWidth(0);
        b.setPadding(dp(6), dp(8), dp(6), dp(8));
        b.setTextColor(active ? Color.WHITE : Color.rgb(71, 83, 105));
        b.setBackground(active ? roundedGradient(new int[] { NAVY, Color.rgb(24, 62, 109) }, 15) : rounded(Color.TRANSPARENT, 15));
        return b;
    }

    private TextView sectionEyebrow(String value) {
        TextView tv = text(value, 10, Color.rgb(112, 123, 142), true);
        tv.setLetterSpacing(0.12f);
        tv.setPadding(dp(2), dp(2), dp(2), dp(2));
        return tv;
    }

    private Button compactControlButton(String label, boolean active) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextSize(12);
        b.setMinHeight(0);
        b.setMinWidth(0);
        b.setPadding(dp(8), dp(6), dp(8), dp(6));
        b.setTextColor(active ? Color.WHITE : NAVY);
        b.setBackground(active ? rounded(TEAL_DARK, 14) : roundedStroke(Color.WHITE, Color.rgb(213, 223, 236), 14, 1));
        return b;
    }

    private Button primaryActionButton(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextSize(15);
        b.setTextColor(Color.WHITE);
        b.setMinHeight(0);
        b.setMinWidth(0);
        b.setBackground(roundedGradient(new int[] { TEAL, TEAL_DARK }, 16));
        return b;
    }

    private Button secondaryActionButton(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextSize(15);
        b.setTextColor(NAVY);
        b.setMinHeight(0);
        b.setMinWidth(0);
        b.setBackground(roundedStroke(Color.WHITE, Color.rgb(197, 211, 228), 16, 1));
        return b;
    }

    private void updateViewModeButtons() {
        if (compareButton == null || standingsButton == null) return;
        compareButton.setText(expectedMode ? "Show actual vs expected" : (headToHeadMode ? "Compare side by side" : "Show profile"));
        standingsButton.setText("Rankings");
        if (rankingsModeActive) {
            compareButton.setTextColor(NAVY);
            compareButton.setBackground(roundedStroke(Color.WHITE, Color.rgb(197, 211, 228), 16, 1));
            standingsButton.setTextColor(Color.WHITE);
            standingsButton.setBackground(roundedGradient(new int[] { NAVY_2, TEAL_DARK }, 16));
        } else {
            compareButton.setTextColor(Color.WHITE);
            compareButton.setBackground(roundedGradient(new int[] { TEAL, TEAL_DARK }, 16));
            standingsButton.setTextColor(NAVY);
            standingsButton.setBackground(roundedStroke(Color.WHITE, Color.rgb(197, 211, 228), 16, 1));
        }
    }

    private void refreshRankingsIfActive() {
        if (rankingsModeActive && !isBusy()) showStandings();
    }

    private void openProfileForCurrentSelection() {
        if (isBusy()) return;
        rankingsModeActive = false;
        headToHeadMode = false;
        expectedMode = false;
        lastHeadToHead = null;
        updateAnalysisModeButtons();
        applyHeadToHeadVisibility();
        updateViewModeButtons();
        standingsBox.removeAllViews();
        showError(null);
        try {
            int season = Integer.parseInt((String) seasonSpinner.getSelectedItem());
            if (teamMode) {
                if (selectedTeam != null) compareTeam(selectedTeam, season);
            } else {
                if (selectedPlayer != null) comparePlayer(selectedPlayer, season);
            }
        } catch (Exception ignored) {}
    }


    private void updateMetricPickerLabel() {
        if (metricPickerButton == null) return;
        String preset = metricPresetName(selectedMetricKeys);
        metricPickerButton.setText("Stats: " + preset + " (" + selectedMetricKeys.size() + ")");
    }

    private String preferredMetricSide() {
        if (!teamMode && selectedPlayer != null && isPitcher(selectedPlayer)) return "pitch";
        if (teamMode && selectedMetricKeys.size() > 0) {
            int pitch = 0, hit = 0;
            for (Metric m : metrics) if (selectedMetricKeys.contains(m.key)) { if ("pitch".equals(m.side)) pitch++; else if ("hit".equals(m.side)) hit++; }
            if (pitch > hit) return "pitch";
        }
        return "hit";
    }

    private boolean isPitcher(Player p) {
        if (p == null || p.position == null) return false;
        String pos = p.position.toUpperCase(Locale.US);
        return pos.equals("P") || pos.equals("SP") || pos.equals("RP") || pos.contains("PITCH");
    }

    private ArrayList<Metric> metricsForCurrentContext() {
        String side = preferredMetricSide();
        ArrayList<Metric> list = new ArrayList<>();
        for (Metric m : metrics) if (m.side.equals(side) || m.side.equals("both")) list.add(m);
        return list;
    }

    private void rebuildRankMetricSpinner() {
        if (rankMetricSpinner == null) return;
        rankMetrics.clear();
        rankMetrics.addAll(metricsForCurrentContext());
        ArrayList<String> metricLabels = new ArrayList<>();
        metricLabels.add("All selected stats");
        for (Metric m : rankMetrics) metricLabels.add(m.label);
        ArrayAdapter<String> rankAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, metricLabels);
        rankMetricSpinner.setAdapter(rankAdapter);
        rankMetricSpinner.setSelection(0);
    }

    private Metric selectedRankMetric() {
        if (rankMetrics.isEmpty()) return metrics[0];
        int pos = rankMetricSpinner == null ? 0 : rankMetricSpinner.getSelectedItemPosition();
        if (pos <= 0) return null;
        return rankMetrics.get(Math.min(pos - 1, rankMetrics.size() - 1));
    }

    private ArrayList<Metric> selectedRankingMetrics() {
        ArrayList<Metric> out = new ArrayList<>();
        String side = preferredMetricSide();
        for (Metric m : metrics) {
            if (selectedMetricKeys.contains(m.key) && (m.side.equals(side) || m.side.equals("both") || teamMode)) out.add(m);
        }
        if (out.isEmpty()) out.addAll(metricsForCurrentContext());
        return out;
    }

    private void applySmartDefaultForSelection(Player p) {
        selectedMetricKeys.clear();
        selectedMetricKeys.addAll(metricKeysForPreset(isPitcher(p) ? "pitcherCore" : "hitterCore"));
        rebuildRankMetricSpinner();
        updateMetricPickerLabel();
        syncMetricChecks();
    }


    private String metricPresetName(Set<String> keys) {
        if (keys.equals(metricKeysForPreset("hitterCore"))) return "Hitter Core";
        if (keys.equals(metricKeysForPreset("pitcherCore"))) return "Pitcher Core";
        if (keys.equals(metricKeysForPreset("standard"))) return "Standard";
        if (keys.equals(metricKeysForPreset("statcast"))) return "Statcast";
        if (keys.equals(metricKeysForPreset("contact"))) return "Contact";
        if (keys.equals(metricKeysForPreset("discipline"))) return "Discipline";
        if (keys.equals(metricKeysForPreset("luck"))) return "Luck";
        if (keys.equals(metricKeysForPreset("all"))) return "All";
        return "Custom";
    }

    private LinkedHashSet<String> metricKeysForPreset(String preset) {
        LinkedHashSet<String> keys = new LinkedHashSet<>();
        String side = preferredMetricSide();
        for (Metric m : metrics) {
            boolean include;
            if ("hitterCore".equals(preset) || ("core".equals(preset) && "hit".equals(side))) include = m.key.equals("avg") || m.key.equals("obp") || m.key.equals("slg") || m.key.equals("ops") || m.key.equals("wOBA") || m.key.equals("xwOBA") || m.key.equals("luck") || m.key.equals("barrelPct");
            else if ("pitcherCore".equals(preset) || ("core".equals(preset) && "pitch".equals(side))) include = m.key.equals("era") || m.key.equals("whip") || m.key.equals("k9") || m.key.equals("bb9") || m.key.equals("kbb") || m.key.equals("ip");
            else if ("standard".equals(preset)) include = m.side.equals(side) && (m.group.startsWith("Standard") || m.type.equals("count") || m.type.equals("pitching"));
            else if ("statcast".equals(preset) || "expected".equals(preset)) include = m.side.equals("hit") && (m.group.startsWith("Statcast") || m.key.equals("luck"));
            else if ("contact".equals(preset)) include = m.side.equals("hit") && m.group.equals("Contact Quality");
            else if ("discipline".equals(preset)) include = m.side.equals("hit") && m.group.equals("Plate Discipline");
            else if ("luck".equals(preset)) include = m.key.equals("wOBA") || m.key.equals("xwOBA") || m.key.equals("luck");
            else if ("pitching".equals(preset)) include = m.side.equals("pitch");
            else if ("all".equals(preset)) include = m.side.equals(side);
            else include = false;
            if (include) keys.add(m.key);
        }
        return keys;
    }

    private void showMetricPicker() {
        final LinkedHashMap<String, CheckBox> boxes = new LinkedHashMap<>();
        LinearLayout shell = new LinearLayout(this);
        shell.setOrientation(LinearLayout.VERTICAL);
        shell.setPadding(dp(4), dp(2), dp(4), dp(2));

        String side = preferredMetricSide();
        TextView hint = text(("pitch".equals(side) ? "Pitching" : "Hitting") + " stats are shown based on the selected player/team. Use presets for the common views, or customize below.", 12, MUTED, false);
        hint.setPadding(0, 0, 0, dp(8));
        shell.addView(hint);
        ArrayList<Metric> pickerMetrics = teamMode ? new ArrayList<>(Arrays.asList(metrics)) : metricsForCurrentContext();

        LinearLayout row1 = new LinearLayout(this); row1.setOrientation(LinearLayout.HORIZONTAL); shell.addView(row1, matchWrap());
        LinearLayout row2 = new LinearLayout(this); row2.setOrientation(LinearLayout.HORIZONTAL); shell.addView(row2, matchWrap());
        row1.addView(dialogPresetChip("Recommended", () -> setDialogPreset(boxes, "core")), weightLp());
        row1.addView(dialogPresetChip("Standard", () -> setDialogPreset(boxes, "standard")), weightLp());
        row1.addView(dialogPresetChip("All", () -> setDialogPreset(boxes, "all")), weightLp());
        if (teamMode) {
            row2.addView(dialogPresetChip("Hitting", () -> setDialogPreset(boxes, "hitterCore")), weightLp());
            row2.addView(dialogPresetChip("Pitching", () -> setDialogPreset(boxes, "pitcherCore")), weightLp());
            row2.addView(dialogPresetChip("Statcast", () -> setDialogPreset(boxes, "statcast")), weightLp());
        } else if ("hit".equals(side)) {
            row2.addView(dialogPresetChip("Statcast", () -> setDialogPreset(boxes, "statcast")), weightLp());
            row2.addView(dialogPresetChip("Contact", () -> setDialogPreset(boxes, "contact")), weightLp());
            row2.addView(dialogPresetChip("Luck", () -> setDialogPreset(boxes, "luck")), weightLp());
        } else {
            row2.addView(dialogPresetChip("Pitching", () -> setDialogPreset(boxes, "pitching")), weightLp());
            row2.addView(dialogPresetChip("Run prevention", () -> setDialogPreset(boxes, "pitcherCore")), weightLp());
            row2.addView(new Space(this), weightLp());
        }

        String lastGroup = "";
        for (Metric m : pickerMetrics) {
            if (!m.group.equals(lastGroup)) {
                TextView sub = text(m.group, 12, MUTED, true);
                sub.setPadding(0, dp(10), 0, dp(3));
                shell.addView(sub);
                lastGroup = m.group;
            }
            CheckBox cb = new CheckBox(this);
            cb.setText(m.label);
            cb.setTextColor(INK);
            cb.setTextSize(14);
            cb.setButtonTintList(ColorStateList.valueOf(TEAL));
            cb.setPadding(dp(4), dp(2), dp(4), dp(2));
            cb.setChecked(selectedMetricKeys.contains(m.key));
            boxes.put(m.key, cb);
            shell.addView(cb, matchWrap());
        }

        ScrollView scroller = new ScrollView(this);
        scroller.addView(shell);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Stats shown")
                .setView(scroller)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Apply", (d, which) -> {
                    selectedMetricKeys.clear();
                    for (Metric m : pickerMetrics) {
                        CheckBox cb = boxes.get(m.key);
                        if (cb != null && cb.isChecked()) selectedMetricKeys.add(m.key);
                    }
                    rebuildRankMetricSpinner();
                    updateMetricPickerLabel();
                    syncMetricChecks();
                    refreshCurrentResults();
                    refreshRankingsIfActive();
                })
                .create();
        dialog.show();
    }

    private TextView dialogPresetChip(String label, Runnable action) {
        TextView tv = filterChip(label, action);
        tv.setTextSize(12);
        tv.setPadding(dp(6), dp(7), dp(6), dp(7));
        return tv;
    }

    private void setDialogPreset(Map<String, CheckBox> boxes, String preset) {
        Set<String> keys = metricKeysForPreset(preset);
        for (Map.Entry<String, CheckBox> e : boxes.entrySet()) e.getValue().setChecked(keys.contains(e.getKey()));
    }

    private void renderSelectionPreview() {
        if (selectedPreviewBox == null) return;
        selectedPreviewBox.removeAllViews();
        boolean hasSelection = teamMode ? selectedTeam != null : selectedPlayer != null;
        selectedPreviewBox.setVisibility(hasSelection ? View.VISIBLE : View.GONE);
        if (!hasSelection) return;

        TeamPalette palette = teamMode ? paletteForTeam(selectedTeam) : paletteForAbbr(selectedPlayer.teamAbbr);
        selectedPreviewBox.setBackground(roundedGradient(new int[] { palette.primary, palette.secondary }, 20));

        if (teamMode) {
            View logo = teamLogoView(selectedTeam, 46);
            LinearLayout.LayoutParams logoLp = new LinearLayout.LayoutParams(dp(46), dp(46));
            logoLp.setMargins(0, 0, dp(11), 0);
            selectedPreviewBox.addView(logo, logoLp);
            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);
            col.addView(text(selectedTeam.name, 16, Color.WHITE, true));
            col.addView(text("Team profile · " + selectedTeam.abbr, 11, Color.rgb(228, 238, 248), false));
            selectedPreviewBox.addView(col, new LinearLayout.LayoutParams(0, -2, 1));
            TextView hint = text("Ready", 11, Color.WHITE, true);
            hint.setGravity(Gravity.CENTER);
            hint.setPadding(dp(9), dp(5), dp(9), dp(5));
            hint.setBackground(roundedStroke(Color.argb(34, 255, 255, 255), Color.argb(80, 255, 255, 255), 14, 1));
            selectedPreviewBox.addView(hint);
        } else {
            ImageView img = new ImageView(this);
            img.setScaleType(ImageView.ScaleType.FIT_CENTER);
            img.setAdjustViewBounds(true);
            img.setBackground(roundedStroke(Color.WHITE, Color.argb(90, 255, 255, 255), 18, 1));
            img.setPadding(dp(2), dp(2), dp(2), dp(2));
            LinearLayout.LayoutParams imgLp = new LinearLayout.LayoutParams(dp(46), dp(46));
            imgLp.setMargins(0, 0, dp(11), 0);
            selectedPreviewBox.addView(img, imgLp);
            loadPlayerImage(selectedPlayer.id, img);
            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);
            col.addView(text(selectedPlayer.fullName, 16, Color.WHITE, true));
            col.addView(text(selectedPlayer.teamAbbr + " · " + selectedPlayer.position, 11, Color.rgb(228, 238, 248), false));
            selectedPreviewBox.addView(col, new LinearLayout.LayoutParams(0, -2, 1));
            TextView hint = text("Ready", 11, Color.WHITE, true);
            hint.setGravity(Gravity.CENTER);
            hint.setPadding(dp(9), dp(5), dp(9), dp(5));
            hint.setBackground(roundedStroke(Color.argb(34, 255, 255, 255), Color.argb(80, 255, 255, 255), 14, 1));
            selectedPreviewBox.addView(hint);
        }
    }

    private void buildMetricFilters() {
        filterBox.removeAllViews();

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.VERTICAL);
        top.addView(text("Stats shown", 13, MUTED, true));
        TextView hint = text("Tap a preset or pick individual stats. No sideways scrolling.", 12, MUTED, false);
        hint.setPadding(0, dp(2), 0, dp(6));
        top.addView(hint);
        filterBox.addView(top, matchWrap());

        LinearLayout presetRow1 = new LinearLayout(this);
        presetRow1.setOrientation(LinearLayout.HORIZONTAL);
        presetRow1.addView(filterChip("Recommended", () -> applyMetricPreset("core")), weightLp());
        presetRow1.addView(filterChip("Standard", () -> applyMetricPreset("standard")), weightLp());
        presetRow1.addView(filterChip("Contact", () -> applyMetricPreset("contact")), weightLp());
        filterBox.addView(presetRow1, matchWrap());

        LinearLayout presetRow2 = new LinearLayout(this);
        presetRow2.setOrientation(LinearLayout.HORIZONTAL);
        presetRow2.addView(filterChip("Discipline", () -> applyMetricPreset("discipline")), weightLp());
        presetRow2.addView(filterChip("Luck", () -> applyMetricPreset("luck")), weightLp());
        presetRow2.addView(filterChip("All", () -> applyMetricPreset("all")), weightLp());
        filterBox.addView(presetRow2, matchWrap());

        metricChecks.clear();
        TextView individual = text("Individual stats", 12, MUTED, true);
        individual.setPadding(0, dp(8), 0, dp(2));
        filterBox.addView(individual);

        ArrayList<Metric> contextMetrics = metricsForCurrentContext();
        for (int i = 0; i < contextMetrics.size(); i += 2) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.addView(metricCheckChip(contextMetrics.get(i)), weightLp());
            if (i + 1 < contextMetrics.size()) row.addView(metricCheckChip(contextMetrics.get(i + 1)), weightLp());
            else row.addView(new Space(this), weightLp());
            filterBox.addView(row, matchWrap());
        }
    }

    private TextView filterChip(String label, Runnable onClick) {
        TextView tv = text(label, 13, INK, true);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(dp(8), dp(9), dp(8), dp(9));
        tv.setBackground(roundedStroke(Color.WHITE, LINE, 16, 1));
        tv.setOnClickListener(v -> onClick.run());
        return tv;
    }

    private CheckBox metricCheckChip(Metric m) {
        CheckBox cb = new CheckBox(this);
        cb.setText(m.label);
        cb.setTextColor(INK);
        cb.setTextSize(13);
        cb.setTypeface(Typeface.DEFAULT_BOLD);
        cb.setChecked(selectedMetricKeys.contains(m.key));
        cb.setButtonTintList(ColorStateList.valueOf(TEAL));
        cb.setPadding(dp(8), dp(6), dp(8), dp(6));
        cb.setBackground(roundedStroke(Color.rgb(248, 250, 253), LINE, 14, 1));
        cb.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (updatingMetricChecks) return;
            if (isChecked) selectedMetricKeys.add(m.key); else selectedMetricKeys.remove(m.key);
            refreshCurrentResults();
        });
        metricChecks.put(m.key, cb);
        return cb;
    }

    private void applyMetricPreset(String preset) {
        selectedMetricKeys.clear();
        selectedMetricKeys.addAll(metricKeysForPreset(preset));
        rebuildRankMetricSpinner();
        syncMetricChecks();
        updateMetricPickerLabel();
        refreshCurrentResults();
        refreshRankingsIfActive();
    }

    private void syncMetricChecks() {
        updatingMetricChecks = true;
        for (Map.Entry<String, CheckBox> e : metricChecks.entrySet()) e.getValue().setChecked(selectedMetricKeys.contains(e.getKey()));
        updatingMetricChecks = false;
    }

    private void wireEvents() {
        playerModeButton.setOnClickListener(v -> setMode(false));
        teamModeButton.setOnClickListener(v -> setMode(true));
        singleViewButton.setOnClickListener(v -> setHeadToHeadMode(false));
        headToHeadButton.setOnClickListener(v -> setHeadToHeadMode(true));
        expectedViewButton.setOnClickListener(v -> setExpectedMode());

        searchInput.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { filterPlayers(s.toString()); }
            @Override public void afterTextChanged(Editable s) {}
        });

        compareSearchInput.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { filterComparePlayers(s.toString()); }
            @Override public void afterTextChanged(Editable s) {}
        });

        suggestionsList.setOnItemClickListener((parent, view, position, id) -> {
            if (position < filteredPlayers.size()) {
                selectedPlayer = filteredPlayers.get(position);
                searchInput.setText(selectedPlayer.fullName);
                searchInput.setSelection(searchInput.getText().length());
                suggestionsList.setVisibility(View.GONE);
                applySmartDefaultForSelection(selectedPlayer);
                statusView.setText(isPitcher(selectedPlayer) ? "Pitcher selected · opening profile." : "Hitter selected · opening profile.");
                renderSelectionPreview();
                hideKeyboard();
                openProfileForCurrentSelection();
            }
        });

        compareSuggestionsList.setOnItemClickListener((parent, view, position, id) -> {
            if (position < filteredComparePlayers.size()) {
                comparePlayer = filteredComparePlayers.get(position);
                compareSearchInput.setText(comparePlayer.fullName);
                compareSearchInput.setSelection(compareSearchInput.getText().length());
                compareSuggestionsList.setVisibility(View.GONE);
                statusView.setText("Second player selected. Tap Compare side by side.");
                renderComparePreview();
                hideKeyboard();
            }
        });

        teamSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position >= 0 && position < allTeams.size()) {
                    selectedTeam = allTeams.get(position);
                    if (teamMode) {
                        renderSelectionPreview();
                        statusView.setText("Team selected · opening profile.");
                        openProfileForCurrentSelection();
                    }
                }
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });

        compareTeamSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position >= 0 && position < allTeams.size()) {
                    compareTeam = allTeams.get(position);
                    if (teamMode && headToHeadMode) renderComparePreview();
                }
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });

        seasonSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) { refreshRankingsIfActive(); }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });

        rankMetricSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) { refreshRankingsIfActive(); }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });

        metricPickerButton.setOnClickListener(v -> showMetricPicker());
        compareButton.setOnClickListener(v -> compareSelected());
        standingsButton.setOnClickListener(v -> showStandings());
        copyButton.setOnClickListener(v -> copyCurrentTable());
    }

    private void setMode(boolean useTeamMode) {
        teamMode = useTeamMode;
        expectedMode = false;
        playerModeButton.setTextColor(teamMode ? NAVY : Color.WHITE);
        playerModeButton.setBackground(teamMode ? roundedStroke(Color.WHITE, LINE, 16, 1) : rounded(NAVY, 16));
        teamModeButton.setTextColor(teamMode ? Color.WHITE : NAVY);
        teamModeButton.setBackground(teamMode ? rounded(NAVY, 16) : roundedStroke(Color.WHITE, LINE, 16, 1));
        searchInput.setVisibility(teamMode ? View.GONE : View.VISIBLE);
        suggestionsList.setVisibility(View.GONE);
        teamSpinner.setVisibility(teamMode ? View.VISIBLE : View.GONE);
        applyHeadToHeadVisibility();
        selectedMetricKeys.clear();
        selectedMetricKeys.addAll(metricKeysForPreset(teamMode ? "hitterCore" : (selectedPlayer != null && isPitcher(selectedPlayer) ? "pitcherCore" : "hitterCore")));
        rebuildRankMetricSpinner();
        updateMetricPickerLabel();
        statusView.setText(statusTextForMode());
        renderSelectionPreview();
        renderComparePreview();
        rankingsModeActive = false;
        updateAnalysisModeButtons();
        updateViewModeButtons();
        resultsBox.setVisibility(View.GONE);
        standingsBox.removeAllViews();
    }

    private void setHeadToHeadMode(boolean useHeadToHead) {
        headToHeadMode = useHeadToHead;
        expectedMode = false;
        updateAnalysisModeButtons();
        applyHeadToHeadVisibility();
        updateViewModeButtons();
        statusView.setText(statusTextForMode());
        renderComparePreview();
        resultsBox.setVisibility(View.GONE);
        standingsBox.removeAllViews();
    }

    private void setExpectedMode() {
        headToHeadMode = false;
        expectedMode = true;
        updateAnalysisModeButtons();
        applyHeadToHeadVisibility();
        updateViewModeButtons();
        statusView.setText(statusTextForMode());
        renderComparePreview();
        resultsBox.setVisibility(View.GONE);
        standingsBox.removeAllViews();
    }

    private void updateAnalysisModeButtons() {
        if (singleViewButton == null || headToHeadButton == null) return;
        boolean profileActive = !headToHeadMode && !expectedMode;
        singleViewButton.setTextColor(profileActive ? Color.WHITE : NAVY);
        singleViewButton.setBackground(profileActive ? rounded(NAVY, 16) : roundedStroke(Color.WHITE, LINE, 16, 1));
        headToHeadButton.setTextColor(headToHeadMode ? Color.WHITE : NAVY);
        headToHeadButton.setBackground(headToHeadMode ? rounded(NAVY, 16) : roundedStroke(Color.WHITE, LINE, 16, 1));
        if (expectedViewButton != null) {
            expectedViewButton.setTextColor(expectedMode ? Color.WHITE : NAVY);
            expectedViewButton.setBackground(expectedMode ? rounded(NAVY, 16) : roundedStroke(Color.WHITE, LINE, 16, 1));
        }
    }

    private void applyHeadToHeadVisibility() {
        int show = headToHeadMode ? View.VISIBLE : View.GONE;
        if (compareSelectorLabel != null) compareSelectorLabel.setVisibility(show);
        if (compareSearchInput != null) compareSearchInput.setVisibility(headToHeadMode && !teamMode ? View.VISIBLE : View.GONE);
        if (compareTeamSpinner != null) compareTeamSpinner.setVisibility(headToHeadMode && teamMode ? View.VISIBLE : View.GONE);
        if (compareSuggestionsList != null) compareSuggestionsList.setVisibility(View.GONE);
        if (comparePreviewBox != null) comparePreviewBox.setVisibility(show);
    }

    private String statusTextForMode() {
        if (headToHeadMode) {
            return teamMode ? "Pick two teams, choose a season, then tap Compare side by side." : "Pick two players, choose a season, then tap Compare side by side.";
        }
        if (expectedMode) {
            return teamMode ? "Pick a team to compare actual stats vs expected stats." : (selectedPlayer == null ? "Search and select a player first." : "Player selected. Tap Show actual vs expected.");
        }
        return teamMode ? "Pick a team, then tap Show profile or Rankings." : (selectedPlayer == null ? "Search and select a player first." : "Player selected. Choose a season, then tap Show profile.");
    }

    private void loadTeamsAndPlayers() {
        setBusy(true, "Loading MLB teams and active players…");
        io.execute(() -> {
            try {
                LoadedData loaded = fetchTeamsAndActivePlayers();
                main.post(() -> {
                    allTeams.clear(); allTeams.addAll(loaded.teams);
                    allPlayers.clear(); allPlayers.addAll(loaded.players);
                    teamAdapter.clear();
                    compareTeamAdapter.clear();
                    for (Team t : allTeams) {
                        teamAdapter.add(t.name);
                        compareTeamAdapter.add(t.name);
                    }
                    teamAdapter.notifyDataSetChanged();
                    compareTeamAdapter.notifyDataSetChanged();
                    if (!allTeams.isEmpty()) selectedTeam = allTeams.get(0);
                    if (allTeams.size() > 1) compareTeam = allTeams.get(1); else if (!allTeams.isEmpty()) compareTeam = allTeams.get(0);
                    if (compareTeamSpinner != null && allTeams.size() > 1) compareTeamSpinner.setSelection(1);
                    statusView.setText("Ready · search a hitter/pitcher or pick a team");
                    renderSelectionPreview();
                    setBusy(false, null);
                });
            } catch (Exception e) {
                main.post(() -> {
                    setBusy(false, null);
                    showError("Could not load MLB team/player list. Check your connection and reopen the app. " + e.getMessage());
                    statusView.setText("Roster list unavailable.");
                });
            }
        });
    }

    private void filterPlayers(String raw) {
        if (teamMode) return;
        filteredPlayers.clear();
        String q = raw.trim().toLowerCase(Locale.US);
        if (q.length() < 2 || allPlayers.isEmpty()) {
            suggestionsList.setVisibility(View.GONE);
            suggestionsAdapter.notifyDataSetChanged();
            return;
        }
        for (Player p : allPlayers) {
            if (p.fullName.toLowerCase(Locale.US).contains(q) || p.teamAbbr.toLowerCase(Locale.US).contains(q) || p.position.toLowerCase(Locale.US).contains(q)) {
                filteredPlayers.add(p);
                if (filteredPlayers.size() >= 24) break;
            }
        }
        suggestionsAdapter.notifyDataSetChanged();
        suggestionsList.setVisibility(filteredPlayers.isEmpty() ? View.GONE : View.VISIBLE);
    }

    private void filterComparePlayers(String raw) {
        if (teamMode || !headToHeadMode) return;
        filteredComparePlayers.clear();
        String q = raw.trim().toLowerCase(Locale.US);
        if (q.length() < 2 || allPlayers.isEmpty()) {
            compareSuggestionsList.setVisibility(View.GONE);
            compareSuggestionsAdapter.notifyDataSetChanged();
            return;
        }
        for (Player p : allPlayers) {
            if (selectedPlayer != null && p.id == selectedPlayer.id) continue;
            if (p.fullName.toLowerCase(Locale.US).contains(q) || p.teamAbbr.toLowerCase(Locale.US).contains(q) || p.position.toLowerCase(Locale.US).contains(q)) {
                filteredComparePlayers.add(p);
                if (filteredComparePlayers.size() >= 24) break;
            }
        }
        compareSuggestionsAdapter.notifyDataSetChanged();
        compareSuggestionsList.setVisibility(filteredComparePlayers.isEmpty() ? View.GONE : View.VISIBLE);
    }

    private void renderComparePreview() {
        if (comparePreviewBox == null) return;
        comparePreviewBox.removeAllViews();
        boolean hasSelection = headToHeadMode && (teamMode ? compareTeam != null : comparePlayer != null);
        comparePreviewBox.setVisibility(hasSelection ? View.VISIBLE : View.GONE);
        if (!hasSelection) return;

        TeamPalette palette = teamMode ? paletteForTeam(compareTeam) : paletteForAbbr(comparePlayer.teamAbbr);
        comparePreviewBox.setBackground(roundedGradient(new int[] { softColor(palette.primary, 0.20f), palette.primary, palette.secondary }, 20));

        if (teamMode) {
            View logo = teamLogoView(compareTeam, 46);
            LinearLayout.LayoutParams logoLp = new LinearLayout.LayoutParams(dp(46), dp(46));
            logoLp.setMargins(0, 0, dp(11), 0);
            comparePreviewBox.addView(logo, logoLp);
            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);
            col.addView(text(compareTeam.name, 16, Color.WHITE, true));
            col.addView(text("Head-to-head opponent · " + compareTeam.abbr, 11, Color.rgb(228, 238, 248), false));
            comparePreviewBox.addView(col, new LinearLayout.LayoutParams(0, -2, 1));
        } else {
            ImageView img = new ImageView(this);
            img.setScaleType(ImageView.ScaleType.FIT_CENTER);
            img.setAdjustViewBounds(true);
            img.setBackground(roundedStroke(Color.WHITE, Color.argb(90, 255, 255, 255), 18, 1));
            img.setPadding(dp(2), dp(2), dp(2), dp(2));
            LinearLayout.LayoutParams imgLp = new LinearLayout.LayoutParams(dp(46), dp(46));
            imgLp.setMargins(0, 0, dp(11), 0);
            comparePreviewBox.addView(img, imgLp);
            loadPlayerImage(comparePlayer.id, img);
            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);
            col.addView(text(comparePlayer.fullName, 16, Color.WHITE, true));
            col.addView(text("Opponent · " + comparePlayer.teamAbbr + " · " + comparePlayer.position, 11, Color.rgb(228, 238, 248), false));
            comparePreviewBox.addView(col, new LinearLayout.LayoutParams(0, -2, 1));
        }
        TextView hint = text("VS", 11, Color.WHITE, true);
        hint.setGravity(Gravity.CENTER);
        hint.setPadding(dp(10), dp(5), dp(10), dp(5));
        hint.setBackground(roundedStroke(Color.argb(34, 255, 255, 255), Color.argb(80, 255, 255, 255), 14, 1));
        comparePreviewBox.addView(hint);
    }

    private void compareSelected() {
        hideKeyboard();
        showError(null);
        rankingsModeActive = false;
        updateViewModeButtons();
        standingsBox.removeAllViews();
        int season = Integer.parseInt((String) seasonSpinner.getSelectedItem());
        if (headToHeadMode) {
            compareSideBySideSelected(season);
            return;
        }
        lastHeadToHead = null;
        if (teamMode) {
            if (selectedTeam == null) { showError("Pick a team first."); return; }
            compareTeam(selectedTeam, season);
        } else {
            if (selectedPlayer == null) { showError("Pick a player from the search results first."); return; }
            comparePlayer(selectedPlayer, season);
        }
    }

    private void compareSideBySideSelected(int season) {
        if (teamMode) {
            if (selectedTeam == null || compareTeam == null) { showError("Pick two teams first."); return; }
            if (selectedTeam.key().equals(compareTeam.key())) { showError("Pick two different teams."); return; }
            compareTeamsSideBySide(selectedTeam, compareTeam, season);
        } else {
            if (selectedPlayer == null || comparePlayer == null) { showError("Pick two players first."); return; }
            if (selectedPlayer.id == comparePlayer.id) { showError("Pick two different players."); return; }
            comparePlayersSideBySide(selectedPlayer, comparePlayer, season);
        }
    }

    private void comparePlayer(Player player, int season) {
        setBusy(true, "Loading selected season…");
        io.execute(() -> {
            try {
                ArrayList<LeaderboardEntry> entries = fetchLeaderboardForPlayer(player, season);
                LeaderboardEntry seasonEntry = findPlayerEntry(entries, player);
                Stats seasonStats = seasonEntry == null ? new Stats() : seasonEntry.stats;
                Stats leagueStats = computeLeagueAverage(entries);
                ArrayList<Metric> displayed = selectedMetricsForRows();
                HashMap<String, Integer> ranks = computePlayerRankMap(entries, season, player.id, displayed);
                HashMap<String, Integer> totals = computePlayerRankTotalMap(entries, season, displayed);
                HashMap<String, Double> percentiles = percentileMap(ranks, totals);
                Stats pendingCareer = new Stats();
                Comparison quick = new Comparison(false, player.fullName, player.teamAbbr, player.position, player.id, season, seasonStats, pendingCareer, leagueStats, new Date(), "Career loading…", player, null, ranks, totals, percentiles, new HashMap<>());
                main.post(() -> {
                    lastComparison = quick;
                    if (expectedMode) renderExpectedComparison(quick); else renderComparison(quick);
                    setBusy(false, expectedMode ? "Actual + expected loaded. Career numbers are filling in…" : "Season + league loaded. Career numbers are filling in…");
                });

                Stats careerStats = fetchPlayerCareerStats(player, season);
                LinkedHashMap<Integer, Stats> recentSeasons = fetchPlayerRecentSeasonStats(player, season);
                HashMap<String, Double> careerPercentiles = valuePercentileMapForPlayerEntries(entries, season, careerStats, displayed);
                Comparison complete = new Comparison(false, player.fullName, player.teamAbbr, player.position, player.id, season, seasonStats, careerStats, leagueStats, new Date(), "Career", player, null, ranks, totals, percentiles, careerPercentiles, recentSeasons);
                main.post(() -> {
                    if (!teamMode && selectedPlayer != null && selectedPlayer.id == player.id && Integer.parseInt((String) seasonSpinner.getSelectedItem()) == season) {
                        lastComparison = complete;
                        if (expectedMode) renderExpectedComparison(complete); else renderComparison(complete);
                        statusView.setText(expectedMode ? "Complete · actual vs expected loaded" : "Complete · season, league, and career loaded");
                    }
                });
            } catch (Exception e) {
                main.post(() -> {
                    setBusy(false, null);
                    showError("Could not load player comparison. Baseball Savant may be slow/rate-limiting, or this player may have no leaderboard row for the selected season. " + e.getMessage());
                });
            }
        });
    }

    private void compareTeam(Team team, int season) {
        setBusy(true, "Loading selected season…");
        io.execute(() -> {
            try {
                ArrayList<LeaderboardEntry> entries = fetchLeaderboardForSelectedMetrics(season);
                Stats teamStats = aggregateTeamStats(entries).get(team.key());
                if (teamStats == null) teamStats = new Stats();
                Stats leagueStats = computeLeagueAverage(entries);
                ArrayList<Metric> displayed = selectedMetricsForRows();
                Map<String, Stats> teamStatsMap = aggregateTeamStats(entries);
                HashMap<String, Integer> ranks = computeTeamRankMap(teamStatsMap, team.key(), displayed);
                HashMap<String, Integer> totals = computeTeamRankTotalMap(teamStatsMap, displayed);
                HashMap<String, Double> percentiles = percentileMap(ranks, totals);
                Stats pendingHistory = new Stats();
                Comparison quick = new Comparison(true, team.name, team.abbr, "Team", 0, season, teamStats, pendingHistory, leagueStats, new Date(), "History loading…", null, team, ranks, totals, percentiles, new HashMap<>());
                main.post(() -> {
                    lastComparison = quick;
                    if (expectedMode) renderExpectedComparison(quick); else renderComparison(quick);
                    setBusy(false, expectedMode ? "Actual + expected loaded. Team history is filling in…" : "Season + league loaded. Team history is filling in…");
                });

                Stats historyStats = fetchTeamHistoryStats(team, season);
                LinkedHashMap<Integer, Stats> recentSeasons = fetchTeamRecentSeasonStats(team, season);
                HashMap<String, Double> historyPercentiles = valuePercentileMapForTeams(teamStatsMap, historyStats, displayed);
                Comparison complete = new Comparison(true, team.name, team.abbr, "Team", 0, season, teamStats, historyStats, leagueStats, new Date(), "2015–" + season + " team avg", null, team, ranks, totals, percentiles, historyPercentiles, recentSeasons);
                main.post(() -> {
                    if (teamMode && selectedTeam != null && selectedTeam.key().equals(team.key()) && Integer.parseInt((String) seasonSpinner.getSelectedItem()) == season) {
                        lastComparison = complete;
                        if (expectedMode) renderExpectedComparison(complete); else renderComparison(complete);
                        statusView.setText(expectedMode ? "Complete · actual vs expected loaded" : "Complete · season, league, and team history loaded");
                    }
                });
            } catch (Exception e) {
                main.post(() -> {
                    setBusy(false, null);
                    showError("Could not load team comparison. " + e.getMessage());
                });
            }
        });
    }

    private void comparePlayersSideBySide(Player a, Player b, int season) {
        setBusy(true, "Loading player side-by-side…");
        io.execute(() -> {
            try {
                ArrayList<LeaderboardEntry> entries = (isPitcher(a) || isPitcher(b)) ? fetchPitchingLeaderboard(season) : fetchLeaderboard(season);
                LeaderboardEntry entryA = findPlayerEntry(entries, a);
                LeaderboardEntry entryB = findPlayerEntry(entries, b);
                Stats statsA = entryA == null ? new Stats() : entryA.stats;
                Stats statsB = entryB == null ? new Stats() : entryB.stats;
                Stats leagueStats = computeLeagueAverage(entries);
                ArrayList<Metric> displayed = selectedMetricsForRows();
                HashMap<String, Integer> ranksA = computePlayerRankMap(entries, season, a.id, displayed);
                HashMap<String, Integer> ranksB = computePlayerRankMap(entries, season, b.id, displayed);
                HashMap<String, Integer> totals = computePlayerRankTotalMap(entries, season, displayed);
                HeadToHeadComparison h = new HeadToHeadComparison(false, a.fullName, b.fullName, a.teamAbbr + " · " + a.position, b.teamAbbr + " · " + b.position, a.id, b.id, season, statsA, statsB, leagueStats, a, b, null, null, ranksA, ranksB, totals, totals, percentileMap(ranksA, totals), percentileMap(ranksB, totals));
                main.post(() -> {
                    lastComparison = null;
                    lastHeadToHead = h;
                    renderHeadToHead(h);
                    setBusy(false, "Loaded side-by-side for " + season);
                });
            } catch (Exception e) {
                main.post(() -> {
                    setBusy(false, null);
                    showError("Could not load side-by-side player comparison. " + e.getMessage());
                });
            }
        });
    }

    private void compareTeamsSideBySide(Team a, Team b, int season) {
        setBusy(true, "Loading team side-by-side…");
        io.execute(() -> {
            try {
                ArrayList<LeaderboardEntry> entries = fetchLeaderboardForSelectedMetrics(season);
                Map<String, Stats> teams = aggregateTeamStats(entries);
                Stats statsA = teams.get(a.key()); if (statsA == null) statsA = new Stats();
                Stats statsB = teams.get(b.key()); if (statsB == null) statsB = new Stats();
                Stats leagueStats = computeLeagueAverage(entries);
                ArrayList<Metric> displayed = selectedMetricsForRows();
                HashMap<String, Integer> ranksA = computeTeamRankMap(teams, a.key(), displayed);
                HashMap<String, Integer> ranksB = computeTeamRankMap(teams, b.key(), displayed);
                HashMap<String, Integer> totals = computeTeamRankTotalMap(teams, displayed);
                HeadToHeadComparison h = new HeadToHeadComparison(true, a.name, b.name, a.abbr, b.abbr, 0, 0, season, statsA, statsB, leagueStats, null, null, a, b, ranksA, ranksB, totals, totals, percentileMap(ranksA, totals), percentileMap(ranksB, totals));
                main.post(() -> {
                    lastComparison = null;
                    lastHeadToHead = h;
                    renderHeadToHead(h);
                    setBusy(false, "Loaded side-by-side for " + season);
                });
            } catch (Exception e) {
                main.post(() -> {
                    setBusy(false, null);
                    showError("Could not load side-by-side team comparison. " + e.getMessage());
                });
            }
        });
    }

    private void showStandings() {
        hideKeyboard();
        showError(null);
        rankingsModeActive = true;
        updateViewModeButtons();
        resultsBox.setVisibility(View.GONE);
        int season = Integer.parseInt((String) seasonSpinner.getSelectedItem());
        Metric metric = selectedRankMetric();
        if (metric == null) {
            showAllSelectedRankings(season);
            return;
        }
        setBusy(true, "Loading " + (teamMode ? "team" : "player") + " rankings…");
        io.execute(() -> {
            try {
                ArrayList<LeaderboardEntry> entries = fetchLeaderboardForMetric(season, metric);
                if (teamMode) renderTeamStandingsAsync(entries, season, metric);
                else renderPlayerStandingsAsync(entries, season, metric);
            } catch (Exception e) {
                main.post(() -> {
                    setBusy(false, null);
                    showError("Could not load rankings. " + e.getMessage());
                });
            }
        });
    }

    private void showAllSelectedRankings(int season) {
        setBusy(true, "Loading rankings across selected stats…");
        io.execute(() -> {
            try {
                ArrayList<Metric> selected = selectedRankingMetrics();
                if (teamMode) renderTeamAllStatsRankingsAsync(season, selected);
                else renderPlayerAllStatsRankingsAsync(season, selected);
            } catch (Exception e) {
                main.post(() -> {
                    setBusy(false, null);
                    showError("Could not load all-stat rankings. " + e.getMessage());
                });
            }
        });
    }

    private void renderPlayerStandingsAsync(ArrayList<LeaderboardEntry> entries, int season, Metric metric) {
        ArrayList<LeaderboardEntry> eligible = eligiblePlayerEntries(entries, season, metric);
        main.post(() -> {
            renderPlayerStandings(eligible, season, metric);
            setBusy(false, null);
        });
    }

    private void renderTeamStandingsAsync(ArrayList<LeaderboardEntry> entries, int season, Metric metric) {
        Map<String, Stats> teamStats = aggregateTeamStats(entries);
        ArrayList<TeamStanding> teams = new ArrayList<>();
        for (Team t : allTeams) {
            Stats s = teamStats.get(t.key());
            if (s != null && s.get(metric.key) != null) teams.add(new TeamStanding(t, s));
        }
        teams.sort((a, b) -> compareMetricValues(a.stats.get(metric.key), b.stats.get(metric.key), metric));
        main.post(() -> {
            renderTeamStandings(teams, season, metric);
            setBusy(false, null);
        });
    }

    private ArrayList<LeaderboardEntry> eligiblePlayerEntries(ArrayList<LeaderboardEntry> entries, int season, Metric metric) {
        ArrayList<LeaderboardEntry> eligible = new ArrayList<>();
        for (LeaderboardEntry e : entries) {
            Double val = e.stats.get(metric.key);
            if (val == null) continue;
            int minPa = season == Calendar.getInstance().get(Calendar.YEAR) ? 50 : 100;
            int minBbe = season == Calendar.getInstance().get(Calendar.YEAR) ? 25 : 50;
            boolean contactMetric = metric.type.equals("contact") || metric.type.equals("rate");
            boolean pitchingMetric = "pitch".equals(metric.side);
            boolean eligibleSample = pitchingMetric ? (e.stats.ip >= (season == Calendar.getInstance().get(Calendar.YEAR) ? 10 : 25) || e.stats.pa >= minPa) : (e.stats.pa >= minPa && (!contactMetric || e.stats.bbe >= minBbe));
            if (eligibleSample) eligible.add(e);
        }
        sortEntries(eligible, metric);
        return eligible;
    }

    private void renderPlayerAllStatsRankingsAsync(int season, ArrayList<Metric> selected) throws Exception {
        if (selectedPlayer == null) throw new Exception("Pick a player first, then open Rankings.");
        ArrayList<AllRankRow> rows = new ArrayList<>();
        for (Metric m : selected) {
            ArrayList<LeaderboardEntry> entries = eligiblePlayerEntries(fetchLeaderboardForMetric(season, m), season, m);
            int rank = selectedPlayerRank(entries);
            if (entries.isEmpty()) continue;
            LeaderboardEntry leader = entries.get(0);
            LeaderboardEntry mine = rank > 0 ? entries.get(rank - 1) : null;
            rows.add(new AllRankRow(m, rank, entries.size(), mine == null ? selectedPlayer.fullName : mine.name, mine == null ? null : mine.stats.get(m.key), leader.name, leader.stats.get(m.key), selectedPlayer.id, null));
        }
        main.post(() -> {
            renderAllStatsRankings(rows, season, false);
            setBusy(false, null);
        });
    }

    private void renderTeamAllStatsRankingsAsync(int season, ArrayList<Metric> selected) throws Exception {
        if (selectedTeam == null) throw new Exception("Pick a team first, then open Rankings.");
        ArrayList<AllRankRow> rows = new ArrayList<>();
        for (Metric m : selected) {
            Map<String, Stats> teamStats = aggregateTeamStats(fetchLeaderboardForMetric(season, m));
            ArrayList<TeamStanding> teams = new ArrayList<>();
            for (Team t : allTeams) {
                Stats s = teamStats.get(t.key());
                if (s != null && s.get(m.key) != null) teams.add(new TeamStanding(t, s));
            }
            teams.sort((a, b) -> compareMetricValues(a.stats.get(m.key), b.stats.get(m.key), m));
            int rank = selectedTeamRank(teams);
            if (teams.isEmpty()) continue;
            TeamStanding leader = teams.get(0);
            TeamStanding mine = rank > 0 ? teams.get(rank - 1) : null;
            rows.add(new AllRankRow(m, rank, teams.size(), mine == null ? selectedTeam.name : mine.team.name, mine == null ? null : mine.stats.get(m.key), leader.team.name, leader.stats.get(m.key), 0, selectedTeam));
        }
        main.post(() -> {
            renderAllStatsRankings(rows, season, true);
            setBusy(false, null);
        });
    }

    private void renderAllStatsRankings(ArrayList<AllRankRow> rows, int season, boolean teamRows) {
        standingsBox.removeAllViews();
        LinearLayout card = verticalCard(22, null);
        card.setPadding(dp(14), dp(14), dp(14), dp(14));
        standingsBox.addView(card, matchWrap());
        String subject = teamRows ? (selectedTeam == null ? "Selected team" : selectedTeam.name) : (selectedPlayer == null ? "Selected player" : selectedPlayer.fullName);
        card.addView(text(subject + " · ranks across selected stats", 20, INK, true));
        TextView sub = text(season + " season · each row shows selected rank, value, and current leader", 12, MUTED, false);
        sub.setPadding(0, dp(3), 0, dp(8));
        card.addView(sub);
        lastStandingsText = subject + " " + season + " rankings across selected stats\nMetric\tRank\tValue\tLeader\tLeader Value\n";
        if (rows.isEmpty()) {
            TextView empty = text("No ranking rows found for the selected stats. Try a different stat preset.", 14, MUTED, false);
            empty.setPadding(0, dp(10), 0, dp(10));
            card.addView(empty);
        }
        for (AllRankRow r : rows) {
            card.addView(allRankRow(r, teamRows));
            lastStandingsText += r.metric.label + "\t" + (r.rank > 0 ? "#" + r.rank + " of " + r.total : "Not ranked") + "\t" + format(r.value, r.metric) + "\t" + r.leaderName + "\t" + format(r.leaderValue, r.metric) + "\n";
        }
        resultsBox.setVisibility(View.GONE);
    }

    private View allRankRow(AllRankRow r, boolean teamRows) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(8), dp(8), dp(8), dp(8));
        row.setBackground(rounded(Color.WHITE, 13));

        if (teamRows && r.team != null) {
            View logo = teamLogoView(r.team, 34);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(34), dp(34));
            lp.setMargins(0, 0, dp(8), 0);
            row.addView(logo, lp);
        } else if (!teamRows && r.playerId > 0) {
            ImageView avatar = new ImageView(this);
            avatar.setScaleType(ImageView.ScaleType.FIT_CENTER);
            avatar.setBackground(roundedStroke(Color.rgb(235, 241, 248), LINE, 17, 1));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(34), dp(34));
            lp.setMargins(0, 0, dp(8), 0);
            row.addView(avatar, lp);
            loadPlayerImage(r.playerId, avatar);
        }

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        Double rowPct = percentileFromRank(r.rank, r.total);
        String rankText = r.rank > 0 ? "#" + r.rank + " of " + r.total + (rowPct == null ? "" : " · " + percentileLabel(rowPct)) : "Not ranked";
        col.addView(text(r.metric.label + " · " + rankText, 13, INK, true));
        col.addView(text("Leader: " + r.leaderName + " " + format(r.leaderValue, r.metric), 10, MUTED, false));
        row.addView(col, new LinearLayout.LayoutParams(0, -2, 1));

        TextView val = text(format(r.value, r.metric), 14, NAVY, true);
        val.setGravity(Gravity.RIGHT);
        row.addView(val);

        LinearLayout.LayoutParams lp = matchWrap();
        lp.setMargins(0, dp(3), 0, dp(3));
        row.setLayoutParams(lp);
        return row;
    }

    private ArrayList<Metric> selectedMetricsForRows() {
        ArrayList<Metric> out = new ArrayList<>();
        for (Metric m : metrics) if (selectedMetricKeys.contains(m.key)) out.add(m);
        return out;
    }

    private HashMap<String, Integer> computePlayerRankMap(ArrayList<LeaderboardEntry> entries, int season, int playerId, ArrayList<Metric> metricList) {
        HashMap<String, Integer> ranks = new HashMap<>();
        if (playerId <= 0) return ranks;
        for (Metric m : metricList) {
            ArrayList<LeaderboardEntry> eligible = eligiblePlayerEntries(entries, season, m);
            for (int i = 0; i < eligible.size(); i++) {
                if (eligible.get(i).playerId == playerId) {
                    ranks.put(m.key, i + 1);
                    break;
                }
            }
        }
        return ranks;
    }

    private HashMap<String, Integer> computeTeamRankMap(Map<String, Stats> teamStats, String teamKey, ArrayList<Metric> metricList) {
        HashMap<String, Integer> ranks = new HashMap<>();
        for (Metric m : metricList) {
            ArrayList<TeamStanding> teams = new ArrayList<>();
            for (Team t : allTeams) {
                Stats s = teamStats.get(t.key());
                if (s != null && s.get(m.key) != null) teams.add(new TeamStanding(t, s));
            }
            teams.sort((a, b) -> compareMetricValues(a.stats.get(m.key), b.stats.get(m.key), m));
            for (int i = 0; i < teams.size(); i++) {
                if (teams.get(i).team.key().equals(teamKey)) {
                    ranks.put(m.key, i + 1);
                    break;
                }
            }
        }
        return ranks;
    }

    private HashMap<String, Integer> computePlayerRankTotalMap(ArrayList<LeaderboardEntry> entries, int season, ArrayList<Metric> metricList) {
        HashMap<String, Integer> totals = new HashMap<>();
        for (Metric m : metricList) totals.put(m.key, eligiblePlayerEntries(entries, season, m).size());
        return totals;
    }

    private HashMap<String, Integer> computeTeamRankTotalMap(Map<String, Stats> teamStats, ArrayList<Metric> metricList) {
        HashMap<String, Integer> totals = new HashMap<>();
        for (Metric m : metricList) {
            int total = 0;
            for (Team t : allTeams) {
                Stats s = teamStats.get(t.key());
                if (s != null && s.get(m.key) != null) total++;
            }
            totals.put(m.key, total);
        }
        return totals;
    }

    private HashMap<String, Double> percentileMap(Map<String, Integer> ranks, Map<String, Integer> totals) {
        HashMap<String, Double> out = new HashMap<>();
        if (ranks == null || totals == null) return out;
        for (String key : ranks.keySet()) {
            Double pct = percentileFromRank(ranks.get(key), totals.get(key));
            if (pct != null) out.put(key, pct);
        }
        return out;
    }

    private Double percentileFromRank(Integer rank, Integer total) {
        if (rank == null || total == null || rank <= 0 || total <= 0) return null;
        if (total == 1) return 100.0;
        return Math.max(0, Math.min(100, 100.0 * (total - rank) / (double) (total - 1)));
    }

    private String percentileLabel(Double pct) {
        if (pct == null || Double.isNaN(pct)) return "—";
        return Math.round(Math.max(0, Math.min(100, pct))) + "% percentile";
    }

    private String rankPercentileLabel(Integer rank, Integer total, Double pct) {
        String rankText = rank == null || rank <= 0 ? "Not ranked" : "#" + rank + (total == null || total <= 0 ? "" : " of " + total);
        String pctText = pct == null ? "" : " · " + percentileLabel(pct);
        return rankText + pctText;
    }

    private String rankOnlyLabel(Integer rank, Integer total) {
        if (rank == null || rank <= 0) return "Not ranked";
        return "#" + rank + (total == null || total <= 0 ? "" : " of " + total);
    }

    private String percentileBigLabel(Double pct) {
        if (pct == null || Double.isNaN(pct)) return "—";
        return Math.round(Math.max(0, Math.min(100, pct))) + "%";
    }

    private HashMap<String, Double> valuePercentileMapForPlayerEntries(ArrayList<LeaderboardEntry> entries, int season, Stats stats, ArrayList<Metric> metricList) {
        HashMap<String, Double> out = new HashMap<>();
        if (stats == null) return out;
        for (Metric m : metricList) {
            Double value = stats.get(m.key);
            if (value == null || Double.isNaN(value)) continue;
            ArrayList<Double> vals = new ArrayList<>();
            for (LeaderboardEntry e : eligiblePlayerEntries(entries, season, m)) {
                Double v = e.stats.get(m.key);
                if (v != null && !Double.isNaN(v)) vals.add(v);
            }
            Double pct = percentileForValue(vals, value, m);
            if (pct != null) out.put(m.key, pct);
        }
        return out;
    }

    private HashMap<String, Double> valuePercentileMapForTeams(Map<String, Stats> teamStats, Stats stats, ArrayList<Metric> metricList) {
        HashMap<String, Double> out = new HashMap<>();
        if (stats == null) return out;
        for (Metric m : metricList) {
            Double value = stats.get(m.key);
            if (value == null || Double.isNaN(value)) continue;
            ArrayList<Double> vals = new ArrayList<>();
            for (Stats s : teamStats.values()) {
                Double v = s.get(m.key);
                if (v != null && !Double.isNaN(v)) vals.add(v);
            }
            Double pct = percentileForValue(vals, value, m);
            if (pct != null) out.put(m.key, pct);
        }
        return out;
    }

    private Double percentileForValue(ArrayList<Double> values, Double value, Metric m) {
        if (values == null || values.isEmpty() || value == null || Double.isNaN(value)) return null;
        int better = 0;
        for (Double v : values) {
            if (v == null || Double.isNaN(v)) continue;
            int cmp = compareMetricValues(v, value, m);
            if (cmp < 0) better++;
        }
        return percentileFromRank(better + 1, values.size());
    }

    private void renderComparison(Comparison c) {
        resultsBox.setVisibility(View.VISIBLE);
        headerBox.removeAllViews();
        metricBox.removeAllViews();

        TeamPalette palette = paletteForComparison(c);

        LinearLayout card = verticalCard(26, new int[] { Color.WHITE, softColor(palette.secondary, 0.92f), softColor(palette.primary, 0.96f) });
        card.setPadding(dp(14), dp(14), dp(14), dp(14));
        headerBox.addView(card, matchWrap());

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        card.addView(top, matchWrap());

        if (!c.isTeam) {
            FrameLayout avatarFrame = new FrameLayout(this);
            avatarFrame.setBackground(roundedGradient(new int[] { palette.primary, palette.secondary }, 26));
            avatarFrame.setPadding(dp(3), dp(3), dp(3), dp(3));
            ImageView img = new ImageView(this);
            img.setScaleType(ImageView.ScaleType.FIT_CENTER);
            img.setBackground(roundedStroke(Color.WHITE, LINE, 24, 1));
            avatarFrame.addView(img, new FrameLayout.LayoutParams(-1, -1));
            LinearLayout.LayoutParams imgLp = new LinearLayout.LayoutParams(dp(72), dp(72));
            imgLp.setMargins(0, 0, dp(12), 0);
            top.addView(avatarFrame, imgLp);
            loadPlayerImage(c.mlbId, img);
        } else {
            View teamLogo = teamLogoView(c.team, 72);
            LinearLayout.LayoutParams badgeLp = new LinearLayout.LayoutParams(dp(72), dp(72));
            badgeLp.setMargins(0, 0, dp(12), 0);
            top.addView(teamLogo, badgeLp);
        }

        LinearLayout titleCol = new LinearLayout(this);
        titleCol.setOrientation(LinearLayout.VERTICAL);
        top.addView(titleCol, new LinearLayout.LayoutParams(0, -2, 1));
        titleCol.addView(text(c.name, 22, INK, true));
        TextView meta = text(c.meta + " · " + c.season, 12, MUTED, false);
        meta.setPadding(0, dp(2), 0, dp(6));
        titleCol.addView(meta);
        LinearLayout miniPills = new LinearLayout(this);
        miniPills.setOrientation(LinearLayout.HORIZONTAL);
        if (c.seasonStats.ip > 0 && (c.seasonStats.get("era") != null || c.seasonStats.get("whip") != null)) {
            miniPills.addView(smallDataPill(new DecimalFormat("0.0").format(c.seasonStats.ip) + " IP"), weightLp());
            miniPills.addView(smallDataPill(fmtCount(c.seasonStats.pa) + " BF"), weightLp());
        } else {
            miniPills.addView(smallDataPill(fmtCount(c.seasonStats.pa) + " PA"), weightLp());
            miniPills.addView(smallDataPill(fmtCount(c.seasonStats.bbe) + " BBE"), weightLp());
        }
        titleCol.addView(miniPills, matchWrap());

        addBaseballCardSummary(card, c, palette);

        LinearLayout sectionRow = new LinearLayout(this);
        sectionRow.setOrientation(LinearLayout.HORIZONTAL);
        sectionRow.setGravity(Gravity.CENTER_VERTICAL);
        sectionRow.setPadding(0, dp(12), 0, dp(4));
        TextView tableTitle = text("Profile comparison", 18, INK, true);
        sectionRow.addView(tableTitle, new LinearLayout.LayoutParams(0, -2, 1));
        sectionRow.addView(comparisonLegend(c.thirdLabelShort(), palette));
        metricBox.addView(sectionRow, matchWrap());
        TextView scaleHint = text("Bar positions use league percentile when available: 0% left · 50% MLB average · 100% right.", 11, MUTED, false);
        scaleHint.setPadding(dp(1), 0, dp(1), dp(6));
        metricBox.addView(scaleHint, matchWrap());

        int count = 0;
        for (Metric m : metrics) {
            if (!selectedMetricKeys.contains(m.key)) continue;
            renderMetricRow(c, m, palette);
            count++;
        }
        if (count == 0) {
            TextView empty = text("No stats selected. Tap Stats to choose a preset.", 14, MUTED, false);
            empty.setPadding(0, dp(10), 0, dp(10));
            metricBox.addView(empty);
        }
    }

    private void addBaseballCardSummary(LinearLayout card, Comparison c, TeamPalette palette) {
        LinearLayout shell = new LinearLayout(this);
        shell.setOrientation(LinearLayout.VERTICAL);
        shell.setPadding(dp(12), dp(12), dp(12), dp(12));
        LinearLayout.LayoutParams shellLp = matchWrap();
        shellLp.setMargins(0, dp(14), 0, 0);
        shell.setBackground(roundedGradient(new int[] { softColor(palette.primary, 0.96f), Color.WHITE, softColor(palette.secondary, 0.94f) }, 22));
        card.addView(shell, shellLp);

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        shell.addView(head, matchWrap());
        LinearLayout headText = new LinearLayout(this);
        headText.setOrientation(LinearLayout.VERTICAL);
        TextView title = text(c.isTeam ? "Team card" : "Player card", 11, MUTED, true);
        title.setLetterSpacing(0.08f);
        headText.addView(title);
        headText.addView(text(c.isTeam ? "Recent seasons + franchise history" : "Recent seasons + career row", 12, INK, true));
        head.addView(headText, new LinearLayout.LayoutParams(0, -2, 1));
        TextView chip = text(c.season + " snapshot", 11, Color.WHITE, true);
        chip.setGravity(Gravity.CENTER);
        chip.setPadding(dp(10), dp(5), dp(10), dp(5));
        chip.setBackground(roundedGradient(new int[] { palette.primary, palette.secondary }, 14));
        head.addView(chip);

        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        LinearLayout table = new LinearLayout(this);
        table.setOrientation(LinearLayout.VERTICAL);
        hsv.addView(table, new HorizontalScrollView.LayoutParams(-2, -2));
        LinearLayout.LayoutParams hsvLp = matchWrap();
        hsvLp.setMargins(0, dp(10), 0, 0);
        shell.addView(hsv, hsvLp);

        Metric[] cols = summaryMetricsForCard(c);
        table.addView(baseballCardHeaderRow(cols, palette));
        table.addView(baseballCardStatRow(String.valueOf(c.season), c.seasonStats, cols, palette, true, false));
        int added = 0;
        if (c.recentSeasons != null && !c.recentSeasons.isEmpty()) {
            for (Map.Entry<Integer, Stats> e : c.recentSeasons.entrySet()) {
                if (e.getKey() == c.season) continue;
                table.addView(baseballCardStatRow(String.valueOf(e.getKey()), e.getValue(), cols, palette, false, false));
                added++;
                if (added >= 3) break;
            }
        }
        if (added == 0) {
            table.addView(baseballCardStatRow("MLB", c.leagueStats, cols, palette, false, false));
        }
        table.addView(baseballCardStatRow(c.isTeam ? "History" : "Career", c.careerStats, cols, palette, false, true));
    }

    private Metric[] summaryMetricsForCard(Comparison c) {
        boolean pitch = !c.isTeam && c.player != null && isPitcher(c.player);
        if (!pitch && c.isTeam) {
            int pitchCount = 0, hitCount = 0;
            for (Metric m : selectedMetricsForRows()) { if ("pitch".equals(m.side)) pitchCount++; else hitCount++; }
            pitch = pitchCount > hitCount;
        }
        String[] keys = pitch ? new String[] { "era", "whip", "k9", "bb9", "pitchK" } : new String[] { "avg", "ops", "wOBA", "xwOBA", "barrelPct" };
        ArrayList<Metric> cols = new ArrayList<>();
        for (String k : keys) {
            Metric m = metricByKey(k);
            if (m != null) cols.add(m);
        }
        return cols.toArray(new Metric[0]);
    }

    private LinearLayout baseballCardHeaderRow(Metric[] cols, TeamPalette palette) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, 0, 0, dp(4));
        TextView season = tableCell("Season", 64, MUTED, true, Gravity.LEFT);
        row.addView(season);
        for (Metric m : cols) row.addView(tableCell(m.label, 74, MUTED, true, Gravity.CENTER));
        return row;
    }

    private LinearLayout baseballCardStatRow(String label, Stats stats, Metric[] cols, TeamPalette palette, boolean current, boolean career) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(8), dp(7), dp(8), dp(7));
        LinearLayout.LayoutParams rowLp = matchWrap();
        rowLp.setMargins(0, dp(3), 0, dp(3));
        row.setLayoutParams(rowLp);
        row.setBackground(career ? roundedGradient(new int[] { softColor(palette.secondary, 0.88f), Color.WHITE }, 16) : roundedStroke(current ? softColor(palette.primary, 0.90f) : Color.WHITE, current ? softColor(palette.primary, 0.35f) : Color.rgb(230, 236, 246), 16, 1));
        row.addView(tableCell(label, 64, current ? palette.primary : INK, true, Gravity.LEFT));
        for (Metric m : cols) {
            Double val = stats == null ? null : stats.get(m.key);
            row.addView(tableCell(format(val, m), 74, career ? palette.secondary : INK, current || career, Gravity.CENTER));
        }
        return row;
    }

    private TextView tableCell(String value, int widthDp, int color, boolean bold, int gravity) {
        TextView tv = text(value == null ? "—" : value, 12, color, bold);
        tv.setGravity(gravity);
        tv.setSingleLine(true);
        tv.setPadding(dp(3), 0, dp(3), 0);
        tv.setMinWidth(dp(widthDp));
        return tv;
    }

    private void renderExpectedComparison(Comparison c) {
        renderComparison(c);
        TeamPalette palette = paletteForComparison(c);
        metricBox.removeAllViews();

        LinearLayout sectionRow = new LinearLayout(this);
        sectionRow.setOrientation(LinearLayout.HORIZONTAL);
        sectionRow.setGravity(Gravity.CENTER_VERTICAL);
        sectionRow.setPadding(0, dp(12), 0, dp(4));
        sectionRow.addView(text("Actual vs expected", 18, INK, true), new LinearLayout.LayoutParams(0, -2, 1));
        TextView badge = text("xStats", 11, Color.WHITE, true);
        badge.setGravity(Gravity.CENTER);
        badge.setPadding(dp(9), dp(5), dp(9), dp(5));
        badge.setBackground(roundedGradient(new int[] { palette.primary, palette.secondary }, 14));
        sectionRow.addView(badge);
        metricBox.addView(sectionRow, matchWrap());

        TextView hint = text("This mode compares what happened to Statcast's expected version of the same stat. Positive gap = outperforming expected; negative gap = underperforming expected.", 11, MUTED, false);
        hint.setPadding(dp(1), 0, dp(1), dp(6));
        metricBox.addView(hint, matchWrap());

        int count = 0;
        count += renderExpectedActualRow(c, "avg", "xBA", "Batting average", palette) ? 1 : 0;
        count += renderExpectedActualRow(c, "slg", "xSLG", "Slugging", palette) ? 1 : 0;
        count += renderExpectedActualRow(c, "wOBA", "xwOBA", "wOBA", palette) ? 1 : 0;
        count += renderLuckExplainerRow(c, palette) ? 1 : 0;
        if (count == 0) {
            TextView empty = text("No actual/expected stat pairs are available for this selection. Try a hitter or team with Statcast hitting data.", 14, MUTED, false);
            empty.setPadding(0, dp(10), 0, dp(10));
            metricBox.addView(empty);
        }
    }

    private boolean renderExpectedActualRow(Comparison c, String actualKey, String expectedKey, String label, TeamPalette palette) {
        Metric actualMetric = metricByKey(actualKey);
        Metric expectedMetric = metricByKey(expectedKey);
        Double actual = c.seasonStats.get(actualKey);
        Double expected = c.seasonStats.get(expectedKey);
        if (actual == null && expected == null) return false;
        Double gap = diff(actual, expected);
        Double actualPct = c.percentile == null ? null : c.percentile.get(actualKey);
        Double expectedPct = c.percentile == null ? null : c.percentile.get(expectedKey);

        LinearLayout row = verticalCard(18, null);
        row.setPadding(dp(12), dp(10), dp(12), dp(10));
        LinearLayout.LayoutParams rowLp = matchWrap();
        rowLp.setMargins(0, dp(7), 0, 0);
        metricBox.addView(row, rowLp);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout titleCol = new LinearLayout(this);
        titleCol.setOrientation(LinearLayout.VERTICAL);
        titleCol.addView(text(label, 16, INK, true));
        titleCol.addView(text(actualMetric.label + " vs " + expectedMetric.label, 11, MUTED, false));
        top.addView(titleCol, new LinearLayout.LayoutParams(0, -2, 1));
        TextView gapBadge = text(gap == null ? "No gap" : "Gap " + signedFormat(gap, actualMetric), 11, Color.WHITE, true);
        gapBadge.setGravity(Gravity.CENTER);
        gapBadge.setPadding(dp(9), dp(5), dp(9), dp(5));
        int gapColor = gap == null || Math.abs(gap) < 0.000001 ? Color.rgb(70, 88, 125) : (gap > 0 ? palette.primary : palette.secondary);
        gapBadge.setBackground(roundedGradient(new int[] { gapColor, softColor(gapColor, 0.10f) }, 14));
        top.addView(gapBadge);
        row.addView(top);

        ExpectedActualBarView bar = new ExpectedActualBarView(this, actualMetric, actual, expected, actualPct, expectedPct, palette);
        LinearLayout.LayoutParams barLp = new LinearLayout.LayoutParams(-1, dp(54));
        barLp.setMargins(0, dp(7), 0, 0);
        row.addView(bar, barLp);

        LinearLayout values = new LinearLayout(this);
        values.setOrientation(LinearLayout.HORIZONTAL);
        values.setPadding(0, dp(5), 0, 0);
        values.addView(statValueColumn("Actual", format(actual, actualMetric), actualPct == null ? "Observed" : percentileBigLabel(actualPct) + " percentile", palette.primary, true), weightLp());
        values.addView(statValueColumn("Expected", format(expected, expectedMetric), expectedPct == null ? "xStat" : percentileBigLabel(expectedPct) + " percentile", palette.secondary, false), weightLp());
        values.addView(statValueColumn("Gap", gap == null ? "—" : signedFormat(gap, actualMetric), gap == null ? "Actual - expected" : (gap > 0 ? "Over expected" : (gap < 0 ? "Under expected" : "Even")), Color.rgb(70, 88, 125), false), weightLp());
        row.addView(values);
        return true;
    }

    private boolean renderLuckExplainerRow(Comparison c, TeamPalette palette) {
        Double luck = c.seasonStats.get("luck");
        if (luck == null) return false;
        Metric m = metricByKey("luck");
        LinearLayout row = verticalCard(18, null);
        row.setPadding(dp(12), dp(10), dp(12), dp(10));
        LinearLayout.LayoutParams rowLp = matchWrap();
        rowLp.setMargins(0, dp(7), 0, 0);
        metricBox.addView(row, rowLp);
        row.addView(text("Luck index", 16, INK, true));
        TextView detail = text("wOBA - xwOBA. Positive means results are running ahead of expected quality of contact; negative means results are lagging expected quality.", 11, MUTED, false);
        detail.setPadding(0, dp(3), 0, dp(6));
        row.addView(detail);
        LinearLayout values = new LinearLayout(this);
        values.setOrientation(LinearLayout.HORIZONTAL);
        values.addView(statValueColumn("wOBA", format(c.seasonStats.get("wOBA"), metricByKey("wOBA")), "Actual", palette.primary, true), weightLp());
        values.addView(statValueColumn("xwOBA", format(c.seasonStats.get("xwOBA"), metricByKey("xwOBA")), "Expected", palette.secondary, false), weightLp());
        values.addView(statValueColumn("Luck", signedFormat(luck, m), luck > 0 ? "Lucky" : (luck < 0 ? "Unlucky" : "Neutral"), Color.rgb(70, 88, 125), false), weightLp());
        row.addView(values);
        return true;
    }



    private void renderHeadToHead(HeadToHeadComparison h) {
        resultsBox.setVisibility(View.VISIBLE);
        headerBox.removeAllViews();
        metricBox.removeAllViews();

        TeamPalette paletteA = paletteForHeadToHeadSide(h, true);
        TeamPalette paletteB = paletteForHeadToHeadSide(h, false);

        LinearLayout card = verticalCard(26, new int[] { Color.WHITE, softColor(paletteA.primary, 0.92f), softColor(paletteB.primary, 0.94f) });
        card.setPadding(dp(14), dp(14), dp(14), dp(14));
        headerBox.addView(card, matchWrap());

        LinearLayout titleLine = new LinearLayout(this);
        titleLine.setOrientation(LinearLayout.HORIZONTAL);
        titleLine.setGravity(Gravity.CENTER_VERTICAL);
        card.addView(titleLine, matchWrap());
        LinearLayout titleCol = new LinearLayout(this);
        titleCol.setOrientation(LinearLayout.VERTICAL);
        titleLine.addView(titleCol, new LinearLayout.LayoutParams(0, -2, 1));
        titleCol.addView(text(h.isTeam ? "Team side-by-side" : "Player side-by-side", 21, INK, true));
        TextView sub = text(h.season + " season · selected stats only", 12, MUTED, false);
        sub.setPadding(0, dp(2), 0, 0);
        titleCol.addView(sub);
        TextView badge = text("H2H", 11, Color.WHITE, true);
        badge.setGravity(Gravity.CENTER);
        badge.setPadding(dp(10), dp(5), dp(10), dp(5));
        badge.setBackground(roundedGradient(new int[] { paletteA.primary, paletteB.primary }, 14));
        titleLine.addView(badge);

        LinearLayout sides = new LinearLayout(this);
        sides.setOrientation(LinearLayout.HORIZONTAL);
        sides.setPadding(0, dp(12), 0, 0);
        sides.addView(headToHeadSideTile(h, true, paletteA), weightLp());
        TextView vs = text("VS", 13, MUTED, true);
        vs.setGravity(Gravity.CENTER);
        sides.addView(vs, new LinearLayout.LayoutParams(dp(38), -1));
        sides.addView(headToHeadSideTile(h, false, paletteB), weightLp());
        card.addView(sides, matchWrap());

        LinearLayout insight = new LinearLayout(this);
        insight.setOrientation(LinearLayout.HORIZONTAL);
        insight.setPadding(0, dp(10), 0, 0);
        insight.addView(insightTile(h.nameA, keyStatSummary(h.statsA), paletteA.primary), weightLp());
        insight.addView(insightTile("MLB", keyStatSummary(h.leagueStats), Color.rgb(70, 88, 125)), weightLp());
        insight.addView(insightTile(h.nameB, keyStatSummary(h.statsB), paletteB.primary), weightLp());
        card.addView(insight);

        LinearLayout sectionRow = new LinearLayout(this);
        sectionRow.setOrientation(LinearLayout.HORIZONTAL);
        sectionRow.setGravity(Gravity.CENTER_VERTICAL);
        sectionRow.setPadding(0, dp(12), 0, dp(4));
        sectionRow.addView(text("Side-by-side stats", 18, INK, true), new LinearLayout.LayoutParams(0, -2, 1));
        sectionRow.addView(headToHeadLegend(h, paletteA, paletteB));
        metricBox.addView(sectionRow, matchWrap());

        int count = 0;
        for (Metric m : metrics) {
            if (!selectedMetricKeys.contains(m.key)) continue;
            renderHeadToHeadMetricRow(h, m, paletteA, paletteB);
            count++;
        }
        if (count == 0) {
            TextView empty = text("No stats selected. Tap Stats to choose a preset.", 14, MUTED, false);
            empty.setPadding(0, dp(10), 0, dp(10));
            metricBox.addView(empty);
        }
    }

    private View headToHeadSideTile(HeadToHeadComparison h, boolean leftSide, TeamPalette palette) {
        LinearLayout tile = new LinearLayout(this);
        tile.setOrientation(LinearLayout.HORIZONTAL);
        tile.setGravity(Gravity.CENTER_VERTICAL);
        tile.setPadding(dp(9), dp(9), dp(9), dp(9));
        tile.setBackground(roundedStroke(Color.WHITE, softColor(palette.primary, 0.55f), 18, 1));
        if (h.isTeam) {
            View logo = teamLogoView(leftSide ? h.teamA : h.teamB, 44);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(44), dp(44));
            lp.setMargins(0, 0, dp(8), 0);
            tile.addView(logo, lp);
        } else {
            ImageView img = new ImageView(this);
            img.setScaleType(ImageView.ScaleType.FIT_CENTER);
            img.setAdjustViewBounds(true);
            img.setBackground(roundedStroke(Color.rgb(235, 241, 248), LINE, 18, 1));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(44), dp(44));
            lp.setMargins(0, 0, dp(8), 0);
            tile.addView(img, lp);
            loadPlayerImage(leftSide ? h.idA : h.idB, img);
        }
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.addView(text(leftSide ? h.nameA : h.nameB, 14, INK, true));
        col.addView(text(leftSide ? h.metaA : h.metaB, 10, MUTED, false));
        tile.addView(col, new LinearLayout.LayoutParams(0, -2, 1));
        return tile;
    }

    private View headToHeadLegend(HeadToHeadComparison h, TeamPalette paletteA, TeamPalette paletteB) {
        LinearLayout legend = new LinearLayout(this);
        legend.setOrientation(LinearLayout.VERTICAL);
        legend.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        legend.addView(legendMini(shortName(h.nameA), paletteA.primary));
        legend.addView(legendMini("MLB", Color.rgb(70, 88, 125)));
        legend.addView(legendMini(shortName(h.nameB), paletteB.primary));
        return legend;
    }

    private void renderHeadToHeadMetricRow(HeadToHeadComparison h, Metric m, TeamPalette paletteA, TeamPalette paletteB) {
        Double valueA = h.statsA.get(m.key);
        Double valueB = h.statsB.get(m.key);
        Double leagueValue = h.leagueStats == null ? null : h.leagueStats.get(m.key);
        Double delta = diff(valueA, valueB);

        LinearLayout row = verticalCard(18, null);
        row.setPadding(dp(12), dp(10), dp(12), dp(10));
        LinearLayout.LayoutParams rowLp = matchWrap();
        rowLp.setMargins(0, dp(7), 0, 0);
        metricBox.addView(row, rowLp);

        Integer rankA = h.rankA == null ? null : h.rankA.get(m.key);
        Integer rankB = h.rankB == null ? null : h.rankB.get(m.key);
        Integer totalA = h.rankTotalA == null ? null : h.rankTotalA.get(m.key);
        Integer totalB = h.rankTotalB == null ? null : h.rankTotalB.get(m.key);
        Double pctA = h.percentileA == null ? null : h.percentileA.get(m.key);
        Double pctB = h.percentileB == null ? null : h.percentileB.get(m.key);

        LinearLayout topLine = new LinearLayout(this);
        topLine.setOrientation(LinearLayout.HORIZONTAL);
        topLine.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout metricTitle = new LinearLayout(this);
        metricTitle.setOrientation(LinearLayout.VERTICAL);
        metricTitle.addView(text(m.label, 16, INK, true));
        TextView context = text(delta == null ? "Side-by-side comparison" : "Difference: " + signedFormat(delta, m), 11, MUTED, false);
        context.setPadding(0, dp(1), 0, 0);
        metricTitle.addView(context);
        topLine.addView(metricTitle, new LinearLayout.LayoutParams(0, -2, 1));
        String leader = "Even";
        int leaderColor = Color.rgb(70, 88, 125);
        if (delta != null && Math.abs(delta) > 0.000001) {
            boolean aLeads = m.higherGood == null ? delta > 0 : (m.higherGood ? delta > 0 : delta < 0);
            leader = shortName(aLeads ? h.nameA : h.nameB) + " leads";
            leaderColor = aLeads ? paletteA.primary : paletteB.primary;
        }
        TextView leaderBadge = text(leader, 11, Color.WHITE, true);
        leaderBadge.setGravity(Gravity.CENTER);
        leaderBadge.setPadding(dp(9), dp(5), dp(9), dp(5));
        leaderBadge.setBackground(roundedGradient(new int[] { leaderColor, softColor(leaderColor, 0.10f) }, 14));
        topLine.addView(leaderBadge);
        row.addView(topLine);

        TextView rankTv = text("Ranks: " + rankOnlyLabel(rankA, totalA) + " vs " + rankOnlyLabel(rankB, totalB), 11, Color.rgb(88, 99, 118), false);
        rankTv.setPadding(0, dp(5), 0, 0);
        row.addView(rankTv);

        row.addView(percentileDuelView(h.nameA, pctA, paletteA.primary, h.nameB, pctB, paletteB.primary), matchWrap());

        HeadToHeadBarView bar = new HeadToHeadBarView(this, m, new Double[] { valueA, valueB, leagueValue }, new Double[] { pctA, pctB, 50.0 }, paletteA, paletteB, h.nameA, h.nameB);
        LinearLayout.LayoutParams barLp = new LinearLayout.LayoutParams(-1, dp(58));
        barLp.setMargins(0, dp(5), 0, 0);
        row.addView(bar, barLp);
        if (h.isTeam) {
            loadTeamLogoBitmap(h.teamA, bar::setIconA);
            loadTeamLogoBitmap(h.teamB, bar::setIconB);
        } else {
            loadPlayerImageBitmap(h.idA, bar::setIconA);
            loadPlayerImageBitmap(h.idB, bar::setIconB);
        }

        LinearLayout valueLine = new LinearLayout(this);
        valueLine.setOrientation(LinearLayout.HORIZONTAL);
        valueLine.setPadding(0, dp(4), 0, 0);
        valueLine.addView(statValueColumn(shortName(h.nameA), format(valueA, m), "Selected value", paletteA.primary, true), weightLp());
        valueLine.addView(statValueColumn("MLB avg", format(leagueValue, m), "League baseline", Color.rgb(70, 88, 125), false), weightLp());
        valueLine.addView(statValueColumn(shortName(h.nameB), format(valueB, m), "Selected value", paletteB.primary, true), weightLp());
        row.addView(valueLine);
    }

    private TeamPalette paletteForHeadToHeadSide(HeadToHeadComparison h, boolean leftSide) {
        if (h == null) return defaultPalette();
        if (h.isTeam) return paletteForTeam(leftSide ? h.teamA : h.teamB);
        Player p = leftSide ? h.playerA : h.playerB;
        return paletteForAbbr(p == null ? "" : p.teamAbbr);
    }

    private int deltaColorForHeadToHead(Double delta, Metric m, TeamPalette paletteA, TeamPalette paletteB) {
        if (delta == null || delta == 0) return MUTED;
        boolean leftBetter = delta > 0;
        if (m.higherGood != null && !m.higherGood) leftBetter = delta < 0;
        return leftBetter ? paletteA.primary : paletteB.primary;
    }

    private String shortName(String name) {
        String s = safe(name).trim();
        if (s.length() <= 12) return s;
        String[] parts = s.split("\\s+");
        if (parts.length >= 2) return parts[parts.length - 1];
        return s.substring(0, 12);
    }


    private void refreshCurrentResults() {
        if (resultsBox.getVisibility() != View.VISIBLE) return;
        if (lastHeadToHead != null) renderHeadToHead(lastHeadToHead);
        else if (lastComparison != null) renderComparison(lastComparison);
    }

    private TextView summaryPill(String label, String value) {
        TextView tv = text(label + "\n" + value, 12, INK, true);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(dp(6), dp(9), dp(6), dp(9));
        tv.setBackground(roundedStroke(Color.rgb(248, 250, 253), LINE, 16, 1));
        tv.setLineSpacing(dp(2), 1.0f);
        return tv;
    }

    private TextView smallDataPill(String value) {
        TextView tv = text(value, 11, Color.rgb(64, 75, 94), true);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(dp(6), dp(4), dp(6), dp(4));
        tv.setBackground(roundedStroke(Color.WHITE, Color.rgb(222, 231, 242), 12, 1));
        return tv;
    }

    private TextView insightTile(String label, String value, int accent) {
        TextView tv = text(label + "\n" + value, 12, accent, true);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(dp(6), dp(8), dp(6), dp(8));
        tv.setBackground(roundedStroke(Color.WHITE, Color.rgb(224, 232, 243), 16, 1));
        tv.setLineSpacing(dp(2), 1.0f);
        return tv;
    }

    private String keyStatSummary(Stats s) {
        if (s == null) return "—";
        Double w = s.get("wOBA");
        Double x = s.get("xwOBA");
        Double l = s.get("luck");
        String luckText = l == null ? "" : " · Luck " + new DecimalFormat("+0.000;-0.000").format(l);
        return "wOBA " + format(w, metricByKey("wOBA")) + "\nxwOBA " + format(x, metricByKey("xwOBA")) + luckText;
    }

    private Metric metricByKey(String key) {
        for (Metric m : metrics) if (m.key.equals(key)) return m;
        return metrics[0];
    }


    private View comparisonLegend(String thirdLabelShort, TeamPalette palette) {
        LinearLayout legend = new LinearLayout(this);
        legend.setOrientation(LinearLayout.HORIZONTAL);
        legend.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        legend.addView(legendMini("Selected", palette.primary));
        legend.addView(legendMini("League", Color.rgb(70, 88, 125)));
        legend.addView(legendMini(thirdLabelShort, palette.secondary));
        return legend;
    }


    private TextView legendMini(String label, int color) {
        TextView tv = text("● " + label, 9, color, true);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(dp(3), dp(2), dp(3), dp(2));
        return tv;
    }


    private void renderMetricRow(Comparison c, Metric m, TeamPalette palette) {
        Double seasonValue = c.seasonStats.get(m.key);
        Double leagueValue = c.leagueStats == null ? null : c.leagueStats.get(m.key);
        Double careerValue = c.careerStats.get(m.key);
        Double vsLeague = diff(seasonValue, leagueValue);

        LinearLayout row = verticalCard(18, null);
        row.setPadding(dp(12), dp(10), dp(12), dp(10));
        LinearLayout.LayoutParams rowLp = matchWrap();
        rowLp.setMargins(0, dp(7), 0, 0);
        metricBox.addView(row, rowLp);

        Integer rank = c.rank == null ? null : c.rank.get(m.key);
        Integer total = c.rankTotal == null ? null : c.rankTotal.get(m.key);
        Double pct = c.percentile == null ? null : c.percentile.get(m.key);
        Double thirdPct = c.thirdPercentile == null ? null : c.thirdPercentile.get(m.key);

        LinearLayout topLine = new LinearLayout(this);
        topLine.setOrientation(LinearLayout.HORIZONTAL);
        topLine.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout metricTitle = new LinearLayout(this);
        metricTitle.setOrientation(LinearLayout.VERTICAL);
        TextView label = text(m.label, 16, INK, true);
        metricTitle.addView(label);
        TextView context = text(vsLeague == null ? "Compared with league average" : signedFormat(vsLeague, m) + " vs MLB average", 11, MUTED, false);
        context.setPadding(0, dp(1), 0, 0);
        metricTitle.addView(context);
        topLine.addView(metricTitle, new LinearLayout.LayoutParams(0, -2, 1));

        TextView pctBadge = text(pct == null ? "No percentile" : percentileLabel(pct), 11, Color.WHITE, true);
        pctBadge.setGravity(Gravity.CENTER);
        pctBadge.setPadding(dp(9), dp(5), dp(9), dp(5));
        pctBadge.setBackground(roundedGradient(new int[] { palette.primary, softColor(palette.primary, 0.08f) }, 14));
        topLine.addView(pctBadge);
        row.addView(topLine);

        String rankLine = rank == null ? "League rank unavailable for this stat" : "League rank: #" + rank + (total == null || total <= 0 ? "" : " of " + total);
        TextView rankTv = text(rankLine, 11, Color.rgb(88, 99, 118), false);
        rankTv.setPadding(0, dp(5), 0, 0);
        row.addView(rankTv);

        ComparisonBarView bar = new ComparisonBarView(this, m,
                new Double[] { seasonValue, leagueValue, careerValue },
                new Double[] { pct, 50.0, thirdPct },
                c.thirdLabelShort(), palette, c.isTeam ? c.meta : c.name);
        LinearLayout.LayoutParams barLp = new LinearLayout.LayoutParams(-1, dp(58));
        barLp.setMargins(0, dp(5), 0, 0);
        row.addView(bar, barLp);
        if (c.isTeam) loadTeamLogoBitmap(c.team, bar::setCurrentIcon);
        else loadPlayerImageBitmap(c.mlbId, bar::setCurrentIcon);

        LinearLayout valueLine = new LinearLayout(this);
        valueLine.setOrientation(LinearLayout.HORIZONTAL);
        valueLine.setPadding(0, dp(4), 0, 0);
        valueLine.addView(statValueColumn("This year", format(seasonValue, m), "Current season", palette.primary, true), weightLp());
        valueLine.addView(statValueColumn("MLB avg", format(leagueValue, m), "League baseline", Color.rgb(70, 88, 125), false), weightLp());
        valueLine.addView(statValueColumn(c.thirdLabelShort(), format(careerValue, m), c.isTeam ? "Team history" : "Career average", palette.secondary, false), weightLp());
        row.addView(valueLine);
    }

    private LinearLayout statValueColumn(String title, String value, String detail, int color, boolean emphasized) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(dp(5), dp(6), dp(5), dp(6));
        int bg = emphasized ? softColor(color, 0.95f) : Color.rgb(250, 252, 255);
        int stroke = emphasized ? softColor(color, 0.55f) : Color.rgb(226, 234, 244);
        box.setBackground(roundedStroke(bg, stroke, 14, 1));

        TextView top = text(title.toUpperCase(Locale.US), 9, emphasized ? color : Color.rgb(108, 119, 137), true);
        top.setGravity(Gravity.CENTER);
        top.setLetterSpacing(0.08f);
        box.addView(top, matchWrap());

        TextView primary = text(value == null ? "—" : value, 15, INK, true);
        primary.setGravity(Gravity.CENTER);
        primary.setPadding(0, dp(2), 0, 0);
        box.addView(primary, matchWrap());

        TextView sub = text(detail == null || detail.isEmpty() ? "—" : detail, 9, Color.rgb(97, 109, 128), false);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, dp(2), 0, 0);
        box.addView(sub, matchWrap());
        return box;
    }

    private View percentileDuelView(String nameA, Double pctA, int colorA, String nameB, Double pctB, int colorB) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(7), 0, dp(1));
        row.addView(percentileTile(shortName(nameA), pctA, colorA), weightLp());
        TextView mid = text("percentile", 9, MUTED, true);
        mid.setGravity(Gravity.CENTER);
        row.addView(mid, new LinearLayout.LayoutParams(dp(68), -1));
        row.addView(percentileTile(shortName(nameB), pctB, colorB), weightLp());
        return row;
    }

    private View percentileTile(String label, Double pct, int color) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(8), dp(6), dp(8), dp(6));
        box.setBackground(roundedStroke(Color.rgb(250, 252, 255), softColor(color, 0.55f), 14, 1));
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView name = text(label, 10, color, true);
        top.addView(name, new LinearLayout.LayoutParams(0, -2, 1));
        TextView pctText = text(percentileBigLabel(pct), 16, INK, true);
        pctText.setGravity(Gravity.RIGHT);
        top.addView(pctText);
        box.addView(top, matchWrap());
        PercentileMiniBarView mini = new PercentileMiniBarView(this, color, pct);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(8));
        lp.setMargins(0, dp(5), 0, 0);
        box.addView(mini, lp);
        return box;
    }

    private TextView tinyValue(String label, String value, int color) {
        TextView tv = text(label + " " + value, 10, color, true);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(dp(2), dp(1), dp(2), dp(1));
        return tv;
    }



    private int metricAccentColor(Metric m, Double delta) {
        if (delta == null || m.higherGood == null) return NAVY;
        boolean good = delta > 0;
        if (!m.higherGood) good = delta < 0;
        return good ? TEAL_DARK : SALMON;
    }

    private TextView compactValue(String label, String value, int color) {
        TextView tv = text(label + " " + value, 11, color, true);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(dp(3), dp(1), dp(3), dp(1));
        return tv;
    }

    private void renderPlayerStandings(ArrayList<LeaderboardEntry> entries, int season, Metric metric) {
        standingsBox.removeAllViews();
        LinearLayout card = verticalCard(22, null);
        card.setPadding(dp(14), dp(14), dp(14), dp(14));
        standingsBox.addView(card, matchWrap());
        card.addView(text(season + " player standings · " + metric.label, 20, INK, true));
        boolean luckMode = metric.key.equals("luck");
        TextView sub = text(luckMode ? "Positive = luckier than expected. Negative = unluckier than expected." : "Top " + Math.min(30, entries.size()) + " players by selected stat", 12, MUTED, false);
        sub.setPadding(0, dp(3), 0, dp(8));
        card.addView(sub);

        lastStandingsText = season + " player standings by " + metric.label + "\nRank\tPlayer\tTeam\t" + metric.label + "\tPA\tBBE\n";
        int selectedRank = selectedPlayerRank(entries);
        if (selectedRank > 0) {
            card.addView(sectionLabel("Selected player rank"));
            addPlayerStandingRow(card, selectedRank, entries.get(selectedRank - 1), metric);
            card.addView(sectionLabel(luckMode ? "Overall leaderboard" : "Top rankings"));
        }
        if (luckMode && entries.size() > 20) {
            card.addView(sectionLabel("Luckiest"));
            int topLimit = Math.min(12, entries.size());
            for (int i = 0; i < topLimit; i++) addPlayerStandingRow(card, i + 1, entries.get(i), metric);
            card.addView(sectionLabel("Unluckiest"));
            for (int i = entries.size() - 1, rank = entries.size(); i >= Math.max(topLimit, entries.size() - 12); i--, rank--) addPlayerStandingRow(card, rank, entries.get(i), metric);
        } else {
            int limit = Math.min(30, entries.size());
            for (int i = 0; i < limit; i++) addPlayerStandingRow(card, i + 1, entries.get(i), metric);
        }
        resultsBox.setVisibility(View.GONE);
    }

    private void addPlayerStandingRow(LinearLayout card, int rank, LeaderboardEntry e, Metric metric) {
        boolean highlight = selectedPlayer != null && e.playerId == selectedPlayer.id;
        card.addView(standingRow(rank, e.name, e.teamAbbrOrName(), format(e.stats.get(metric.key), metric), e.stats, highlight, e.playerId, null));
        lastStandingsText += rank + "\t" + e.name + "\t" + e.teamAbbrOrName() + "\t" + format(e.stats.get(metric.key), metric) + "\t" + e.stats.pa + "\t" + e.stats.bbe + "\n";
    }

    private TextView sectionLabel(String value) {
        TextView tv = text(value, 12, TEAL_DARK, true);
        tv.setPadding(0, dp(10), 0, dp(3));
        return tv;
    }

    private void renderTeamStandings(ArrayList<TeamStanding> teams, int season, Metric metric) {
        standingsBox.removeAllViews();
        LinearLayout card = verticalCard(22, null);
        card.setPadding(dp(14), dp(14), dp(14), dp(14));
        standingsBox.addView(card, matchWrap());
        card.addView(text(season + " team standings · " + metric.label, 20, INK, true));
        boolean luckMode = metric.key.equals("luck");
        TextView sub = text(luckMode ? "Positive = luckier than expected. Negative = unluckier than expected." : "All MLB teams ranked by selected stat", 12, MUTED, false);
        sub.setPadding(0, dp(3), 0, dp(8));
        card.addView(sub);

        lastStandingsText = season + " team standings by " + metric.label + "\nRank\tTeam\t" + metric.label + "\tPA\tBBE\n";
        int selectedRank = selectedTeamRank(teams);
        if (selectedRank > 0) {
            card.addView(sectionLabel("Selected team rank"));
            addTeamStandingRow(card, selectedRank, teams.get(selectedRank - 1), metric);
            card.addView(sectionLabel(luckMode ? "Overall leaderboard" : "League table"));
        }
        if (luckMode && teams.size() > 20) {
            card.addView(sectionLabel("Luckiest"));
            int topLimit = Math.min(10, teams.size());
            for (int i = 0; i < topLimit; i++) addTeamStandingRow(card, i + 1, teams.get(i), metric);
            card.addView(sectionLabel("Unluckiest"));
            for (int i = teams.size() - 1, rank = teams.size(); i >= Math.max(topLimit, teams.size() - 10); i--, rank--) addTeamStandingRow(card, rank, teams.get(i), metric);
        } else {
            for (int i = 0; i < teams.size(); i++) addTeamStandingRow(card, i + 1, teams.get(i), metric);
        }
        resultsBox.setVisibility(View.GONE);
    }

    private void addTeamStandingRow(LinearLayout card, int rank, TeamStanding t, Metric metric) {
        boolean highlight = selectedTeam != null && t.team.key().equals(selectedTeam.key());
        card.addView(standingRow(rank, t.team.name, t.team.abbr, format(t.stats.get(metric.key), metric), t.stats, highlight, 0, t.team));
        lastStandingsText += rank + "\t" + t.team.name + "\t" + format(t.stats.get(metric.key), metric) + "\t" + t.stats.pa + "\t" + t.stats.bbe + "\n";
    }

    private int selectedPlayerRank(ArrayList<LeaderboardEntry> entries) {
        if (selectedPlayer == null) return -1;
        for (int i = 0; i < entries.size(); i++) if (entries.get(i).playerId == selectedPlayer.id) return i + 1;
        return -1;
    }

    private int selectedTeamRank(ArrayList<TeamStanding> teams) {
        if (selectedTeam == null) return -1;
        for (int i = 0; i < teams.size(); i++) if (teams.get(i).team.key().equals(selectedTeam.key())) return i + 1;
        return -1;
    }

    private View standingRow(int rank, String name, String meta, String value, Stats stats, boolean highlight, int playerId, Team team) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(7), dp(7), dp(7), dp(7));
        row.setBackground(rounded(highlight ? Color.rgb(231, 251, 248) : Color.WHITE, 13));

        TextView rankTv = text(String.valueOf(rank), 13, highlight ? TEAL_DARK : MUTED, true);
        rankTv.setGravity(Gravity.CENTER);
        row.addView(rankTv, new LinearLayout.LayoutParams(dp(30), -2));

        if (playerId > 0) {
            ImageView avatar = new ImageView(this);
            avatar.setScaleType(ImageView.ScaleType.FIT_CENTER);
            avatar.setBackground(roundedStroke(Color.rgb(235, 241, 248), LINE, 18, 1));
            LinearLayout.LayoutParams aLp = new LinearLayout.LayoutParams(dp(36), dp(36));
            aLp.setMargins(0, 0, dp(8), 0);
            row.addView(avatar, aLp);
            loadPlayerImage(playerId, avatar);
        } else if (team != null) {
            View logo = teamLogoView(team, 36);
            LinearLayout.LayoutParams aLp = new LinearLayout.LayoutParams(dp(36), dp(36));
            aLp.setMargins(0, 0, dp(8), 0);
            row.addView(logo, aLp);
        }

        LinearLayout nameCol = new LinearLayout(this);
        nameCol.setOrientation(LinearLayout.VERTICAL);
        nameCol.addView(text(name, 13, INK, true));
        nameCol.addView(text(meta + " · " + statLineSummary(stats), 10, MUTED, false));
        row.addView(nameCol, new LinearLayout.LayoutParams(0, -2, 1));

        TextView val = text(value, 14, NAVY, true);
        val.setGravity(Gravity.RIGHT);
        row.addView(val);

        LinearLayout.LayoutParams lp = matchWrap();
        lp.setMargins(0, dp(3), 0, dp(3));
        row.setLayoutParams(lp);
        return row;
    }

    private void copyCurrentTable() {
        String text;
        if (resultsBox.getVisibility() == View.VISIBLE && lastHeadToHead != null) text = headToHeadText(lastHeadToHead);
        else if (resultsBox.getVisibility() == View.VISIBLE && lastComparison != null) text = comparisonText(lastComparison);
        else text = lastStandingsText;
        if (text == null || text.trim().isEmpty()) return;
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("Statcast table", text));
        Toast.makeText(this, "Copied table", Toast.LENGTH_SHORT).show();
    }

    private String comparisonText(Comparison c) {
        StringBuilder sb = new StringBuilder();
        sb.append(c.name).append(" · ").append(c.season).append(" Statcast comparison\n");
        sb.append("Metric\tSeason\tLeague Avg\t").append(c.thirdLabel).append("\tVs League\tVs ").append(c.thirdLabel).append("\n");
        for (Metric m : metrics) {
            if (!selectedMetricKeys.contains(m.key)) continue;
            Double season = c.seasonStats.get(m.key);
            Double league = c.leagueStats == null ? null : c.leagueStats.get(m.key);
            Double career = c.careerStats.get(m.key);
            sb.append(m.label).append('\t')
                    .append(format(season, m)).append('\t')
                    .append(format(league, m)).append('\t')
                    .append(format(career, m)).append('\t')
                    .append(signedFormat(diff(season, league), m)).append('\t')
                    .append(signedFormat(diff(season, career), m)).append('\n');
        }
        return sb.toString();
    }

    private String headToHeadText(HeadToHeadComparison h) {
        StringBuilder sb = new StringBuilder();
        sb.append(h.nameA).append(" vs ").append(h.nameB).append(" · ").append(h.season).append(" Statcast side-by-side\n");
        sb.append("Metric\t").append(h.nameA).append("\tMLB Avg\t").append(h.nameB).append("\tDiff A-B\n");
        for (Metric m : metrics) {
            if (!selectedMetricKeys.contains(m.key)) continue;
            Double a = h.statsA.get(m.key);
            Double league = h.leagueStats == null ? null : h.leagueStats.get(m.key);
            Double b = h.statsB.get(m.key);
            sb.append(m.label).append('\t')
                    .append(format(a, m)).append('\t')
                    .append(format(league, m)).append('\t')
                    .append(format(b, m)).append('\t')
                    .append(signedFormat(diff(a, b), m)).append('\n');
        }
        return sb.toString();
    }

    // Data loading -----------------------------------------------------------------------------

    private LoadedData fetchTeamsAndActivePlayers() throws Exception {
        String teamsText = httpGet("https://statsapi.mlb.com/api/v1/teams?sportId=1&activeStatus=Y");
        JSONArray teams = new JSONObject(teamsText).optJSONArray("teams");
        ArrayList<Team> teamList = new ArrayList<>();
        LinkedHashMap<Integer, Team> teamsById = new LinkedHashMap<>();
        if (teams == null) return new LoadedData(teamList, new ArrayList<>());

        for (int i = 0; i < teams.length(); i++) {
            JSONObject teamJson = teams.getJSONObject(i);
            int teamId = teamJson.optInt("id");
            String name = teamJson.optString("name", "MLB");
            String abbr = teamJson.optString("abbreviation", teamJson.optString("teamCode", name));
            Team t = new Team(teamId, name, abbr);
            teamList.add(t);
            teamsById.put(teamId, t);
        }
        teamList.sort((a, b) -> a.name.compareToIgnoreCase(b.name));

        ArrayList<Player> fastPlayers = fetchPlayersFromSingleEndpoint(teamsById);
        if (!fastPlayers.isEmpty()) return new LoadedData(teamList, fastPlayers);

        // Fallback: roster-by-team, but in parallel. The original version did this sequentially and felt very slow.
        LinkedHashMap<Integer, Player> playersById = new LinkedHashMap<>();
        ExecutorService rosterPool = Executors.newFixedThreadPool(8);
        ArrayList<Future<ArrayList<Player>>> futures = new ArrayList<>();
        for (Team t : teamList) {
            futures.add(rosterPool.submit(() -> fetchRosterForTeam(t)));
        }
        for (Future<ArrayList<Player>> f : futures) {
            try {
                for (Player p : f.get()) playersById.put(p.id, p);
            } catch (Exception ignored) {}
        }
        rosterPool.shutdown();
        ArrayList<Player> players = new ArrayList<>(playersById.values());
        players.sort((a, b) -> a.fullName.compareToIgnoreCase(b.fullName));
        return new LoadedData(teamList, players);
    }

    private ArrayList<Player> fetchPlayersFromSingleEndpoint(Map<Integer, Team> teamsById) {
        ArrayList<Player> players = new ArrayList<>();
        try {
            int season = Calendar.getInstance().get(Calendar.YEAR);
            String url = "https://statsapi.mlb.com/api/v1/sports/1/players?season=" + season + "&activeStatus=Y&hydrate=currentTeam,primaryPosition";
            String text = httpGet(url);
            JSONArray people = new JSONObject(text).optJSONArray("people");
            if (people == null) return players;
            for (int i = 0; i < people.length(); i++) {
                JSONObject person = people.getJSONObject(i);
                int id = person.optInt("id");
                String fullName = person.optString("fullName", "");
                JSONObject currentTeam = person.optJSONObject("currentTeam");
                int teamId = currentTeam == null ? 0 : currentTeam.optInt("id");
                Team team = teamsById.get(teamId);
                String teamName = team == null ? (currentTeam == null ? "" : currentTeam.optString("name", "")) : team.name;
                String teamAbbr = team == null ? (currentTeam == null ? "" : currentTeam.optString("abbreviation", "")) : team.abbr;
                JSONObject pos = person.optJSONObject("primaryPosition");
                String position = pos == null ? "" : pos.optString("abbreviation", pos.optString("name", ""));
                if (id > 0 && !fullName.isEmpty() && !teamName.isEmpty()) players.add(new Player(id, fullName, teamName, teamAbbr, position));
            }
            players.sort((a, b) -> a.fullName.compareToIgnoreCase(b.fullName));
        } catch (Exception ignored) {}
        return players;
    }

    private ArrayList<Player> fetchRosterForTeam(Team team) {
        ArrayList<Player> players = new ArrayList<>();
        try {
            String rosterText = httpGet("https://statsapi.mlb.com/api/v1/teams/" + team.id + "/roster/active?hydrate=person");
            JSONArray roster = new JSONObject(rosterText).optJSONArray("roster");
            if (roster == null) return players;
            for (int j = 0; j < roster.length(); j++) {
                JSONObject item = roster.getJSONObject(j);
                JSONObject person = item.optJSONObject("person");
                JSONObject pos = item.optJSONObject("position");
                if (person == null) continue;
                int id = person.optInt("id");
                String fullName = person.optString("fullName", "");
                String position = pos == null ? "" : pos.optString("abbreviation", pos.optString("name", ""));
                if (id > 0 && !fullName.isEmpty()) players.add(new Player(id, fullName, team.name, team.abbr, position));
            }
        } catch (Exception ignored) {}
        return players;
    }

    private ArrayList<LeaderboardEntry> fetchLeaderboardForMetric(int season, Metric metric) throws Exception {
        return "pitch".equals(metric.side) ? fetchPitchingLeaderboard(season) : fetchLeaderboard(season);
    }

    private ArrayList<LeaderboardEntry> fetchLeaderboardForPlayer(Player p, int season) throws Exception {
        return isPitcher(p) ? fetchPitchingLeaderboard(season) : fetchLeaderboard(season);
    }

    private ArrayList<LeaderboardEntry> fetchLeaderboardForSelectedMetrics(int season) throws Exception {
        int pitch = 0, hit = 0;
        for (Metric m : metrics) if (selectedMetricKeys.contains(m.key)) { if ("pitch".equals(m.side)) pitch++; else if ("hit".equals(m.side)) hit++; }
        return pitch > hit ? fetchPitchingLeaderboard(season) : fetchLeaderboard(season);
    }

    private ArrayList<LeaderboardEntry> fetchLeaderboard(int season) throws Exception {
        ArrayList<LeaderboardEntry> cached = leaderboardCache.get(season);
        if (cached != null) return cached;
        String csv = httpGet(customLeaderboardUrl(season));
        List<Map<String, String>> rows = parseCsv(csv);
        if (rows.isEmpty()) throw new Exception("No Baseball Savant leaderboard rows returned for " + season + ".");
        ArrayList<LeaderboardEntry> entries = new ArrayList<>();
        for (Map<String, String> row : rows) {
            int id = intVal(pick(row, "player_id", "playerid", "player id", "batter", "entity_id"));
            String name = pickString(row, "player_name", "player name", "last_name, first_name", "name", "last_name first_name");
            if (name.isEmpty()) name = buildNameFromColumns(row);
            name = normalizePlayerName(name);
            String teamName = pickString(row, "team_name", "team name", "team", "team_name_alt");
            String teamAbbr = pickString(row, "team_abbrev", "team abbr", "team_abbreviation", "team_short", "team");
            if (id > 0) {
                Player p = playerById(id);
                if (p != null) {
                    if (teamName.isEmpty()) teamName = p.teamName;
                    if (teamAbbr.isEmpty()) teamAbbr = p.teamAbbr;
                    if (name.isEmpty()) name = p.fullName;
                }
            }
            Stats stats = statsFromLeaderboardRow(row);
            if ((!name.isEmpty() || id > 0) && (stats.pa > 0 || stats.bbe > 0 || stats.anyValue())) {
                entries.add(new LeaderboardEntry(id, name, teamName, teamAbbr, stats));
            }
        }
        mergeStandardStatsIntoEntries(entries, fetchStandardLeaderboard(season, false));
        leaderboardCache.put(season, entries);
        return entries;
    }

    private ArrayList<LeaderboardEntry> fetchPitchingLeaderboard(int season) throws Exception {
        ArrayList<LeaderboardEntry> cached = pitchingLeaderboardCache.get(season);
        if (cached != null) return cached;
        ArrayList<LeaderboardEntry> entries = fetchStandardLeaderboard(season, true);
        if (entries.isEmpty()) throw new Exception("No pitching rows returned for " + season + ".");
        pitchingLeaderboardCache.put(season, entries);
        return entries;
    }

    private String customLeaderboardUrl(int season) throws Exception {
        LinkedHashMap<String, String> params = new LinkedHashMap<>();
        params.put("year", String.valueOf(season));
        params.put("type", "batter");
        params.put("filter", "");
        params.put("min", "1");
        params.put("selections", "pa,xba,xslg,woba,xwoba,exit_velocity_avg,launch_angle_avg,sweet_spot_percent,barrel_batted_rate,hard_hit_percent,k_percent,bb_percent");
        params.put("sort", "xwoba");
        params.put("sortDir", "desc");
        params.put("csv", "true");
        return "https://baseballsavant.mlb.com/leaderboard/custom" + toQuery(params);
    }

    private Stats statsFromLeaderboardRow(Map<String, String> row) {
        Stats s = new Stats();
        s.pa = intVal(pick(row, "pa", "PA"));
        s.bbe = intVal(pick(row, "batted_ball", "batted_balls", "batted balls", "bbe", "Batted Balls", "batted_ball_events"));
        if (s.bbe <= 0) s.bbe = intVal(pick(row, "bip", "balls in play"));
        if (s.bbe <= 0 && s.pa > 0) s.bbe = Math.max(1, (int) Math.round(s.pa * 0.68));
        s.put("wOBA", pick(row, "woba", "wOBA"));
        s.put("xBA", pick(row, "xba", "xBA"));
        s.put("xSLG", pick(row, "xslg", "xSLG"));
        s.put("xwOBA", pick(row, "xwoba", "xwOBA"));
        s.put("avgEV", pick(row, "exit_velocity_avg", "Avg EV (MPH)", "avg_ev", "avg exit velocity"));
        s.put("avgLA", pick(row, "launch_angle_avg", "Avg LA (°)", "avg_la", "avg launch angle"));
        s.put("hardHitPct", pick(row, "hard_hit_percent", "Hard Hit %", "hardhit_percent"));
        s.put("barrelPct", pick(row, "barrel_batted_rate", "Barrel%", "barrel_percent", "barrel_batted_rate"));
        s.put("sweetSpotPct", pick(row, "sweet_spot_percent", "LA Sweet-Spot %", "sweet spot %"));
        s.put("kPct", pick(row, "k_percent", "K%", "strikeout_percent", "k %"));
        s.put("bbPct", pick(row, "bb_percent", "BB%", "walk_percent", "bb %"));
        return s;
    }

    private ArrayList<LeaderboardEntry> fetchStandardLeaderboard(int season, boolean pitching) {
        ArrayList<LeaderboardEntry> out = new ArrayList<>();
        try {
            String group = pitching ? "pitching" : "hitting";
            String url = "https://statsapi.mlb.com/api/v1/stats?stats=season&group=" + group + "&playerPool=ALL&season=" + season + "&limit=10000";
            String text = httpGet(url);
            JSONArray statsArr = new JSONObject(text).optJSONArray("stats");
            if (statsArr == null || statsArr.length() == 0) return out;
            JSONArray splits = statsArr.getJSONObject(0).optJSONArray("splits");
            if (splits == null) return out;
            for (int i = 0; i < splits.length(); i++) {
                JSONObject split = splits.getJSONObject(i);
                JSONObject player = split.optJSONObject("player");
                JSONObject team = split.optJSONObject("team");
                JSONObject stat = split.optJSONObject("stat");
                if (player == null || stat == null) continue;
                int id = player.optInt("id");
                String name = player.optString("fullName", "");
                String teamName = team == null ? "" : team.optString("name", "");
                String teamAbbr = team == null ? "" : team.optString("abbreviation", team.optString("teamCode", ""));
                Player known = playerById(id);
                if (known != null) {
                    if (name.isEmpty()) name = known.fullName;
                    if (teamName.isEmpty()) teamName = known.teamName;
                    if (teamAbbr.isEmpty()) teamAbbr = known.teamAbbr;
                }
                Stats s = pitching ? statsFromPitchingJson(stat) : statsFromHittingJson(stat);
                if (id > 0 && !name.isEmpty() && (s.pa > 0 || s.bbe > 0 || s.ip > 0 || s.anyValue())) out.add(new LeaderboardEntry(id, name, teamName, teamAbbr, s));
            }
        } catch (Exception ignored) {}
        return out;
    }

    private Stats statsFromHittingJson(JSONObject stat) {
        Stats s = new Stats();
        s.pa = intFromJson(stat, "plateAppearances");
        s.bbe = Math.max(1, intFromJson(stat, "atBats") - intFromJson(stat, "strikeOuts") + intFromJson(stat, "sacFlies"));
        s.put("avg", num(stat.optString("avg", "")));
        s.put("obp", num(stat.optString("obp", "")));
        s.put("slg", num(stat.optString("slg", "")));
        s.put("ops", num(stat.optString("ops", "")));
        s.put("hr", (double) intFromJson(stat, "homeRuns"));
        s.put("rbi", (double) intFromJson(stat, "rbi"));
        s.put("r", (double) intFromJson(stat, "runs"));
        s.put("sb", (double) intFromJson(stat, "stolenBases"));
        return s;
    }

    private Stats statsFromPitchingJson(JSONObject stat) {
        Stats s = new Stats();
        s.ip = inningsToDouble(stat.optString("inningsPitched", "0"));
        s.pa = intFromJson(stat, "battersFaced");
        s.bbe = (int) Math.round(s.ip * 3.0);
        s.put("era", num(stat.optString("era", "")));
        s.put("whip", num(stat.optString("whip", "")));
        s.put("k9", num(stat.optString("strikeoutsPer9Inn", "")));
        s.put("bb9", num(stat.optString("walksPer9Inn", "")));
        s.put("kbb", num(stat.optString("strikeoutWalkRatio", "")));
        s.put("pitchK", (double) intFromJson(stat, "strikeOuts"));
        s.put("pitchBB", (double) intFromJson(stat, "baseOnBalls"));
        s.put("saves", (double) intFromJson(stat, "saves"));
        s.put("ip", s.ip);
        return s;
    }

    private int intFromJson(JSONObject obj, String key) {
        try { return Integer.parseInt(obj.optString(key, "0").replace(",", "")); } catch (Exception e) { return obj.optInt(key, 0); }
    }

    private double inningsToDouble(String ipText) {
        try {
            String[] parts = safe(ipText).split("\\.");
            double whole = parts.length > 0 && !parts[0].isEmpty() ? Double.parseDouble(parts[0]) : 0;
            double outs = parts.length > 1 && !parts[1].isEmpty() ? Double.parseDouble(parts[1]) : 0;
            return whole + outs / 3.0;
        } catch (Exception e) { return 0; }
    }

    private void mergeStandardStatsIntoEntries(ArrayList<LeaderboardEntry> entries, ArrayList<LeaderboardEntry> standard) {
        LinkedHashMap<Integer, LeaderboardEntry> byId = new LinkedHashMap<>();
        for (LeaderboardEntry e : entries) if (e.playerId > 0) byId.put(e.playerId, e);
        for (LeaderboardEntry std : standard) {
            LeaderboardEntry existing = byId.get(std.playerId);
            if (existing != null) existing.stats.mergeFrom(std.stats);
            else {
                entries.add(std);
                if (std.playerId > 0) byId.put(std.playerId, std);
            }
        }
    }

    private Stats computeLeagueAverage(ArrayList<LeaderboardEntry> entries) {
        WeightedStatsBuilder b = new WeightedStatsBuilder(metrics);
        for (LeaderboardEntry e : entries) b.add(e.stats);
        return b.build();
    }

    private LinkedHashMap<Integer, Stats> fetchPlayerRecentSeasonStats(Player player, int throughSeason) {
        LinkedHashMap<Integer, Stats> out = new LinkedHashMap<>();
        int first = Math.max(STATCAST_START_YEAR, throughSeason - 3);
        for (int y = throughSeason; y >= first; y--) {
            try {
                LeaderboardEntry e = findPlayerEntry(fetchLeaderboardForPlayer(player, y), player);
                if (e != null && e.stats != null && e.stats.anyValue()) out.put(y, e.stats);
            } catch (Exception ignored) {}
        }
        return out;
    }

    private LinkedHashMap<Integer, Stats> fetchTeamRecentSeasonStats(Team team, int throughSeason) {
        LinkedHashMap<Integer, Stats> out = new LinkedHashMap<>();
        int first = Math.max(STATCAST_START_YEAR, throughSeason - 3);
        for (int y = throughSeason; y >= first; y--) {
            try {
                Stats s = aggregateTeamStats(fetchLeaderboardForSelectedMetrics(y)).get(team.key());
                if (s != null && s.anyValue()) out.put(y, s);
            } catch (Exception ignored) {}
        }
        return out;
    }

    private Stats fetchPlayerCareerStats(Player player, int throughSeason) {
        WeightedStatsBuilder b = new WeightedStatsBuilder(metrics, true);
        ExecutorService pool = Executors.newFixedThreadPool(6);
        ArrayList<Future<Stats>> futures = new ArrayList<>();
        for (int y = STATCAST_START_YEAR; y <= throughSeason; y++) {
            final int year = y;
            futures.add(pool.submit(() -> {
                try {
                    LeaderboardEntry e = findPlayerEntry(fetchLeaderboardForPlayer(player, year), player);
                    return e == null ? null : e.stats;
                } catch (Exception ignored) { return null; }
            }));
        }
        for (Future<Stats> f : futures) {
            try { b.add(f.get()); } catch (Exception ignored) {}
        }
        pool.shutdown();
        return b.build();
    }

    private Stats fetchTeamHistoryStats(Team team, int throughSeason) {
        WeightedStatsBuilder b = new WeightedStatsBuilder(metrics, true);
        ExecutorService pool = Executors.newFixedThreadPool(6);
        ArrayList<Future<Stats>> futures = new ArrayList<>();
        for (int y = STATCAST_START_YEAR; y <= throughSeason; y++) {
            final int year = y;
            futures.add(pool.submit(() -> {
                try { return aggregateTeamStats(fetchLeaderboardForSelectedMetrics(year)).get(team.key()); }
                catch (Exception ignored) { return null; }
            }));
        }
        for (Future<Stats> f : futures) {
            try { b.add(f.get()); } catch (Exception ignored) {}
        }
        pool.shutdown();
        return b.build();
    }

    private Map<String, Stats> aggregateTeamStats(ArrayList<LeaderboardEntry> entries) {
        LinkedHashMap<String, WeightedStatsBuilder> builders = new LinkedHashMap<>();
        for (LeaderboardEntry e : entries) {
            String key = teamKeyFromEntry(e);
            if (key.isEmpty()) continue;
            WeightedStatsBuilder b = builders.get(key);
            if (b == null) {
                b = new WeightedStatsBuilder(metrics, true);
                builders.put(key, b);
            }
            b.add(e.stats);
        }
        LinkedHashMap<String, Stats> out = new LinkedHashMap<>();
        for (Map.Entry<String, WeightedStatsBuilder> e : builders.entrySet()) out.put(e.getKey(), e.getValue().build());
        return out;
    }

    private LeaderboardEntry findPlayerEntry(ArrayList<LeaderboardEntry> entries, Player player) {
        for (LeaderboardEntry e : entries) if (e.playerId > 0 && e.playerId == player.id) return e;
        String target = normalizeNameKey(player.fullName);
        for (LeaderboardEntry e : entries) if (normalizeNameKey(e.name).equals(target)) return e;
        return null;
    }

    private Player playerById(int id) {
        for (Player p : allPlayers) if (p.id == id) return p;
        return null;
    }

    private String teamKeyFromEntry(LeaderboardEntry e) {
        String abbr = safe(e.teamAbbr).toUpperCase(Locale.US).trim();
        if (!abbr.isEmpty()) {
            for (Team t : allTeams) if (abbr.equals(t.abbr.toUpperCase(Locale.US))) return t.key();
        }
        String name = normalizeNameKey(e.teamName);
        if (!name.isEmpty()) {
            for (Team t : allTeams) if (normalizeNameKey(t.name).equals(name)) return t.key();
        }
        return abbr;
    }

    private void sortEntries(ArrayList<LeaderboardEntry> entries, Metric metric) {
        entries.sort((a, b) -> compareMetricValues(a.stats.get(metric.key), b.stats.get(metric.key), metric));
    }

    private int compareMetricValues(Double av, Double bv, Metric metric) {
        if (av == null && bv == null) return 0;
        if (av == null) return 1;
        if (bv == null) return -1;
        int cmp = Double.compare(bv, av); // default: high to low
        if (metric.higherGood != null && !metric.higherGood) cmp = Double.compare(av, bv);
        return cmp;
    }

    private View teamLogoView(Team team, int sizeDp) {
        TeamPalette palette = paletteForTeam(team);
        FrameLayout frame = new FrameLayout(this);
        frame.setPadding(dp(4), dp(4), dp(4), dp(4));
        frame.setBackground(roundedGradient(new int[] { softColor(palette.primary, 0.35f), softColor(palette.secondary, 0.55f) }, Math.max(14, sizeDp / 2)));

        ImageView logo = new ImageView(this);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        logo.setAdjustViewBounds(true);
        logo.setPadding(dp(2), dp(2), dp(2), dp(2));
        frame.addView(logo, new FrameLayout.LayoutParams(-1, -1));
        loadTeamLogo(team, logo);
        return frame;
    }

    private TextView teamBadge(String abbr, int sizeDp, int sp, TeamPalette palette) {
        // Kept only for older fallback references. Team logo surfaces now use a logo/shape without text.
        TextView badge = text("", sp, Color.WHITE, true);
        badge.setGravity(Gravity.CENTER);
        badge.setBackground(roundedGradient(new int[] { palette.primary, palette.secondary }, Math.max(12, sizeDp / 2)));
        return badge;
    }

    private void loadPlayerImage(int playerId, ImageView imageView) {
        if (playerId <= 0) return;
        imageView.setImageDrawable(rounded(Color.rgb(235, 241, 248), 24));
        loadPlayerImageBitmap(playerId, bitmap -> imageView.setImageBitmap(bitmap));
    }

    private void loadTeamLogo(Team team, ImageView imageView) {
        if (team == null || team.id <= 0) return;
        loadTeamLogoBitmap(team, bitmap -> imageView.setImageBitmap(bitmap));
    }

    private void loadPlayerImageBitmap(int playerId, BitmapCallback callback) {
        if (playerId <= 0 || callback == null) return;
        String[] urls = new String[] {
                "https://img.mlbstatic.com/mlb-photos/image/upload/w_120,q_auto:best/v1/people/" + playerId + "/headshot/current",
                "https://img.mlbstatic.com/mlb-photos/image/upload/w_120,d_people:generic:headshot:silo:current.png,q_auto:best/v1/people/" + playerId + "/headshot/67/current"
        };
        loadBitmapFromUrls(urls, callback);
    }

    private void loadTeamLogoBitmap(Team team, BitmapCallback callback) {
        if (team == null || callback == null) return;
        String code = espnTeamCode(team);
        ArrayList<String> urls = new ArrayList<>();
        if (!code.isEmpty()) {
            urls.add("https://a.espncdn.com/i/teamlogos/mlb/500/" + code + ".png");
            urls.add("https://a.espncdn.com/i/teamlogos/mlb/500-dark/" + code + ".png");
            urls.add("https://a.espncdn.com/i/teamlogos/mlb/500-light/" + code + ".png");
        }
        // If ESPN changes a code, the UI falls back to a team-colored shape without text instead of showing duplicate lettering.
        loadBitmapFromUrls(urls.toArray(new String[0]), callback);
    }

    private void loadBitmapFromUrls(String[] urls, BitmapCallback callback) {
        if (urls == null || urls.length == 0 || callback == null) return;
        for (String url : urls) {
            Bitmap cached = imageCache.get(url);
            if (cached != null) { callback.onBitmap(cached); return; }
        }
        String primary = urls[0];
        synchronized (imageWaiters) {
            ArrayList<BitmapCallback> waiters = imageWaiters.get(primary);
            if (waiters != null) { waiters.add(callback); return; }
            waiters = new ArrayList<>();
            waiters.add(callback);
            imageWaiters.put(primary, waiters);
        }
        io.execute(() -> {
            Bitmap bitmap = null;
            for (String url : urls) {
                if (url == null || url.isEmpty()) continue;
                try {
                    HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
                    conn.setConnectTimeout(7000);
                    conn.setReadTimeout(12000);
                    conn.setRequestProperty("User-Agent", "Mozilla/5.0 Statcast Compare Android");
                    Bitmap b = BitmapFactory.decodeStream(conn.getInputStream());
                    if (b != null) {
                        bitmap = b;
                        imageCache.put(url, b);
                        break;
                    }
                } catch (Exception ignored) {}
            }
            Bitmap finalBitmap = bitmap;
            ArrayList<BitmapCallback> callbacks;
            synchronized (imageWaiters) { callbacks = imageWaiters.remove(primary); }
            if (finalBitmap != null && callbacks != null) {
                main.post(() -> {
                    for (BitmapCallback cb : callbacks) cb.onBitmap(finalBitmap);
                });
            }
        });
    }

    private String espnTeamCode(Team team) {
        String abbr = team == null ? "" : safe(team.abbr).toUpperCase(Locale.US).replaceAll("[^A-Z]", "");
        String teamName = team == null ? "" : safe(team.name).toLowerCase(Locale.US);
        if (abbr.equals("ARI") || abbr.equals("AZ") || teamName.contains("diamondback")) return "ari";
        if (abbr.equals("ATL")) return "atl";
        if (abbr.equals("BAL")) return "bal";
        if (abbr.equals("BOS")) return "bos";
        if (abbr.equals("CHC")) return "chc";
        if (abbr.equals("CWS") || abbr.equals("CHW")) return "chw";
        if (abbr.equals("CIN")) return "cin";
        if (abbr.equals("CLE")) return "cle";
        if (abbr.equals("COL")) return "col";
        if (abbr.equals("DET")) return "det";
        if (abbr.equals("HOU")) return "hou";
        if (abbr.equals("KC") || abbr.equals("KCR")) return "kc";
        if (abbr.equals("LAA")) return "laa";
        if (abbr.equals("LAD")) return "lad";
        if (abbr.equals("MIA")) return "mia";
        if (abbr.equals("MIL")) return "mil";
        if (abbr.equals("MIN")) return "min";
        if (abbr.equals("NYM")) return "nym";
        if (abbr.equals("NYY")) return "nyy";
        if (abbr.equals("ATH") || abbr.equals("OAK")) return "ath";
        if (abbr.equals("PHI")) return "phi";
        if (abbr.equals("PIT")) return "pit";
        if (abbr.equals("SD") || abbr.equals("SDP")) return "sd";
        if (abbr.equals("SF") || abbr.equals("SFG")) return "sf";
        if (abbr.equals("SEA")) return "sea";
        if (abbr.equals("STL")) return "stl";
        if (abbr.equals("TB") || abbr.equals("TBR")) return "tb";
        if (abbr.equals("TEX")) return "tex";
        if (abbr.equals("TOR")) return "tor";
        if (abbr.equals("WSH") || abbr.equals("WSN")) return "wsh";
        return abbr.toLowerCase(Locale.US);
    }

    private TeamPalette paletteForComparison(Comparison c) {
        if (c == null) return defaultPalette();
        if (c.isTeam) return paletteForTeam(c.team);
        String abbr = c.player == null ? "" : c.player.teamAbbr;
        return paletteForAbbr(abbr);
    }

    private TeamPalette paletteForTeam(Team team) {
        return paletteForAbbr(team == null ? "" : team.abbr);
    }

    private TeamPalette paletteForAbbr(String rawAbbr) {
        String a = safe(rawAbbr).toUpperCase(Locale.US).replaceAll("[^A-Z]", "");
        if (a.equals("ARI") || a.equals("AZ")) return new TeamPalette(Color.rgb(167, 25, 48), Color.rgb(48, 108, 146));
        if (a.equals("ATL")) return new TeamPalette(Color.rgb(19, 39, 79), Color.rgb(206, 17, 65));
        if (a.equals("BAL")) return new TeamPalette(Color.rgb(223, 70, 1), Color.rgb(39, 37, 31));
        if (a.equals("BOS")) return new TeamPalette(Color.rgb(189, 48, 57), Color.rgb(12, 35, 64));
        if (a.equals("CHC")) return new TeamPalette(Color.rgb(14, 51, 134), Color.rgb(204, 52, 51));
        if (a.equals("CWS") || a.equals("CHW")) return new TeamPalette(Color.rgb(39, 37, 31), Color.rgb(196, 206, 212));
        if (a.equals("CIN")) return new TeamPalette(Color.rgb(198, 1, 31), Color.rgb(20, 20, 20));
        if (a.equals("CLE")) return new TeamPalette(Color.rgb(0, 43, 92), Color.rgb(229, 24, 55));
        if (a.equals("COL")) return new TeamPalette(Color.rgb(51, 0, 111), Color.rgb(196, 206, 212));
        if (a.equals("DET")) return new TeamPalette(Color.rgb(12, 35, 64), Color.rgb(250, 70, 22));
        if (a.equals("HOU")) return new TeamPalette(Color.rgb(0, 45, 98), Color.rgb(235, 110, 31));
        if (a.equals("KC") || a.equals("KCR")) return new TeamPalette(Color.rgb(0, 70, 135), Color.rgb(189, 155, 96));
        if (a.equals("LAA")) return new TeamPalette(Color.rgb(186, 0, 33), Color.rgb(0, 50, 99));
        if (a.equals("LAD")) return new TeamPalette(Color.rgb(0, 90, 156), Color.rgb(239, 62, 66));
        if (a.equals("MIA")) return new TeamPalette(Color.rgb(0, 163, 224), Color.rgb(239, 51, 64));
        if (a.equals("MIL")) return new TeamPalette(Color.rgb(18, 40, 75), Color.rgb(255, 197, 47));
        if (a.equals("MIN")) return new TeamPalette(Color.rgb(0, 43, 92), Color.rgb(211, 17, 69));
        if (a.equals("NYM")) return new TeamPalette(Color.rgb(0, 45, 114), Color.rgb(255, 89, 16));
        if (a.equals("NYY")) return new TeamPalette(Color.rgb(12, 35, 64), Color.rgb(196, 206, 212));
        if (a.equals("ATH") || a.equals("OAK")) return new TeamPalette(Color.rgb(0, 56, 49), Color.rgb(239, 178, 30));
        if (a.equals("PHI")) return new TeamPalette(Color.rgb(232, 24, 40), Color.rgb(0, 45, 114));
        if (a.equals("PIT")) return new TeamPalette(Color.rgb(39, 37, 31), Color.rgb(253, 184, 39));
        if (a.equals("SD") || a.equals("SDP")) return new TeamPalette(Color.rgb(47, 36, 29), Color.rgb(255, 196, 37));
        if (a.equals("SF") || a.equals("SFG")) return new TeamPalette(Color.rgb(253, 90, 30), Color.rgb(39, 37, 31));
        if (a.equals("SEA")) return new TeamPalette(Color.rgb(0, 92, 92), Color.rgb(12, 44, 86));
        if (a.equals("STL")) return new TeamPalette(Color.rgb(196, 30, 58), Color.rgb(12, 35, 64));
        if (a.equals("TB") || a.equals("TBR")) return new TeamPalette(Color.rgb(9, 44, 92), Color.rgb(143, 188, 230));
        if (a.equals("TEX")) return new TeamPalette(Color.rgb(0, 50, 120), Color.rgb(192, 17, 31));
        if (a.equals("TOR")) return new TeamPalette(Color.rgb(19, 74, 142), Color.rgb(232, 41, 28));
        if (a.equals("WSH") || a.equals("WSN")) return new TeamPalette(Color.rgb(171, 0, 3), Color.rgb(20, 34, 90));
        return defaultPalette();
    }

    private TeamPalette defaultPalette() { return new TeamPalette(NAVY, TEAL_DARK); }

    private int softColor(int color, float amountWhite) {
        int r = Math.round(Color.red(color) * (1f - amountWhite) + 255 * amountWhite);
        int g = Math.round(Color.green(color) * (1f - amountWhite) + 255 * amountWhite);
        int b = Math.round(Color.blue(color) * (1f - amountWhite) + 255 * amountWhite);
        return Color.rgb(r, g, b);
    }

    private String initials(String value) {
        String cleaned = safe(value).replaceAll("[^A-Za-z0-9 ]", " ").trim();
        if (cleaned.isEmpty()) return "•";
        String[] parts = cleaned.split("\\s+");
        if (parts.length == 1) return parts[0].substring(0, Math.min(2, parts[0].length())).toUpperCase(Locale.US);
        return (parts[0].substring(0, 1) + parts[parts.length - 1].substring(0, 1)).toUpperCase(Locale.US);
    }

    private String httpGet(String urlString) throws Exception {
        String cached = textCache.get(urlString);
        if (cached != null) return cached;

        SharedPreferences prefs = getSharedPreferences("statcast_http_cache_v15", MODE_PRIVATE);
        String key = "url_" + Integer.toHexString(urlString.hashCode());
        long now = System.currentTimeMillis();
        long ttl = cacheTtlMs(urlString);
        String diskText = prefs.getString(key, null);
        long diskTime = prefs.getLong(key + "_time", 0L);
        if (diskText != null && now - diskTime < ttl) {
            textCache.put(urlString, diskText);
            return diskText;
        }

        HttpURLConnection conn = (HttpURLConnection) new URL(urlString).openConnection();
        conn.setConnectTimeout(12000);
        conn.setReadTimeout(25000);
        conn.setRequestMethod("GET");
        conn.setRequestProperty("User-Agent", "Mozilla/5.0 Statcast Compare Android");
        conn.setRequestProperty("Accept", "text/csv,text/plain,application/json,text/html,*/*");
        int code = conn.getResponseCode();
        InputStream stream = code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream();
        BufferedReader br = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line).append('\n');
        String text = sb.toString();
        if (code < 200 || code >= 300) throw new Exception("HTTP " + code);
        textCache.put(urlString, text);
        prefs.edit().putString(key, text).putLong(key + "_time", now).apply();
        return text;
    }

    private long cacheTtlMs(String urlString) {
        int currentYear = Calendar.getInstance().get(Calendar.YEAR);
        String currentYearText = "year=" + currentYear;
        if (urlString.contains("/roster/") || urlString.contains("/sports/1/players") || urlString.contains("/teams?")) return 12L * 60L * 60L * 1000L;
        if (urlString.contains(currentYearText)) return 6L * 60L * 60L * 1000L;
        return 21L * 24L * 60L * 60L * 1000L;
    }

    // CSV/format helpers -----------------------------------------------------------------------

    private List<Map<String, String>> parseCsv(String text) {
        ArrayList<ArrayList<String>> rows = new ArrayList<>();
        ArrayList<String> row = new ArrayList<>();
        StringBuilder field = new StringBuilder();
        boolean inQuotes = false;
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            char next = i + 1 < text.length() ? text.charAt(i + 1) : '\0';
            if (c == '"') {
                if (inQuotes && next == '"') { field.append('"'); i++; }
                else inQuotes = !inQuotes;
            } else if (c == ',' && !inQuotes) {
                row.add(field.toString()); field.setLength(0);
            } else if ((c == '\n' || c == '\r') && !inQuotes) {
                if (c == '\r' && next == '\n') i++;
                row.add(field.toString()); field.setLength(0);
                boolean nonEmpty = false; for (String v : row) if (!v.isEmpty()) { nonEmpty = true; break; }
                if (nonEmpty) rows.add(row);
                row = new ArrayList<>();
            } else field.append(c);
        }
        if (field.length() > 0 || !row.isEmpty()) {
            row.add(field.toString());
            rows.add(row);
        }
        ArrayList<Map<String, String>> out = new ArrayList<>();
        if (rows.size() < 2) return out;
        ArrayList<String> headers = rows.get(0);
        for (int r = 1; r < rows.size(); r++) {
            HashMap<String, String> map = new HashMap<>();
            ArrayList<String> vals = rows.get(r);
            for (int h = 0; h < headers.size(); h++) map.put(headers.get(h).trim(), h < vals.size() ? vals.get(h) : "");
            out.add(map);
        }
        return out;
    }

    private String toQuery(LinkedHashMap<String, String> params) throws Exception {
        StringBuilder sb = new StringBuilder("?");
        boolean first = true;
        for (Map.Entry<String, String> e : params.entrySet()) {
            if (!first) sb.append('&');
            sb.append(enc(e.getKey())).append('=').append(enc(e.getValue()));
            first = false;
        }
        return sb.toString();
    }

    private String enc(String s) throws Exception { return URLEncoder.encode(s == null ? "" : s, "UTF-8"); }
    private String safe(String s) { return s == null ? "" : s; }
    private Double pick(Map<String, String> row, String... names) {
        for (String n : names) if (row.containsKey(n)) return num(row.get(n));
        HashMap<String, String> lowerMap = new HashMap<>();
        for (String k : row.keySet()) lowerMap.put(k.toLowerCase(Locale.US).replaceAll("[^a-z0-9]", ""), k);
        for (String n : names) {
            String k = lowerMap.get(n.toLowerCase(Locale.US).replaceAll("[^a-z0-9]", ""));
            if (k != null) return num(row.get(k));
        }
        return null;
    }
    private String pickString(Map<String, String> row, String... names) {
        for (String n : names) if (row.containsKey(n) && row.get(n) != null && !row.get(n).trim().isEmpty()) return row.get(n).trim();
        HashMap<String, String> lowerMap = new HashMap<>();
        for (String k : row.keySet()) lowerMap.put(k.toLowerCase(Locale.US).replaceAll("[^a-z0-9]", ""), k);
        for (String n : names) {
            String k = lowerMap.get(n.toLowerCase(Locale.US).replaceAll("[^a-z0-9]", ""));
            if (k != null && row.get(k) != null && !row.get(k).trim().isEmpty()) return row.get(k).trim();
        }
        return "";
    }
    private String buildNameFromColumns(Map<String, String> row) {
        String first = pickString(row, "first_name", "first name");
        String last = pickString(row, "last_name", "last name");
        return (first + " " + last).trim();
    }
    private String normalizePlayerName(String name) {
        String n = safe(name).trim();
        if (n.contains(",")) {
            String[] parts = n.split(",");
            if (parts.length >= 2) n = parts[1].trim() + " " + parts[0].trim();
        }
        return n.replaceAll("\\s+", " ").trim();
    }
    private String normalizeNameKey(String value) {
        return safe(value).toLowerCase(Locale.US).replaceAll("[^a-z0-9]", "");
    }
    private Double num(String value) {
        if (value == null) return null;
        String cleaned = value.replace("%", "").replace(",", "").trim();
        if (cleaned.isEmpty() || cleaned.equals("-")) return null;
        try { return Double.parseDouble(cleaned); } catch (Exception e) { return null; }
    }
    private int intVal(Double d) { return d == null || Double.isNaN(d) ? 0 : (int) Math.round(d); }
    private Double diff(Double a, Double b) { return a == null || b == null ? null : a - b; }
    private String fmtCount(int v) { return String.format(Locale.US, "%,d", v); }

    private String statLineSummary(Stats s) {
        if (s == null) return "—";
        if (s.ip > 0 && (s.get("era") != null || s.get("whip") != null)) return new DecimalFormat("0.0").format(s.ip) + " IP" + (s.pa > 0 ? " · " + fmtCount(s.pa) + " BF" : "");
        return fmtCount(s.pa) + " PA · " + fmtCount(s.bbe) + " BBE";
    }

    private String format(Double v, Metric m) {
        if (v == null || Double.isNaN(v)) return "—";
        String pattern = m.decimals <= 0 ? "0" : (m.decimals == 1 ? "0.0" : (m.decimals == 2 ? "0.00" : "0.000"));
        DecimalFormat df = new DecimalFormat(pattern);
        return df.format(v) + m.unit;
    }
    private String signedFormat(Double v, Metric m) {
        if (v == null || Double.isNaN(v)) return "—";
        return (v > 0 ? "+" : "") + format(v, m);
    }
    private double[] scaleValues(Double[] values, Metric m) {
        ArrayList<Double> valid = new ArrayList<>();
        for (Double v : values) if (v != null && !Double.isNaN(v)) valid.add(v);
        double[] out = new double[values.length];
        if (valid.isEmpty()) return out;
        double[] domain = metricScaleDomain(m, values);
        double lo = domain[0], hi = domain[1];
        if (hi <= lo) { lo -= 1; hi += 1; }
        for (int i = 0; i < values.length; i++) {
            Double v = values[i];
            if (v == null || Double.isNaN(v)) out[i] = 0;
            else out[i] = Math.max(7, Math.min(100, ((v - lo) / (hi - lo)) * 100));
        }
        return out;
    }

    private double[] metricScaleDomain(Metric m, Double[] values) {
        ArrayList<Double> valid = new ArrayList<>();
        for (Double v : values) if (v != null && !Double.isNaN(v)) valid.add(v);
        if (valid.isEmpty()) return new double[] {0, 1};

        double min = Collections.min(valid);
        double max = Collections.max(valid);
        double lo;
        double hi;

        switch (m.key) {
            case "avg":
            case "xBA":
                lo = 0.180; hi = 0.360; break;
            case "obp":
                lo = 0.240; hi = 0.460; break;
            case "slg":
            case "xSLG":
                lo = 0.280; hi = 0.700; break;
            case "ops":
                lo = 0.500; hi = 1.100; break;
            case "wOBA":
            case "xwOBA":
                lo = 0.240; hi = 0.460; break;
            case "luck":
                lo = -0.060; hi = 0.060; break;
            case "avgEV":
                lo = 82.0; hi = 98.0; break;
            case "avgLA":
                lo = -10.0; hi = 35.0; break;
            case "hardHitPct":
                lo = 20.0; hi = 65.0; break;
            case "barrelPct":
                lo = 0.0; hi = 25.0; break;
            case "sweetSpotPct":
                lo = 20.0; hi = 45.0; break;
            case "kPct":
                lo = 5.0; hi = 40.0; break;
            case "bbPct":
                lo = 2.0; hi = 20.0; break;
            case "era":
                lo = 1.50; hi = 7.50; break;
            case "whip":
                lo = 0.80; hi = 1.80; break;
            case "k9":
                lo = 5.0; hi = 14.0; break;
            case "bb9":
                lo = 1.0; hi = 6.0; break;
            case "kbb":
                lo = 1.0; hi = 8.0; break;
            case "ip":
                lo = 0.0; hi = max > 400 ? 1600.0 : 220.0; break;
            case "hr":
                lo = 0.0; hi = max > 120 ? 320.0 : 60.0; break;
            case "rbi":
            case "r":
                lo = 0.0; hi = max > 200 ? 950.0 : 150.0; break;
            case "sb":
                lo = 0.0; hi = max > 120 ? 220.0 : 80.0; break;
            case "pitchK":
                lo = 0.0; hi = max > 400 ? 1600.0 : 320.0; break;
            case "pitchBB":
                lo = 0.0; hi = max > 180 ? 700.0 : 110.0; break;
            case "saves":
                lo = 0.0; hi = max > 90 ? 90.0 : 55.0; break;
            default:
                if (m.isCount()) {
                    lo = 0.0;
                    hi = Math.max(10.0, max * 1.18);
                } else if ("expected".equals(m.type)) {
                    lo = min - 0.010; hi = max + 0.010;
                } else if ("rate".equals(m.type)) {
                    lo = min - 1.5; hi = max + 1.5;
                } else {
                    lo = min - 0.5; hi = max + 0.5;
                }
                break;
        }

        double span = hi - lo;
        double extra = Math.max(span * 0.04, m.isCount() ? 1.0 : ("luck".equals(m.key) ? 0.003 : 0.0));
        lo = Math.min(lo, min - extra);
        hi = Math.max(hi, max + extra);

        if ("luck".equals(m.key)) {
            double abs = Math.max(Math.abs(lo), Math.abs(hi));
            lo = -abs;
            hi = abs;
        }

        return new double[] { lo, hi };
    }


    private void drawBitmapFitCenter(Canvas canvas, Bitmap bitmap, RectF box, boolean roundedClip, float cornerRadius) {
        if (bitmap == null || bitmap.getWidth() <= 0 || bitmap.getHeight() <= 0) return;
        float bw = bitmap.getWidth();
        float bh = bitmap.getHeight();
        float scale = Math.min(box.width() / bw, box.height() / bh);
        float w = bw * scale;
        float h = bh * scale;
        Rect src = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());
        RectF dst = new RectF(box.centerX() - w / 2f, box.centerY() - h / 2f, box.centerX() + w / 2f, box.centerY() + h / 2f);
        if (roundedClip) {
            Path clip = new Path();
            clip.addRoundRect(box, cornerRadius, cornerRadius, Path.Direction.CW);
            int save = canvas.save();
            canvas.clipPath(clip);
            canvas.drawBitmap(bitmap, src, dst, paintForBitmap());
            canvas.restoreToCount(save);
        } else {
            canvas.drawBitmap(bitmap, src, dst, paintForBitmap());
        }
    }

    private Paint paintForBitmap() {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG | Paint.DITHER_FLAG);
        p.setStyle(Paint.Style.FILL);
        return p;
    }


    class PercentileMiniBarView extends View {
        final int color;
        final Double pct;
        final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        PercentileMiniBarView(Context context, int color, Double pct) {
            super(context);
            this.color = color;
            this.pct = pct;
        }
        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float left = 0, right = getWidth(), midY = getHeight() / 2f;
            RectF track = new RectF(left, midY - dp(3), right, midY + dp(3));
            paint.setStyle(Paint.Style.FILL);
            paint.setShader(null);
            paint.setColor(Color.rgb(228, 235, 245));
            canvas.drawRoundRect(track, dp(8), dp(8), paint);
            if (pct != null && !Double.isNaN(pct)) {
                float x = (float) (left + (Math.max(0, Math.min(100, pct)) / 100.0) * (right - left));
                RectF fill = new RectF(left, track.top, x, track.bottom);
                paint.setColor(color);
                canvas.drawRoundRect(fill, dp(8), dp(8), paint);
                paint.setColor(Color.WHITE);
                canvas.drawCircle(x, midY, dp(4), paint);
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(dp(2));
                paint.setColor(color);
                canvas.drawCircle(x, midY, dp(4), paint);
                paint.setStyle(Paint.Style.FILL);
            }
        }
    }

    class ExpectedActualBarView extends View {
        final Metric metric;
        final Double actual, expected, actualPct, expectedPct;
        final TeamPalette palette;
        final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        ExpectedActualBarView(Context context, Metric metric, Double actual, Double expected, Double actualPct, Double expectedPct, TeamPalette palette) {
            super(context);
            this.metric = metric;
            this.actual = actual;
            this.expected = expected;
            this.actualPct = actualPct;
            this.expectedPct = expectedPct;
            this.palette = palette == null ? defaultPalette() : palette;
        }
        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float left = dp(18);
            float right = getWidth() - dp(18);
            float y = dp(20);
            float h = dp(10);
            RectF track = new RectF(left, y, right, y + h);
            paint.setStyle(Paint.Style.FILL);
            paint.setShader(null);
            paint.setColor(Color.rgb(229, 235, 245));
            canvas.drawRoundRect(track, dp(10), dp(10), paint);
            paint.setColor(softColor(palette.primary, 0.78f));
            canvas.drawRoundRect(track, dp(10), dp(10), paint);
            drawPercentTick(canvas, left, y + h + dp(14), "0%");
            drawPercentTick(canvas, left + (right - left) / 2f, y + h + dp(14), "50%");
            drawPercentTick(canvas, right, y + h + dp(14), "100%");

            float actualX = markerX(actual, actualPct, left, right);
            float expectedX = markerX(expected, expectedPct, left, right);
            if (actualX >= 0 && expectedX >= 0) {
                paint.setStrokeWidth(dp(3));
                paint.setColor(Color.argb(150, 42, 47, 61));
                canvas.drawLine(actualX, y + h / 2f, expectedX, y + h / 2f, paint);
            }
            if (expectedX >= 0) drawMarker(canvas, expectedX, y + h / 2f, palette.secondary, "x");
            if (actualX >= 0) drawMarker(canvas, actualX, y + h / 2f, palette.primary, "A");
        }
        private float markerX(Double value, Double pct, float left, float right) {
            if (pct != null && !Double.isNaN(pct)) return (float) (left + (Math.max(0, Math.min(100, pct)) / 100.0) * (right - left));
            if (value == null || Double.isNaN(value)) return -1;
            double[] domain = metricScaleDomain(metric, new Double[] { actual, expected });
            double lo = domain[0], hi = domain[1];
            if (hi <= lo) return -1;
            return (float) Math.max(left + dp(10), Math.min(right - dp(10), left + ((value - lo) / (hi - lo)) * (right - left)));
        }
        private void drawPercentTick(Canvas canvas, float x, float y, String label) {
            paint.setShader(null);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.rgb(112, 123, 142));
            paint.setTextAlign(Paint.Align.CENTER);
            paint.setTextSize(dp(8));
            paint.setTypeface(Typeface.DEFAULT_BOLD);
            canvas.drawText(label, x, y, paint);
        }
        private void drawMarker(Canvas canvas, float cx, float cy, int color, String label) {
            paint.setShader(null);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.WHITE);
            canvas.drawCircle(cx, cy, dp(13), paint);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dp(3));
            paint.setColor(color);
            canvas.drawCircle(cx, cy, dp(12), paint);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(color);
            paint.setTextAlign(Paint.Align.CENTER);
            paint.setTextSize(dp(10));
            paint.setTypeface(Typeface.DEFAULT_BOLD);
            canvas.drawText(label, cx, cy + dp(4), paint);
        }
    }


    class HeadToHeadBarView extends View {
        final Metric metric;
        final Double[] values;
        final Double[] percentiles;
        final TeamPalette paletteA;
        final TeamPalette paletteB;
        final String labelA;
        final String labelB;
        Bitmap iconA;
        Bitmap iconB;
        final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

        HeadToHeadBarView(Context context, Metric metric, Double[] values, Double[] percentiles, TeamPalette paletteA, TeamPalette paletteB, String labelA, String labelB) {
            super(context);
            this.metric = metric;
            this.values = values;
            this.percentiles = percentiles;
            this.paletteA = paletteA == null ? defaultPalette() : paletteA;
            this.paletteB = paletteB == null ? defaultPalette() : paletteB;
            this.labelA = labelA == null ? "A" : labelA;
            this.labelB = labelB == null ? "B" : labelB;
        }

        void setIconA(Bitmap bitmap) { this.iconA = bitmap; invalidate(); }
        void setIconB(Bitmap bitmap) { this.iconB = bitmap; invalidate(); }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            ArrayList<Double> valid = new ArrayList<>();
            for (Double v : values) if (v != null && !Double.isNaN(v)) valid.add(v);
            if (valid.isEmpty()) return;

            double[] domain = metricScaleDomain(metric, values);
            double lo = domain[0];
            double hi = domain[1];
            if (hi <= lo) { lo -= 1; hi += 1; }

            float left = dp(18);
            float right = getWidth() - dp(18);
            float y = dp(22);
            float h = dp(10);
            RectF track = new RectF(left, y, right, y + h);

            paint.setStyle(Paint.Style.FILL);
            paint.setShader(null);
            paint.setColor(Color.rgb(229, 235, 245));
            canvas.drawRoundRect(track, dp(10), dp(10), paint);
            LinearGradient gradient = new LinearGradient(left, y, right, y + h,
                    new int[] { softColor(paletteA.primary, 0.18f), softColor(Color.rgb(70, 88, 125), 0.18f), softColor(paletteB.primary, 0.18f) },
                    new float[] { 0f, 0.50f, 1f }, Shader.TileMode.CLAMP);
            paint.setShader(gradient);
            canvas.drawRoundRect(track, dp(10), dp(10), paint);
            paint.setShader(null);

            paint.setColor(Color.argb(105, 255, 255, 255));
            for (int i = 1; i < 4; i++) {
                float gx = left + (right - left) * i / 4f;
                canvas.drawRoundRect(new RectF(gx - dp(1), y - dp(3), gx + dp(1), y + h + dp(3)), dp(1), dp(1), paint);
            }

            if (lo < 0 && hi > 0 && metric.key.equals("luck")) {
                float zx = (float) (left + ((0 - lo) / (hi - lo)) * (right - left));
                paint.setColor(Color.argb(200, 45, 54, 74));
                canvas.drawRoundRect(new RectF(zx - dp(1), y - dp(8), zx + dp(1), y + h + dp(8)), dp(2), dp(2), paint);
            }

            drawPercentileScale(canvas, left, right, y + h + dp(16));

            float[] xs = new float[values.length];
            for (int i = 0; i < values.length; i++) {
                Double v = values[i];
                if (v == null || Double.isNaN(v)) { xs[i] = -1; continue; }
                float x;
                if (percentiles != null && i < percentiles.length && percentiles[i] != null && !Double.isNaN(percentiles[i])) {
                    x = (float) (left + (Math.max(0, Math.min(100, percentiles[i])) / 100.0) * (right - left));
                } else {
                    x = (float) (left + ((v - lo) / (hi - lo)) * (right - left));
                }
                xs[i] = Math.max(left + dp(14), Math.min(right - dp(14), x));
            }

            if (xs.length > 2 && xs[2] >= 0) drawLeagueMarker(canvas, xs[2], y + h / 2);
            if (xs.length > 0 && xs[0] >= 0) drawSideMarker(canvas, xs[0], y + h / 2, iconA, paletteA, labelA, true);
            if (xs.length > 1 && xs[1] >= 0) drawSideMarker(canvas, xs[1], y + h / 2, iconB, paletteB, labelB, false);
        }

        private void drawPercentileScale(Canvas canvas, float left, float right, float baseline) {
            paint.setShader(null);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.rgb(112, 123, 142));
            paint.setTextSize(dp(8));
            paint.setTypeface(Typeface.DEFAULT_BOLD);
            paint.setTextAlign(Paint.Align.LEFT);
            canvas.drawText("0%", left, baseline, paint);
            paint.setTextAlign(Paint.Align.CENTER);
            canvas.drawText("50%", (left + right) / 2f, baseline, paint);
            paint.setTextAlign(Paint.Align.RIGHT);
            canvas.drawText("100%", right, baseline, paint);
        }

        private void drawSideMarker(Canvas canvas, float cx, float cy, Bitmap icon, TeamPalette palette, String label, boolean leftSide) {
            float w = dp(32), h = dp(28);
            RectF outer = new RectF(cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2);
            paint.setShader(null);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.WHITE);
            canvas.drawRoundRect(outer, dp(9), dp(9), paint);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dp(2));
            paint.setColor(palette.primary);
            canvas.drawRoundRect(outer, dp(9), dp(9), paint);
            paint.setStyle(Paint.Style.FILL);
            RectF inner = new RectF(outer.left + dp(3), outer.top + dp(3), outer.right - dp(3), outer.bottom - dp(3));
            if (icon != null) {
                drawBitmapFitCenter(canvas, icon, inner, true, dp(6));
            } else {
                paint.setColor(palette.primary);
                canvas.drawRoundRect(inner, dp(6), dp(6), paint);
                paint.setColor(Color.WHITE);
                paint.setTextAlign(Paint.Align.CENTER);
                paint.setTextSize(dp(8));
                paint.setTypeface(Typeface.DEFAULT_BOLD);
                canvas.drawText(leftSide ? "A" : "B", inner.centerX(), inner.centerY() + dp(3), paint);
            }
        }

        private void drawLeagueMarker(Canvas canvas, float cx, float cy) {
            float w = dp(31), h = dp(18);
            RectF pill = new RectF(cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2);
            paint.setShader(null);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.WHITE);
            canvas.drawRoundRect(new RectF(pill.left - dp(2), pill.top - dp(2), pill.right + dp(2), pill.bottom + dp(2)), dp(10), dp(10), paint);
            LinearGradient lg = new LinearGradient(pill.left, pill.top, pill.right, pill.bottom,
                    new int[] { Color.rgb(21, 53, 97), Color.rgb(198, 45, 58) }, null, Shader.TileMode.CLAMP);
            paint.setShader(lg);
            canvas.drawRoundRect(pill, dp(10), dp(10), paint);
            paint.setShader(null);
            paint.setColor(Color.WHITE);
            paint.setTextAlign(Paint.Align.CENTER);
            paint.setTextSize(dp(7));
            paint.setTypeface(Typeface.DEFAULT_BOLD);
            canvas.drawText("MLB", cx, cy + dp(3), paint);
        }
    }

    class ComparisonBarView extends View {
        final Metric metric;
        final Double[] values;
        final Double[] percentiles;
        final String thirdLabel;
        final TeamPalette palette;
        final String currentLabel;
        Bitmap currentIcon;
        final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

        ComparisonBarView(Context context, Metric metric, Double[] values, Double[] percentiles, String thirdLabel, TeamPalette palette, String currentLabel) {
            super(context);
            this.metric = metric;
            this.values = values;
            this.percentiles = percentiles;
            this.thirdLabel = thirdLabel == null ? "Career" : thirdLabel;
            this.palette = palette == null ? defaultPalette() : palette;
            this.currentLabel = currentLabel == null ? "" : currentLabel;
        }

        void setCurrentIcon(Bitmap bitmap) {
            this.currentIcon = bitmap;
            invalidate();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            ArrayList<Double> valid = new ArrayList<>();
            for (Double v : values) if (v != null && !Double.isNaN(v)) valid.add(v);
            if (valid.isEmpty()) return;

            double[] domain = metricScaleDomain(metric, values);
            double lo = domain[0];
            double hi = domain[1];
            if (hi <= lo) { lo -= 1; hi += 1; }

            float left = dp(18);
            float right = getWidth() - dp(18);
            float y = dp(19);
            float h = dp(10);
            RectF track = new RectF(left, y, right, y + h);

            paint.setStyle(Paint.Style.FILL);
            paint.setShader(null);
            paint.setColor(Color.rgb(229, 235, 245));
            canvas.drawRoundRect(track, dp(10), dp(10), paint);

            LinearGradient gradient = new LinearGradient(left, y, right, y + h,
                    new int[] { softColor(palette.secondary, 0.28f), softColor(palette.primary, 0.10f), softColor(palette.secondary, 0.20f) },
                    new float[] { 0f, 0.55f, 1f }, Shader.TileMode.CLAMP);
            paint.setShader(gradient);
            canvas.drawRoundRect(track, dp(10), dp(10), paint);
            paint.setShader(null);

            paint.setColor(Color.argb(105, 255, 255, 255));
            for (int i = 1; i < 4; i++) {
                float gx = left + (right - left) * i / 4f;
                canvas.drawRoundRect(new RectF(gx - dp(1), y - dp(3), gx + dp(1), y + h + dp(3)), dp(1), dp(1), paint);
            }

            if (lo < 0 && hi > 0 && metric.key.equals("luck")) {
                float zx = (float) (left + ((0 - lo) / (hi - lo)) * (right - left));
                paint.setColor(Color.argb(210, 45, 54, 74));
                canvas.drawRoundRect(new RectF(zx - dp(1), y - dp(8), zx + dp(1), y + h + dp(8)), dp(2), dp(2), paint);
            }

            drawPercentileScale(canvas, left, right, y + h + dp(16));

            float[] xs = new float[values.length];
            for (int i = 0; i < values.length; i++) {
                Double v = values[i];
                if (v == null || Double.isNaN(v)) { xs[i] = -1; continue; }
                float x;
                if (percentiles != null && i < percentiles.length && percentiles[i] != null && !Double.isNaN(percentiles[i])) {
                    x = (float) (left + (Math.max(0, Math.min(100, percentiles[i])) / 100.0) * (right - left));
                } else {
                    x = (float) (left + ((v - lo) / (hi - lo)) * (right - left));
                }
                xs[i] = Math.max(left + dp(12), Math.min(right - dp(12), x));
            }

            if (xs.length > 1 && xs[1] >= 0) drawLeagueMarker(canvas, xs[1], y + h / 2);
            if (xs.length > 2 && xs[2] >= 0) drawCareerMarker(canvas, xs[2], y + h / 2);
            if (xs.length > 0 && xs[0] >= 0) drawCurrentMarker(canvas, xs[0], y + h / 2);
        }

        private void drawPercentileScale(Canvas canvas, float left, float right, float baseline) {
            paint.setShader(null);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.rgb(112, 123, 142));
            paint.setTextSize(dp(8));
            paint.setTypeface(Typeface.DEFAULT_BOLD);
            paint.setTextAlign(Paint.Align.LEFT);
            canvas.drawText("0%", left, baseline, paint);
            paint.setTextAlign(Paint.Align.CENTER);
            canvas.drawText("50%", (left + right) / 2f, baseline, paint);
            paint.setTextAlign(Paint.Align.RIGHT);
            canvas.drawText("100%", right, baseline, paint);
        }

        private void drawCurrentMarker(Canvas canvas, float cx, float cy) {
            float w = dp(30), h = dp(26);
            RectF outer = new RectF(cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2);
            paint.setShader(null);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.WHITE);
            canvas.drawRoundRect(outer, dp(9), dp(9), paint);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dp(2));
            paint.setColor(palette.primary);
            canvas.drawRoundRect(outer, dp(9), dp(9), paint);
            paint.setStyle(Paint.Style.FILL);
            RectF inner = new RectF(outer.left + dp(3), outer.top + dp(3), outer.right - dp(3), outer.bottom - dp(3));
            if (currentIcon != null) {
                drawBitmapFitCenter(canvas, currentIcon, inner, true, dp(6));
            } else {
                paint.setColor(palette.primary);
                canvas.drawRoundRect(inner, dp(6), dp(6), paint);
                paint.setColor(Color.WHITE);
                paint.setTextAlign(Paint.Align.CENTER);
                paint.setTextSize(dp(8));
                paint.setTypeface(Typeface.DEFAULT_BOLD);
                canvas.drawText(initials(currentLabel), inner.centerX(), inner.centerY() + dp(3), paint);
            }
        }

        private void drawLeagueMarker(Canvas canvas, float cx, float cy) {
            float w = dp(31), h = dp(18);
            RectF pill = new RectF(cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2);
            paint.setShader(null);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.WHITE);
            canvas.drawRoundRect(new RectF(pill.left - dp(2), pill.top - dp(2), pill.right + dp(2), pill.bottom + dp(2)), dp(10), dp(10), paint);
            LinearGradient lg = new LinearGradient(pill.left, pill.top, pill.right, pill.bottom,
                    new int[] { Color.rgb(21, 53, 97), Color.rgb(198, 45, 58) }, null, Shader.TileMode.CLAMP);
            paint.setShader(lg);
            canvas.drawRoundRect(pill, dp(10), dp(10), paint);
            paint.setShader(null);
            paint.setColor(Color.WHITE);
            paint.setTextAlign(Paint.Align.CENTER);
            paint.setTextSize(dp(7));
            paint.setTypeface(Typeface.DEFAULT_BOLD);
            canvas.drawText("MLB", cx, cy + dp(3), paint);
        }

        private void drawCareerMarker(Canvas canvas, float cx, float cy) {
            float r = dp(10);
            paint.setShader(null);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.WHITE);
            canvas.drawCircle(cx, cy, r + dp(2), paint);
            paint.setColor(softColor(palette.secondary, 0.05f));
            canvas.drawCircle(cx, cy, r + dp(1), paint);
            paint.setColor(Color.WHITE);
            canvas.drawCircle(cx, cy, r - dp(1), paint);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dp(2));
            paint.setColor(palette.secondary);
            canvas.drawCircle(cx, cy, r - dp(1), paint);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(palette.secondary);
            paint.setTextAlign(Paint.Align.CENTER);
            paint.setTextSize(dp(11));
            paint.setTypeface(Typeface.DEFAULT_BOLD);
            canvas.drawText(thirdLabel.equals("Hist") ? "H" : "★", cx, cy + dp(4), paint);
        }
    }


    class PlayerSuggestionAdapter extends BaseAdapter {
        final ArrayList<Player> data;
        PlayerSuggestionAdapter(ArrayList<Player> data) { this.data = data; }
        @Override public int getCount() { return data.size(); }
        @Override public Object getItem(int position) { return data.get(position); }
        @Override public long getItemId(int position) { return data.get(position).id; }
        @Override public View getView(int position, View convertView, android.view.ViewGroup parent) {
            Player p = data.get(position);
            LinearLayout row;
            if (convertView instanceof LinearLayout) row = (LinearLayout) convertView;
            else {
                row = new LinearLayout(MainActivity.this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(dp(9), dp(7), dp(9), dp(7));
            }
            row.removeAllViews();
            ImageView img = new ImageView(MainActivity.this);
            img.setScaleType(ImageView.ScaleType.FIT_CENTER);
            img.setBackground(roundedStroke(Color.rgb(235, 241, 248), LINE, 16, 1));
            LinearLayout.LayoutParams imgLp = new LinearLayout.LayoutParams(dp(36), dp(36));
            imgLp.setMargins(0, 0, dp(9), 0);
            row.addView(img, imgLp);
            loadPlayerImage(p.id, img);
            LinearLayout col = new LinearLayout(MainActivity.this);
            col.setOrientation(LinearLayout.VERTICAL);
            col.addView(text(p.fullName, 14, INK, true));
            col.addView(text(p.teamAbbr + " · " + p.position + (isPitcher(p) ? " · Pitcher" : " · Hitter"), 11, MUTED, false));
            row.addView(col, new LinearLayout.LayoutParams(0, -2, 1));
            TextView chip = text(isPitcher(p) ? "P" : "BAT", 10, isPitcher(p) ? NAVY : TEAL_DARK, true);
            chip.setGravity(Gravity.CENTER);
            chip.setPadding(dp(7), dp(3), dp(7), dp(3));
            chip.setBackground(roundedStroke(Color.WHITE, Color.rgb(218, 227, 239), 12, 1));
            row.addView(chip);
            return row;
        }
    }

    // UI helpers -------------------------------------------------------------------------------

    private boolean isBusy() {
        return loading != null && loading.getVisibility() == View.VISIBLE;
    }

    private void setBusy(boolean busy, String message) {
        loading.setVisibility(busy ? View.VISIBLE : View.GONE);
        compareButton.setEnabled(!busy);
        standingsButton.setEnabled(!busy);
        if (singleViewButton != null) singleViewButton.setEnabled(!busy);
        if (headToHeadButton != null) headToHeadButton.setEnabled(!busy);
        if (message != null) statusView.setText(message);
    }
    private void showError(String message) {
        errorView.setText(message == null ? "" : message);
        errorView.setVisibility(message == null || message.isEmpty() ? View.GONE : View.VISIBLE);
    }
    private void hideKeyboard() {
        try {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(searchInput.getWindowToken(), 0);
        } catch (Exception ignored) {}
    }
    private TextView text(String value, int sp, int color, boolean bold) {
        TextView tv = new TextView(this);
        tv.setText(value);
        tv.setTextSize(sp);
        tv.setTextColor(color);
        if (bold) tv.setTypeface(Typeface.DEFAULT_BOLD);
        return tv;
    }
    private LinearLayout verticalCard(int radius, int[] gradientColors) {
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.VERTICAL);
        v.setBackground(gradientColors == null ? rounded(CARD, radius) : roundedGradient(gradientColors, radius));
        v.setElevation(dp(2));
        return v;
    }
    private LinearLayout.LayoutParams matchWrap() { return new LinearLayout.LayoutParams(-1, -2); }
    private LinearLayout.LayoutParams weightLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
        lp.setMargins(dp(3), dp(3), dp(3), dp(3));
        return lp;
    }
    private GradientDrawable rounded(int color, int radius) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(color);
        gd.setCornerRadius(dp(radius));
        return gd;
    }
    private GradientDrawable roundedStroke(int color, int stroke, int radius, int strokeDp) {
        GradientDrawable gd = rounded(color, radius);
        gd.setStroke(dp(strokeDp), stroke);
        return gd;
    }
    private GradientDrawable roundedGradient(int[] colors, int radius) {
        GradientDrawable gd = new GradientDrawable(GradientDrawable.Orientation.TL_BR, colors);
        gd.setCornerRadius(dp(radius));
        return gd;
    }
    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    interface BitmapCallback { void onBitmap(Bitmap bitmap); }

    static class TeamPalette {
        final int primary; final int secondary;
        TeamPalette(int primary, int secondary) { this.primary = primary; this.secondary = secondary; }
    }

    static class LoadedData {
        final ArrayList<Team> teams; final ArrayList<Player> players;
        LoadedData(ArrayList<Team> teams, ArrayList<Player> players) { this.teams = teams; this.players = players; }
    }
    static class Team {
        final int id; final String name; final String abbr;
        Team(int id, String name, String abbr) { this.id = id; this.name = name; this.abbr = abbr == null || abbr.isEmpty() ? name : abbr; }
        String key() { return abbr.toUpperCase(Locale.US); }
    }
    static class Player {
        final int id; final String fullName; final String teamName; final String teamAbbr; final String position;
        Player(int id, String fullName, String teamName, String teamAbbr, String position) { this.id = id; this.fullName = fullName; this.teamName = teamName; this.teamAbbr = teamAbbr; this.position = position; }
    }
    static class LeaderboardEntry {
        final int playerId; final String name; final String teamName; final String teamAbbr; final Stats stats;
        LeaderboardEntry(int playerId, String name, String teamName, String teamAbbr, Stats stats) { this.playerId = playerId; this.name = name; this.teamName = teamName; this.teamAbbr = teamAbbr; this.stats = stats; }
        String teamAbbrOrName() { return teamAbbr == null || teamAbbr.isEmpty() ? teamName : teamAbbr; }
    }
    static class TeamStanding {
        final Team team; final Stats stats;
        TeamStanding(Team team, Stats stats) { this.team = team; this.stats = stats; }
    }
    static class Stats {
        int pa = 0; int bbe = 0; double ip = 0; final Map<String, Double> vals = new HashMap<>();
        void put(String key, Double value) { vals.put(key, value); }
        void mergeFrom(Stats other) { if (other == null) return; if (other.pa > 0) pa = Math.max(pa, other.pa); if (other.bbe > 0) bbe = Math.max(bbe, other.bbe); if (other.ip > 0) ip = Math.max(ip, other.ip); vals.putAll(other.vals); }
        Double get(String key) {
            if ("luck".equals(key)) {
                Double woba = vals.get("wOBA");
                Double xwoba = vals.get("xwOBA");
                return woba == null || xwoba == null ? null : woba - xwoba;
            }
            return vals.get(key);
        }
        boolean anyValue() { for (Double d : vals.values()) if (d != null && !Double.isNaN(d)) return true; return false; }
    }
    static class Metric {
        final String key, label, unit, type, group, side; final int decimals; final Boolean higherGood;
        Metric(String key, String label, String unit, int decimals, Boolean higherGood, String type, String group) {
            this(key, label, unit, decimals, higherGood, type, group, "hit");
        }
        Metric(String key, String label, String unit, int decimals, Boolean higherGood, String type, String group, String side) {
            this.key = key; this.label = label; this.unit = unit; this.decimals = decimals; this.higherGood = higherGood; this.type = type; this.group = group; this.side = side == null ? "hit" : side;
        }
        boolean isCount() { return "count".equals(type); }
    }
    static class Comparison {
        final boolean isTeam; final String name, meta; final int mlbId, season; final Stats seasonStats, careerStats, leagueStats; final Date updated; final String thirdLabel; final Player player; final Team team;
        final Map<String, Integer> rank, rankTotal; final Map<String, Double> percentile, thirdPercentile; final LinkedHashMap<Integer, Stats> recentSeasons;
        Comparison(boolean isTeam, String name, String meta, String role, int mlbId, int season, Stats seasonStats, Stats careerStats, Stats leagueStats, Date updated, String thirdLabel, Player player, Team team) {
            this(isTeam, name, meta, role, mlbId, season, seasonStats, careerStats, leagueStats, updated, thirdLabel, player, team, new HashMap<>(), new HashMap<>(), new HashMap<>(), new HashMap<>(), new LinkedHashMap<>());
        }
        Comparison(boolean isTeam, String name, String meta, String role, int mlbId, int season, Stats seasonStats, Stats careerStats, Stats leagueStats, Date updated, String thirdLabel, Player player, Team team, Map<String, Integer> rank, Map<String, Integer> rankTotal, Map<String, Double> percentile, Map<String, Double> thirdPercentile) {
            this(isTeam, name, meta, role, mlbId, season, seasonStats, careerStats, leagueStats, updated, thirdLabel, player, team, rank, rankTotal, percentile, thirdPercentile, new LinkedHashMap<>());
        }
        Comparison(boolean isTeam, String name, String meta, String role, int mlbId, int season, Stats seasonStats, Stats careerStats, Stats leagueStats, Date updated, String thirdLabel, Player player, Team team, Map<String, Integer> rank, Map<String, Integer> rankTotal, Map<String, Double> percentile, Map<String, Double> thirdPercentile, LinkedHashMap<Integer, Stats> recentSeasons) {
            this.isTeam = isTeam; this.name = name; this.meta = meta + (role == null || role.isEmpty() ? "" : " · " + role); this.mlbId = mlbId; this.season = season; this.seasonStats = seasonStats; this.careerStats = careerStats; this.leagueStats = leagueStats; this.updated = updated; this.thirdLabel = thirdLabel; this.player = player; this.team = team; this.rank = rank == null ? new HashMap<>() : rank; this.rankTotal = rankTotal == null ? new HashMap<>() : rankTotal; this.percentile = percentile == null ? new HashMap<>() : percentile; this.thirdPercentile = thirdPercentile == null ? new HashMap<>() : thirdPercentile; this.recentSeasons = recentSeasons == null ? new LinkedHashMap<>() : recentSeasons;
        }
        String thirdLabelShort() { return isTeam ? "Hist" : "Career"; }
    }
    static class HeadToHeadComparison {
        final boolean isTeam; final String nameA, nameB, metaA, metaB; final int idA, idB, season; final Stats statsA, statsB, leagueStats; final Player playerA, playerB; final Team teamA, teamB; final Map<String, Integer> rankA, rankB, rankTotalA, rankTotalB; final Map<String, Double> percentileA, percentileB;
        HeadToHeadComparison(boolean isTeam, String nameA, String nameB, String metaA, String metaB, int idA, int idB, int season, Stats statsA, Stats statsB, Stats leagueStats, Player playerA, Player playerB, Team teamA, Team teamB, Map<String, Integer> rankA, Map<String, Integer> rankB) {
            this(isTeam, nameA, nameB, metaA, metaB, idA, idB, season, statsA, statsB, leagueStats, playerA, playerB, teamA, teamB, rankA, rankB, new HashMap<>(), new HashMap<>(), new HashMap<>(), new HashMap<>());
        }
        HeadToHeadComparison(boolean isTeam, String nameA, String nameB, String metaA, String metaB, int idA, int idB, int season, Stats statsA, Stats statsB, Stats leagueStats, Player playerA, Player playerB, Team teamA, Team teamB, Map<String, Integer> rankA, Map<String, Integer> rankB, Map<String, Integer> rankTotalA, Map<String, Integer> rankTotalB, Map<String, Double> percentileA, Map<String, Double> percentileB) {
            this.isTeam = isTeam; this.nameA = nameA; this.nameB = nameB; this.metaA = metaA; this.metaB = metaB; this.idA = idA; this.idB = idB; this.season = season; this.statsA = statsA; this.statsB = statsB; this.leagueStats = leagueStats; this.playerA = playerA; this.playerB = playerB; this.teamA = teamA; this.teamB = teamB; this.rankA = rankA == null ? new HashMap<>() : rankA; this.rankB = rankB == null ? new HashMap<>() : rankB; this.rankTotalA = rankTotalA == null ? new HashMap<>() : rankTotalA; this.rankTotalB = rankTotalB == null ? new HashMap<>() : rankTotalB; this.percentileA = percentileA == null ? new HashMap<>() : percentileA; this.percentileB = percentileB == null ? new HashMap<>() : percentileB;
        }
    }
    static class AllRankRow {
        final Metric metric; final int rank, total, playerId; final String subjectName, leaderName; final Double value, leaderValue; final Team team;
        AllRankRow(Metric metric, int rank, int total, String subjectName, Double value, String leaderName, Double leaderValue, int playerId, Team team) {
            this.metric = metric; this.rank = rank; this.total = total; this.subjectName = subjectName; this.value = value; this.leaderName = leaderName; this.leaderValue = leaderValue; this.playerId = playerId; this.team = team;
        }
    }
    static class WeightedStatsBuilder {
        final Metric[] metrics; final boolean sumCounts; int pa = 0; int bbe = 0; double ip = 0; final Map<String, Double> sums = new HashMap<>(); final Map<String, Double> weights = new HashMap<>();
        WeightedStatsBuilder(Metric[] metrics) { this(metrics, false); }
        WeightedStatsBuilder(Metric[] metrics, boolean sumCounts) { this.metrics = metrics; this.sumCounts = sumCounts; }
        void add(Stats s) {
            if (s == null) return;
            pa += s.pa; bbe += s.bbe; ip += s.ip;
            for (Metric m : metrics) {
                if (m.key.equals("luck")) continue;
                Double val = s.get(m.key);
                if (val == null || Double.isNaN(val)) continue;
                if (m.isCount()) {
                    sums.put(m.key, sums.getOrDefault(m.key, 0.0) + val);
                    weights.put(m.key, weights.getOrDefault(m.key, 0.0) + (sumCounts ? 1.0 : 1.0));
                    continue;
                }
                double w;
                if ("pitch".equals(m.side)) w = s.ip > 0 ? s.ip : (s.pa > 0 ? s.pa : s.bbe);
                else w = (m.type.equals("expected") || m.key.equals("kPct") || m.key.equals("bbPct") || m.type.equals("standard")) ? s.pa : s.bbe;
                if (w <= 0) w = s.pa > 0 ? s.pa : (s.bbe > 0 ? s.bbe : s.ip);
                if (w <= 0) continue;
                sums.put(m.key, sums.getOrDefault(m.key, 0.0) + val * w);
                weights.put(m.key, weights.getOrDefault(m.key, 0.0) + w);
            }
        }
        Stats build() {
            Stats s = new Stats(); s.pa = pa; s.bbe = bbe; s.ip = ip;
            for (Metric m : metrics) {
                Double w = weights.get(m.key);
                if (w == null || w <= 0) s.put(m.key, null);
                else if (m.isCount() && sumCounts) s.put(m.key, sums.get(m.key));
                else s.put(m.key, sums.get(m.key) / w);
            }
            return s;
        }
    }
}