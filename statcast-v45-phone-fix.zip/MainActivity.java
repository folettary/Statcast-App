package com.folettary.statcastcompare;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.net.Uri;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.LinearGradient;
import android.graphics.RadialGradient;
import android.graphics.Outline;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.animation.ValueAnimator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.LruCache;
import android.view.Gravity;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebView;
import android.widget.*;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class MainActivity extends Activity {
    private static final int STATCAST_START_YEAR = 2015;
    private static boolean isDark = false;          // dark mode toggle – static survives recreate()

    // Mutable color fields – reassigned in initColors() on each dark/light switch
    private int NAVY, NAVY_2, TEAL, TEAL_DARK, SALMON, AMBER, BG, INK, MUTED, LINE, CARD;

    // v29: Font weight ladder – initialized in initColors()
    private Typeface tfRegular, tfMedium, tfBold;

    private final ExecutorService io = Executors.newFixedThreadPool(8);
    private final Handler main = new Handler(Looper.getMainLooper());
    private final Map<String, String> textCache = Collections.synchronizedMap(new HashMap<>());
    private LruCache<String, Bitmap> imageCache;
    private final Map<String, ArrayList<BitmapCallback>> imageWaiters = Collections.synchronizedMap(new HashMap<>());
    private final Map<Integer, ArrayList<LeaderboardEntry>> leaderboardCache = Collections.synchronizedMap(new HashMap<>());
    private final Map<Integer, ArrayList<LeaderboardEntry>> pitchingLeaderboardCache = Collections.synchronizedMap(new HashMap<>());
    private final Map<String, ArrayList<GameLogEntry>> gameLogCache = Collections.synchronizedMap(new HashMap<>());

    private LinearLayout root;
    private LinearLayout form;
    private Button playerModeButton;
    private Button teamModeButton;
    private Button singleViewButton;
    private Button headToHeadButton;
    private Button expectedViewButton;
    private EditText searchInput;
    private ListView suggestionsList;
    private Spinner teamSpinner;
    private LinearLayout teamChipRow;
    private LinearLayout compareTeamChipRow;
    private TextView compareSelectorLabel;
    private EditText compareSearchInput;
    private ListView compareSuggestionsList;
    private Spinner compareTeamSpinner;
    private LinearLayout comparePreviewBox;
    private Spinner seasonSpinner;
    private Spinner rankMetricSpinner;
    private LinearLayout seasonChipRow;
    private LinearLayout rankMetricChipRow;
    private LinearLayout rankControlContainer;
    private final ArrayList<TextView> seasonChips = new ArrayList<>();
    private final ArrayList<TextView> rankMetricChips = new ArrayList<>();
    private int selectedSeasonValue = Calendar.getInstance().get(Calendar.YEAR);
    private int selectedRankMetricPosition = -1; // -1 = All selected stats
    private Button metricPickerButton;
    private LinearLayout selectedPreviewBox;
    private Button compareButton;
    private Button standingsButton;
    private ProgressBar loading;
    private View skeletonView = null;       // v29: shimmer skeleton during profile loads
    private TextView statusView;
    private TextView errorView;
    private Button retryButton;
    private Button shareButton;
    private LinearLayout filterBox;
    private LinearLayout resultsBox;
    private LinearLayout headerBox;
    private LinearLayout metricBox;
    private LinearLayout standingsBox;
    private LinearLayout recentsBox;
    private Button copyButton;
    private TextView liveBadge;
    private LinearLayout controlsCard;
    private ScrollView mainScroll;
    private final Map<String, String> metricTrendModes = new HashMap<>();
    private final ArrayList<Metric> rankMetrics = new ArrayList<>();

    private final ArrayList<Player> allPlayers = new ArrayList<>();
    private final ArrayList<Player> filteredPlayers = new ArrayList<>();
    private final ArrayList<Player> filteredComparePlayers = new ArrayList<>();
    private final ArrayList<Team> allTeams = new ArrayList<>();
    private PlayerSuggestionAdapter suggestionsAdapter;
    private PlayerSuggestionAdapter compareSuggestionsAdapter;
    private ArrayAdapter<String> teamAdapter;
    private ArrayAdapter<String> compareTeamAdapter;
    private Player selectedPlayer;
    private Player comparePlayer;
    private Team selectedTeam;
    private Team compareTeam;
    private boolean teamMode = false;
    private boolean headToHeadMode = false;
    private boolean expectedMode = false;
    private Comparison lastComparison;
    private HeadToHeadComparison lastHeadToHead;
    private String lastStandingsText = "";
    private boolean rankingsModeActive = false;
    private boolean generalRankingsMode = false;
    private boolean suppressNextAutoScroll = false;
    private String trendWindowMode = "season";

    private final LinkedHashSet<String> selectedMetricKeys = new LinkedHashSet<>();
    private final Map<String, CheckBox> metricChecks = new LinkedHashMap<>();
    private boolean updatingMetricChecks = false;

    private final Metric[] metrics = new Metric[] {
            // Hitter standard stats
            new Metric("avg", "AVG", "", 3, true, "standard", "Standard Hitting", "hit"),
            new Metric("obp", "OBP", "", 3, true, "standard", "Standard Hitting", "hit"),
            new Metric("slg", "SLG", "", 3, true, "standard", "Standard Hitting", "hit"),
            new Metric("ops", "OPS", "", 3, true, "standard", "Standard Hitting", "hit"),
            new Metric("hr", "HR", "", 0, true, "count", "Standard Hitting", "hit"),
            new Metric("rbi", "RBI", "", 0, true, "count", "Standard Hitting", "hit"),
            new Metric("r", "Runs", "", 0, true, "count", "Standard Hitting", "hit"),
            new Metric("sb", "SB", "", 0, true, "count", "Standard Hitting", "hit"),

            // Hitter Statcast stats
            new Metric("wOBA", "wOBA", "", 3, true, "expected", "Statcast Hitting", "hit"),
            new Metric("xwOBA", "xwOBA", "", 3, true, "expected", "Statcast Hitting", "hit"),
            new Metric("luck", "Luck", "", 3, true, "luck", "Statcast Hitting", "hit"),
            new Metric("xBA", "xBA", "", 3, true, "expected", "Statcast Hitting", "hit"),
            new Metric("xSLG", "xSLG", "", 3, true, "expected", "Statcast Hitting", "hit"),
            new Metric("avgEV", "Avg EV", " mph", 1, true, "contact", "Contact Quality", "hit"),
            new Metric("avgLA", "Launch Angle", "°", 1, null, "contact", "Contact Quality", "hit"),
            new Metric("hardHitPct", "Hard-Hit %", "%", 1, true, "rate", "Contact Quality", "hit"),
            new Metric("barrelPct", "Barrel %", "%", 1, true, "rate", "Contact Quality", "hit"),
            new Metric("sweetSpotPct", "Sweet-Spot %", "%", 1, true, "rate", "Contact Quality", "hit"),
            new Metric("kPct", "K %", "%", 1, false, "rate", "Plate Discipline", "hit"),
            new Metric("bbPct", "BB %", "%", 1, true, "rate", "Plate Discipline", "hit"),

            // Pitching standard stats
            new Metric("era", "ERA", "", 2, false, "pitching", "Standard Pitching", "pitch"),
            new Metric("whip", "WHIP", "", 2, false, "pitching", "Standard Pitching", "pitch"),
            new Metric("k9", "K/9", "", 1, true, "pitching", "Standard Pitching", "pitch"),
            new Metric("bb9", "BB/9", "", 1, false, "pitching", "Standard Pitching", "pitch"),
            new Metric("kbb", "K/BB", "", 2, true, "pitching", "Standard Pitching", "pitch"),
            new Metric("pitchK", "SO", "", 0, true, "count", "Standard Pitching", "pitch"),
            new Metric("pitchBB", "BB", "", 0, false, "count", "Standard Pitching", "pitch"),
            new Metric("saves", "SV", "", 0, true, "count", "Standard Pitching", "pitch"),
            new Metric("ip", "IP", "", 1, true, "pitching", "Standard Pitching", "pitch")
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        isDark = false; // v28 uses one polished light theme.
        initColors();
        long maxKb = Runtime.getRuntime().maxMemory() / 1024;
        imageCache = new LruCache<String, Bitmap>((int) (maxKb / 8)) {
            @Override protected int sizeOf(String key, Bitmap b) { return b.getByteCount() / 1024; }
        };
        selectedMetricKeys.addAll(metricKeysForPreset("all"));
        buildUi();
        loadTeamsAndPlayers();
        fetchTodayGames();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        io.shutdown();
    }

    private void initColors() {
        if (isDark) {
            NAVY     = Color.rgb(9, 15, 28);
            NAVY_2   = Color.rgb(18, 38, 70);
            TEAL     = Color.rgb(13, 178, 163);
            TEAL_DARK= Color.rgb(0, 145, 132);
            SALMON   = Color.rgb(255, 122, 107);
            AMBER    = Color.rgb(255, 190, 89);
            BG       = Color.rgb(13, 18, 30);
            INK      = Color.rgb(225, 233, 245);
            MUTED    = Color.rgb(130, 145, 168);
            LINE     = Color.rgb(38, 52, 74);
            CARD     = Color.rgb(20, 28, 44);
        } else {
            NAVY     = Color.rgb(10, 23, 55);
            NAVY_2   = Color.rgb(21, 53, 97);
            TEAL     = Color.rgb(13, 178, 163);
            TEAL_DARK= Color.rgb(0, 125, 115);
            SALMON   = Color.rgb(255, 122, 107);
            AMBER    = Color.rgb(255, 190, 89);
            BG       = Color.rgb(242, 246, 251);
            INK      = Color.rgb(22, 29, 43);
            MUTED    = Color.rgb(94, 105, 124);
            LINE     = Color.rgb(221, 229, 241);
            CARD     = Color.WHITE;
        }
        // v29: font weight ladder (color-independent; system-cached)
        tfRegular = Typeface.create("sans-serif",        Typeface.NORMAL);
        tfMedium  = Typeface.create("sans-serif-medium", Typeface.NORMAL);
        tfBold    = Typeface.create("sans-serif",        Typeface.BOLD);
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        mainScroll = scroll;
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(10), dp(6), dp(10), dp(24));
        scroll.addView(root, new ScrollView.LayoutParams(-1, -2));
        setContentView(scroll);

        LinearLayout appBar = new LinearLayout(this);
        appBar.setOrientation(LinearLayout.HORIZONTAL);
        appBar.setGravity(Gravity.CENTER_VERTICAL);
        appBar.setPadding(dp(9), dp(6), dp(9), dp(6));
        appBar.setBackground(isDark
            ? roundedGradient(new int[] { Color.rgb(6, 12, 24), Color.rgb(12, 34, 62), Color.rgb(0, 80, 78) }, 20)
            : roundedGradient(new int[] { Color.rgb(7, 20, 46), Color.rgb(14, 54, 92), Color.rgb(0, 112, 110) }, 20));
        appBar.setElevation(dp(4));
        root.addView(appBar, matchWrap());

        TextView monogram = text("SC", 14, Color.WHITE, true);
        monogram.setGravity(Gravity.CENTER);
        monogram.setLetterSpacing(0.08f);
        monogram.setBackground(roundedStroke(Color.argb(34, 255, 255, 255), Color.argb(90, 255, 255, 255), 18, 1));
        LinearLayout.LayoutParams monoLp = new LinearLayout.LayoutParams(dp(34), dp(34));
        monoLp.setMargins(0, 0, dp(9), 0);
        appBar.addView(monogram, monoLp);

        LinearLayout titleColApp = new LinearLayout(this);
        titleColApp.setOrientation(LinearLayout.VERTICAL);
        appBar.addView(titleColApp, new LinearLayout.LayoutParams(0, -2, 1));
        TextView title = text("Statcast Compare", 18, Color.WHITE, true);
        title.setLetterSpacing(0.01f);
        titleColApp.addView(title);
        TextView subtitle = text("Profiles · matchups · rankings", 10, Color.rgb(217, 230, 245), false);
        subtitle.setPadding(0, dp(1), 0, 0);
        titleColApp.addView(subtitle);

        LinearLayout badgeStack = new LinearLayout(this);
        badgeStack.setOrientation(LinearLayout.VERTICAL);
        badgeStack.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        liveBadge = text("LIVE", 11, Color.WHITE, true);
        liveBadge.setGravity(Gravity.CENTER);
        liveBadge.setPadding(dp(9), dp(5), dp(9), dp(5));
        liveBadge.setLetterSpacing(0.12f);
        liveBadge.setBackground(roundedStroke(Color.argb(40, 255, 255, 255), Color.argb(92, 255, 255, 255), 14, 1));
        badgeStack.addView(liveBadge);
        TextView versionBadge = text("v45", 11, Color.rgb(213, 238, 236), true);
        versionBadge.setGravity(Gravity.CENTER);
        versionBadge.setPadding(0, dp(3), 0, 0);
        badgeStack.addView(versionBadge);

        appBar.addView(badgeStack);

        form = verticalCard(26, null);
        form.setPadding(dp(9), dp(9), dp(9), dp(9));
        LinearLayout.LayoutParams formLp = matchWrap();
        formLp.setMargins(0, dp(6), 0, 0);
        root.addView(form, formLp);

        LinearLayout commandHeader = new LinearLayout(this);
        commandHeader.setOrientation(LinearLayout.HORIZONTAL);
        commandHeader.setGravity(Gravity.CENTER_VERTICAL);
        form.addView(commandHeader, matchWrap());
        LinearLayout commandText = new LinearLayout(this);
        commandText.setOrientation(LinearLayout.VERTICAL);
        commandHeader.addView(commandText, new LinearLayout.LayoutParams(0, -2, 1));
        commandText.addView(text("Find a player or team", 15, INK, true));
        commandText.addView(text("Profile opens automatically. Browse rankings anytime.", 10, MUTED, false));

        metricPickerButton = compactControlButton("Stats", false);
        metricPickerButton.setForeground(ripple(false));
        metricPickerButton.setVisibility(View.GONE); // v28: show all context stats by default; no top-level stat filter clutter
        commandHeader.addView(metricPickerButton, new LinearLayout.LayoutParams(dp(1), dp(1)));
        updateMetricPickerLabel();

        LinearLayout modeShell = new LinearLayout(this);
        modeShell.setOrientation(LinearLayout.HORIZONTAL);
        modeShell.setPadding(dp(4), dp(4), dp(4), dp(4));
        modeShell.setBackground(rounded(Color.rgb(238, 243, 249), 18));
        LinearLayout.LayoutParams modeShellLp = matchWrap();
        modeShellLp.setMargins(0, dp(8), 0, dp(7));
        form.addView(modeShell, modeShellLp);
        playerModeButton = pillButton("Player", true);
        teamModeButton = pillButton("Team", false);
        playerModeButton.setForeground(ripple(true));
        teamModeButton.setForeground(ripple(true));
        modeShell.addView(playerModeButton, weightLp());
        modeShell.addView(teamModeButton, weightLp());

        LinearLayout viewShell = new LinearLayout(this);
        viewShell.setOrientation(LinearLayout.HORIZONTAL);
        viewShell.setPadding(dp(4), dp(4), dp(4), dp(4));
        viewShell.setBackground(rounded(Color.rgb(238, 243, 249), 18));
        LinearLayout.LayoutParams viewShellLp = matchWrap();
        viewShellLp.setMargins(0, 0, 0, dp(7));
        form.addView(viewShell, viewShellLp);
        singleViewButton = null; // Profile is the default/home view. Tap the selected card to return to Profile.
        headToHeadButton = pillButton("Compare", false);
        expectedViewButton = pillButton("xStats", false);
        standingsButton = pillButton("Rankings", false);
        headToHeadButton.setForeground(ripple(true));
        expectedViewButton.setForeground(ripple(true));
        standingsButton.setForeground(ripple(true));
        viewShell.addView(headToHeadButton, weightLp());
        viewShell.addView(expectedViewButton, weightLp());
        viewShell.addView(standingsButton, weightLp());

        TextView searchLabel = sectionEyebrow("SELECT");
        form.addView(searchLabel);

        // v28: recent-player quick picks removed to reduce top-card clutter.
        recentsBox = new LinearLayout(this);
        recentsBox.setOrientation(LinearLayout.HORIZONTAL);
        recentsBox.setVisibility(View.GONE);

        searchInput = new EditText(this);
        searchInput.setHint("Search player — Soto, Judge, Ohtani, Skenes…");
        searchInput.setSingleLine(true);
        searchInput.setTextSize(16);
        searchInput.setTextColor(INK);
        searchInput.setHintTextColor(Color.rgb(124, 135, 153));
        searchInput.setPadding(dp(14), dp(11), dp(14), dp(11));
        searchInput.setBackground(roundedStroke(isDark ? Color.rgb(28, 38, 58) : Color.WHITE, isDark ? Color.rgb(52, 68, 98) : Color.rgb(202, 215, 232), 18, 1));
        searchInput.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        searchInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        searchInput.setContentDescription("Search for a player by name, team, or position");
        LinearLayout.LayoutParams inputLp = matchWrap();
        inputLp.setMargins(0, dp(6), 0, dp(8));
        form.addView(searchInput, inputLp);

        suggestionsList = new ListView(this);
        suggestionsAdapter = new PlayerSuggestionAdapter(filteredPlayers);
        suggestionsList.setAdapter(suggestionsAdapter);
        suggestionsList.setVisibility(View.GONE);
        suggestionsList.setDividerHeight(1);
        suggestionsList.setBackground(roundedStroke(Color.WHITE, Color.rgb(226, 233, 243), 16, 1));
        form.addView(suggestionsList, new LinearLayout.LayoutParams(-1, dp(154)));

        teamSpinner = new Spinner(this);
        teamAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, new ArrayList<>());
        teamSpinner.setAdapter(teamAdapter);
        teamSpinner.setVisibility(View.GONE);
        form.addView(teamSpinner, new LinearLayout.LayoutParams(dp(1), dp(1)));

        teamChipRow = new LinearLayout(this);
        teamChipRow.setOrientation(LinearLayout.HORIZONTAL);
        teamChipRow.setVisibility(View.GONE);
        LinearLayout.LayoutParams teamChipLp = matchWrap();
        teamChipLp.setMargins(0, dp(6), 0, dp(8));
        form.addView(horizontalChipScroller(teamChipRow), teamChipLp);

        selectedPreviewBox = new LinearLayout(this);
        selectedPreviewBox.setOrientation(LinearLayout.HORIZONTAL);
        selectedPreviewBox.setGravity(Gravity.CENTER_VERTICAL);
        selectedPreviewBox.setPadding(dp(9), dp(9), dp(9), dp(9));
        selectedPreviewBox.setVisibility(View.GONE);
        selectedPreviewBox.setBackground(roundedGradient(new int[] { Color.rgb(249, 252, 255), Color.rgb(239, 248, 249) }, 18));
        LinearLayout.LayoutParams previewLp = matchWrap();
        previewLp.setMargins(0, dp(2), 0, dp(10));
        form.addView(selectedPreviewBox, previewLp);

        compareSelectorLabel = sectionEyebrow("2 · PICK WHO TO COMPARE AGAINST");
        compareSelectorLabel.setVisibility(View.GONE);
        form.addView(compareSelectorLabel);

        compareSearchInput = new EditText(this);
        compareSearchInput.setHint("Search second player…");
        compareSearchInput.setSingleLine(true);
        compareSearchInput.setTextSize(16);
        compareSearchInput.setTextColor(INK);
        compareSearchInput.setHintTextColor(Color.rgb(124, 135, 153));
        compareSearchInput.setPadding(dp(14), dp(11), dp(14), dp(11));
        compareSearchInput.setBackground(roundedStroke(isDark ? Color.rgb(28, 38, 58) : Color.WHITE, isDark ? Color.rgb(52, 68, 98) : Color.rgb(202, 215, 232), 18, 1));
        compareSearchInput.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        compareSearchInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        compareSearchInput.setContentDescription("Search for a second player to compare");
        compareSearchInput.setVisibility(View.GONE);
        LinearLayout.LayoutParams compareInputLp = matchWrap();
        compareInputLp.setMargins(0, dp(6), 0, dp(8));
        form.addView(compareSearchInput, compareInputLp);

        compareSuggestionsList = new ListView(this);
        compareSuggestionsAdapter = new PlayerSuggestionAdapter(filteredComparePlayers);
        compareSuggestionsList.setAdapter(compareSuggestionsAdapter);
        compareSuggestionsList.setVisibility(View.GONE);
        compareSuggestionsList.setDividerHeight(1);
        compareSuggestionsList.setBackground(roundedStroke(Color.WHITE, Color.rgb(226, 233, 243), 16, 1));
        form.addView(compareSuggestionsList, new LinearLayout.LayoutParams(-1, dp(154)));

        compareTeamSpinner = new Spinner(this);
        compareTeamAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, new ArrayList<>());
        compareTeamSpinner.setAdapter(compareTeamAdapter);
        compareTeamSpinner.setVisibility(View.GONE);
        form.addView(compareTeamSpinner, new LinearLayout.LayoutParams(dp(1), dp(1)));

        compareTeamChipRow = new LinearLayout(this);
        compareTeamChipRow.setOrientation(LinearLayout.HORIZONTAL);
        compareTeamChipRow.setVisibility(View.GONE);
        LinearLayout.LayoutParams compareTeamLp = matchWrap();
        compareTeamLp.setMargins(0, dp(6), 0, dp(8));
        form.addView(horizontalChipScroller(compareTeamChipRow), compareTeamLp);

        comparePreviewBox = new LinearLayout(this);
        comparePreviewBox.setOrientation(LinearLayout.HORIZONTAL);
        comparePreviewBox.setGravity(Gravity.CENTER_VERTICAL);
        comparePreviewBox.setPadding(dp(9), dp(9), dp(9), dp(9));
        comparePreviewBox.setVisibility(View.GONE);
        comparePreviewBox.setBackground(roundedGradient(new int[] { Color.rgb(249, 252, 255), Color.rgb(239, 248, 249) }, 18));
        LinearLayout.LayoutParams comparePreviewLp = matchWrap();
        comparePreviewLp.setMargins(0, dp(2), 0, dp(10));
        form.addView(comparePreviewBox, comparePreviewLp);

        controlsCard = new LinearLayout(this);
        controlsCard.setOrientation(LinearLayout.VERTICAL);
        controlsCard.setPadding(dp(10), dp(10), dp(10), dp(10));
        controlsCard.setBackground(roundedStroke(Color.rgb(248, 251, 254), Color.rgb(227, 234, 244), 20, 1));
        controlsCard.setVisibility(View.GONE);
        LinearLayout.LayoutParams controlsLp = matchWrap();
        controlsLp.setMargins(0, dp(3), 0, 0);
        form.addView(controlsCard, controlsLp);

        LinearLayout seasonCol = new LinearLayout(this);
        seasonCol.setOrientation(LinearLayout.VERTICAL);
        seasonCol.addView(sectionEyebrow("SEASON"));
        seasonSpinner = new Spinner(this);
        seasonSpinner.setVisibility(View.GONE);
        ArrayList<String> years = new ArrayList<>();
        int currentYear = Calendar.getInstance().get(Calendar.YEAR);
        selectedSeasonValue = currentYear;
        for (int y = currentYear; y >= STATCAST_START_YEAR; y--) years.add(String.valueOf(y));
        ArrayAdapter<String> yearAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, years);
        seasonSpinner.setAdapter(yearAdapter);
        seasonCol.addView(seasonSpinner, new LinearLayout.LayoutParams(dp(1), dp(1)));
        seasonChipRow = new LinearLayout(this);
        seasonChipRow.setOrientation(LinearLayout.HORIZONTAL);
        HorizontalScrollView seasonScroll = horizontalChipScroller(seasonChipRow);
        seasonCol.addView(seasonScroll, matchWrap());
        controlsCard.addView(seasonCol, matchWrap());
        buildSeasonChips();

        rankControlContainer = new LinearLayout(this);
        rankControlContainer.setOrientation(LinearLayout.VERTICAL);
        rankControlContainer.setVisibility(View.GONE);
        LinearLayout.LayoutParams rankControlsLp = matchWrap();
        rankControlsLp.setMargins(0, dp(8), 0, 0);
        controlsCard.addView(rankControlContainer, rankControlsLp);

        rankControlContainer.addView(sectionEyebrow("RANKING STAT"));
        rankMetricSpinner = new Spinner(this);
        rankMetricSpinner.setVisibility(View.GONE);
        rankControlContainer.addView(rankMetricSpinner, new LinearLayout.LayoutParams(dp(1), dp(1)));
        rankMetricChipRow = new LinearLayout(this);
        rankMetricChipRow.setOrientation(LinearLayout.HORIZONTAL);
        HorizontalScrollView rankScroll = horizontalChipScroller(rankMetricChipRow);
        rankControlContainer.addView(rankScroll, matchWrap());
        rebuildRankMetricSpinner();

        // v28: no bottom action row. Data loads immediately when mode/selection changes.
        compareButton = primaryActionButton("Compare");
        compareButton.setVisibility(View.GONE);
        compareButton.setEnabled(false);
        controlsCard.addView(compareButton, new LinearLayout.LayoutParams(dp(1), dp(1)));

        statusView = text("Loading MLB teams and active players…", 12, MUTED, false);
        statusView.setPadding(dp(2), dp(9), dp(2), 0);
        statusView.setVisibility(View.GONE);

        filterBox = new LinearLayout(this);
        filterBox.setOrientation(LinearLayout.VERTICAL);
        filterBox.setVisibility(View.GONE);

        loading = new ProgressBar(this);
        loading.setVisibility(View.GONE);
        LinearLayout.LayoutParams loadLp = new LinearLayout.LayoutParams(dp(38), dp(38));
        loadLp.gravity = Gravity.CENTER_HORIZONTAL;
        loadLp.setMargins(0, dp(10), 0, 0);
        form.addView(loading, loadLp);

        errorView = text("", 14, Color.rgb(180, 54, 70), false);
        errorView.setPadding(dp(2), dp(10), dp(2), 0);
        errorView.setVisibility(View.GONE);
        form.addView(errorView);

        retryButton = secondaryActionButton("Retry");
        retryButton.setForeground(ripple(false));
        retryButton.setVisibility(View.GONE);
        retryButton.setOnClickListener(v -> {
            showError(null);
            loadTeamsAndPlayers();
        });
        LinearLayout.LayoutParams retryLp = matchWrap();
        retryLp.setMargins(0, dp(6), 0, 0);
        form.addView(retryButton, retryLp);

        resultsBox = new LinearLayout(this);
        resultsBox.setOrientation(LinearLayout.VERTICAL);
        resultsBox.setVisibility(View.GONE);
        LinearLayout.LayoutParams resultsLp = matchWrap();
        resultsLp.setMargins(0, dp(12), 0, 0);
        root.addView(resultsBox, resultsLp);

        headerBox = new LinearLayout(this);
        headerBox.setOrientation(LinearLayout.VERTICAL);
        resultsBox.addView(headerBox, matchWrap());

        copyButton = compactControlButton("Copy table", false);
        copyButton.setForeground(ripple(false));
        copyButton.setVisibility(View.GONE);

        shareButton = compactControlButton("Share image", false);
        shareButton.setForeground(ripple(false));
        shareButton.setVisibility(View.GONE);

        metricBox = new LinearLayout(this);
        metricBox.setOrientation(LinearLayout.VERTICAL);
        resultsBox.addView(metricBox, matchWrap());

        standingsBox = new LinearLayout(this);
        standingsBox.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams standingsLp = matchWrap();
        standingsLp.setMargins(0, dp(14), 0, 0);
        root.addView(standingsBox, standingsLp);

        updateAnalysisModeButtons();
        updateViewModeButtons();
        updateControlsVisibility();
        wireEvents();
    }


    private TextView heroPill(String label) {
        TextView tv = text(label, 12, Color.WHITE, true);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(dp(8), dp(9), dp(8), dp(9));
        tv.setBackground(roundedStroke(Color.argb(38, 255, 255, 255), Color.argb(80, 255, 255, 255), 16, 1));
        return tv;
    }

    private Button pillButton(String label, boolean active) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextSize(13);
        b.setMinHeight(0);
        b.setMinWidth(0);
        b.setPadding(dp(4), dp(6), dp(4), dp(6));
        b.setGravity(Gravity.CENTER);
        b.setIncludeFontPadding(false);
        b.setSingleLine(false);
        b.setMaxLines(2);
        b.setEllipsize(null);
        b.setTextColor(active ? Color.WHITE : Color.rgb(71, 83, 105));
        b.setBackground(active ? roundedGradient(new int[] { NAVY, Color.rgb(24, 62, 109) }, 15) : rounded(Color.TRANSPARENT, 15));
        return b;
    }

    private TextView sectionEyebrow(String value) {
        TextView tv = new TextView(this);
        tv.setText(value);
        tv.setTextSize(10);
        tv.setTextColor(Color.rgb(112, 123, 142));
        tv.setTypeface(tfMedium);               // v29: medium weight for section labels
        tv.setLetterSpacing(0.12f);
        tv.setPadding(dp(2), dp(2), dp(2), dp(2));
        return tv;
    }


    private HorizontalScrollView horizontalChipScroller(LinearLayout chipRow) {
        HorizontalScrollView scroll = new HorizontalScrollView(this);
        scroll.setHorizontalScrollBarEnabled(false);
        scroll.setOverScrollMode(View.OVER_SCROLL_NEVER);
        scroll.setFillViewport(false);
        scroll.addView(chipRow, new HorizontalScrollView.LayoutParams(-2, -2));
        return scroll;
    }

    private TextView choiceChip(String label, boolean active) {
        TextView tv = text(label, 13, active ? Color.WHITE : NAVY, true);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(dp(13), dp(8), dp(13), dp(8));
        tv.setSingleLine(true);
        tv.setBackground(active
                ? roundedGradient(new int[] { NAVY, Color.rgb(24, 62, 109) }, 16)
                : roundedStroke(Color.WHITE, Color.rgb(205, 216, 230), 16, 1));
        tv.setForeground(ripple(active));
        return tv;
    }

    private TextView groupChip(String label) {
        TextView tv = text(label.toUpperCase(Locale.US), 10, MUTED, true);
        tv.setGravity(Gravity.CENTER);
        tv.setLetterSpacing(0.10f);
        tv.setPadding(dp(10), dp(8), dp(8), dp(8));
        tv.setSingleLine(true);
        return tv;
    }

    private void addChipWithMargin(LinearLayout row, View chip) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.setMargins(0, dp(3), dp(7), dp(3));
        row.addView(chip, lp);
    }


    private void buildTeamChips() {
        if (teamChipRow != null) {
            teamChipRow.removeAllViews();
            for (int i = 0; i < allTeams.size(); i++) {
                final int index = i;
                Team t = allTeams.get(i);
                boolean active = selectedTeam != null && selectedTeam.key().equals(t.key());
                TextView chip = choiceChip(t.abbr == null || t.abbr.isEmpty() ? initials(t.name) : t.abbr, active);
                chip.setOnClickListener(v -> {
                    selectedTeam = allTeams.get(index);
                    if (teamSpinner != null) teamSpinner.setSelection(index);
                    buildTeamChips();
                    renderSelectionPreview();
                    if (teamMode) refreshAfterPrimarySelection();
                });
                addChipWithMargin(teamChipRow, chip);
            }
        }
        if (compareTeamChipRow != null) {
            compareTeamChipRow.removeAllViews();
            for (int i = 0; i < allTeams.size(); i++) {
                final int index = i;
                Team t = allTeams.get(i);
                boolean active = compareTeam != null && compareTeam.key().equals(t.key());
                TextView chip = choiceChip(t.abbr == null || t.abbr.isEmpty() ? initials(t.name) : t.abbr, active);
                chip.setOnClickListener(v -> {
                    compareTeam = allTeams.get(index);
                    if (compareTeamSpinner != null) compareTeamSpinner.setSelection(index);
                    buildTeamChips();
                    if (teamMode && headToHeadMode) { renderComparePreview(); refreshHeadToHeadIfReady(); }
                });
                addChipWithMargin(compareTeamChipRow, chip);
            }
        }
    }

    private void buildSeasonChips() {
        if (seasonChipRow == null) return;
        seasonChipRow.removeAllViews();
        seasonChips.clear();
        int currentYear = Calendar.getInstance().get(Calendar.YEAR);
        for (int y = currentYear; y >= STATCAST_START_YEAR; y--) {
            final int year = y;
            TextView chip = choiceChip(String.valueOf(year), year == selectedSeasonValue);
            chip.setOnClickListener(v -> setSelectedSeason(year));
            seasonChips.add(chip);
            addChipWithMargin(seasonChipRow, chip);
        }
    }

    private void refreshSeasonChips() {
        for (int i = 0; i < seasonChips.size(); i++) {
            TextView chip = seasonChips.get(i);
            try {
                int year = Integer.parseInt(chip.getText().toString());
                chip.setTextColor(year == selectedSeasonValue ? Color.WHITE : NAVY);
                chip.setBackground(year == selectedSeasonValue
                        ? roundedGradient(new int[] { NAVY, Color.rgb(24, 62, 109) }, 16)
                        : roundedStroke(Color.WHITE, Color.rgb(205, 216, 230), 16, 1));
            } catch (Exception ignored) {}
        }
    }

    private void setSelectedSeason(int year) {
        selectedSeasonValue = year;
        if (seasonSpinner != null && seasonSpinner.getAdapter() != null) {
            for (int i = 0; i < seasonSpinner.getAdapter().getCount(); i++) {
                Object item = seasonSpinner.getAdapter().getItem(i);
                if (item != null && item.toString().equals(String.valueOf(year))) {
                    seasonSpinner.setSelection(i);
                    break;
                }
            }
        }
        refreshSeasonChips();
        if (rankingsModeActive) showStandings();
        else if (headToHeadMode) refreshHeadToHeadIfReady();
        else if (expectedMode) refreshExpectedIfReady();
        else if ((teamMode && selectedTeam != null) || (!teamMode && selectedPlayer != null)) openProfileForCurrentSelection();
    }

    private void refreshRankMetricChips() {
        if (rankMetricChipRow == null) return;
        rankMetricChipRow.removeAllViews();
        rankMetricChips.clear();

        // Keep the old "all stats" view available, but default to OPS/ERA for one-stat rankings.
        TextView allChip = choiceChip("All", selectedRankMetricPosition < 0);
        allChip.setOnClickListener(v -> {
            selectedRankMetricPosition = -1;
            if (rankMetricSpinner != null) rankMetricSpinner.setSelection(0);
            refreshRankMetricChips();
            refreshRankingsIfActive();
        });
        rankMetricChips.add(allChip);
        addChipWithMargin(rankMetricChipRow, allChip);

        boolean hasHit = false, hasPitch = false;
        for (Metric m : rankMetrics) {
            if ("pitch".equals(m.side)) hasPitch = true;
            else hasHit = true;
        }

        if (hasHit) addChipWithMargin(rankMetricChipRow, groupChip("Batting"));
        for (int i = 0; i < rankMetrics.size(); i++) {
            Metric m = rankMetrics.get(i);
            if ("pitch".equals(m.side)) continue;
            addRankMetricChip(i, m);
        }

        if (hasPitch) addChipWithMargin(rankMetricChipRow, groupChip("Pitching"));
        for (int i = 0; i < rankMetrics.size(); i++) {
            Metric m = rankMetrics.get(i);
            if (!"pitch".equals(m.side)) continue;
            addRankMetricChip(i, m);
        }
    }

    private void addRankMetricChip(int index, Metric m) {
        TextView chip = choiceChip(m.label, selectedRankMetricPosition == index);
        chip.setOnClickListener(v -> {
            selectedRankMetricPosition = index;
            if (rankMetricSpinner != null) rankMetricSpinner.setSelection(index + 1);
            refreshRankMetricChips();
            refreshRankingsIfActive();
        });
        rankMetricChips.add(chip);
        addChipWithMargin(rankMetricChipRow, chip);
    }

    private int defaultRankingMetricIndex() {
        String preferredKey = "ops";
        if ((!teamMode && selectedPlayer != null && isPitcher(selectedPlayer)) || ("pitch".equals(preferredMetricSide()) && !teamMode)) {
            preferredKey = "era";
        }
        for (int i = 0; i < rankMetrics.size(); i++) if (rankMetrics.get(i).key.equals(preferredKey)) return i;
        for (int i = 0; i < rankMetrics.size(); i++) if (rankMetrics.get(i).key.equals("ops")) return i;
        for (int i = 0; i < rankMetrics.size(); i++) if (rankMetrics.get(i).key.equals("era")) return i;
        return rankMetrics.isEmpty() ? -1 : 0;
    }

    private Button compactControlButton(String label, boolean active) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextSize(11);
        b.setMinHeight(0);
        b.setMinWidth(0);
        b.setPadding(dp(6), dp(5), dp(6), dp(5));
        b.setGravity(Gravity.CENTER);
        b.setIncludeFontPadding(false);
        b.setSingleLine(false);
        b.setMaxLines(2);
        b.setEllipsize(null);
        b.setTextColor(active ? Color.WHITE : NAVY);
        b.setBackground(active ? rounded(TEAL_DARK, 14) : roundedStroke(Color.WHITE, Color.rgb(213, 223, 236), 14, 1));
        return b;
    }

    private Button primaryActionButton(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextSize(14);
        b.setTextColor(Color.WHITE);
        b.setMinHeight(0);
        b.setMinWidth(0);
        b.setPadding(dp(8), dp(6), dp(8), dp(6));
        b.setGravity(Gravity.CENTER);
        b.setIncludeFontPadding(false);
        b.setSingleLine(false);
        b.setMaxLines(2);
        b.setEllipsize(null);
        b.setBackground(roundedGradient(new int[] { TEAL, TEAL_DARK }, 16));
        return b;
    }

    private Button secondaryActionButton(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextSize(14);
        b.setTextColor(NAVY);
        b.setMinHeight(0);
        b.setMinWidth(0);
        b.setPadding(dp(8), dp(6), dp(8), dp(6));
        b.setGravity(Gravity.CENTER);
        b.setIncludeFontPadding(false);
        b.setSingleLine(false);
        b.setMaxLines(2);
        b.setEllipsize(null);
        b.setBackground(roundedStroke(Color.WHITE, Color.rgb(197, 211, 228), 16, 1));
        return b;
    }

    private void updateViewModeButtons() {
        if (standingsButton == null || headToHeadButton == null || expectedViewButton == null) return;
        if (compareButton != null) compareButton.setVisibility(View.GONE);
        boolean hasSelection = (teamMode && selectedTeam != null) || (!teamMode && selectedPlayer != null);
        headToHeadButton.setVisibility(hasSelection ? View.VISIBLE : View.GONE);
        expectedViewButton.setVisibility(hasSelection ? View.VISIBLE : View.GONE);
        headToHeadButton.setTextColor(headToHeadMode ? Color.WHITE : NAVY);
        headToHeadButton.setBackground(headToHeadMode ? rounded(NAVY, 16) : roundedStroke(Color.WHITE, LINE, 16, 1));
        expectedViewButton.setTextColor(expectedMode ? Color.WHITE : NAVY);
        expectedViewButton.setBackground(expectedMode ? rounded(NAVY, 16) : roundedStroke(Color.WHITE, LINE, 16, 1));
        standingsButton.setText(rankingsModeActive ? "Viewing rankings" : "Browse rankings");
        standingsButton.setTextColor(rankingsModeActive ? Color.WHITE : NAVY);
        standingsButton.setBackground(rankingsModeActive ? rounded(NAVY, 16) : roundedStroke(Color.WHITE, LINE, 16, 1));
        if (rankControlContainer != null) rankControlContainer.setVisibility(rankingsModeActive ? View.VISIBLE : View.GONE);
        updateControlsVisibility();
    }

    private void updateControlsVisibility() {
        if (controlsCard == null) return;
        boolean hasSelection = (teamMode && selectedTeam != null) || (!teamMode && selectedPlayer != null);
        controlsCard.setVisibility((hasSelection || rankingsModeActive) ? View.VISIBLE : View.GONE);
    }

    private void refreshRankingsIfActive() {
        if (rankingsModeActive && !isBusy()) showStandings();
    }

    private void openProfileForCurrentSelection() {
        if (isBusy()) return;
        rankingsModeActive = false;
        headToHeadMode = false;
        expectedMode = false;
        lastHeadToHead = null;
        updateAnalysisModeButtons();
        applyHeadToHeadVisibility();
        updateViewModeButtons();
        updateControlsVisibility();
        standingsBox.removeAllViews();
        showError(null);
        try {
            int season = currentSeason();
            if (teamMode) {
                if (selectedTeam != null) compareTeam(selectedTeam, season);
            } else {
                if (selectedPlayer != null) comparePlayer(selectedPlayer, season);
            }
        } catch (Exception ignored) {}
    }

    private void scrollToResultsTop() {
        if (mainScroll == null || resultsBox == null) return;
        mainScroll.postDelayed(() -> mainScroll.smoothScrollTo(0, Math.max(0, resultsBox.getTop() - dp(8))), 250);
    }

    private void refreshAfterPrimarySelection() {
        generalRankingsMode = false;
        if (rankingsModeActive) {
            showStandings();
        } else if (headToHeadMode) {
            renderComparePreview();
            if (!refreshHeadToHeadIfReady()) resultsBox.setVisibility(View.GONE);
        } else if (expectedMode) {
            if (!refreshExpectedIfReady()) resultsBox.setVisibility(View.GONE);
        } else {
            openProfileForCurrentSelection();
        }
    }


    private void updateMetricPickerLabel() {
        if (metricPickerButton == null) return;
        String preset = metricPresetName(selectedMetricKeys);
        metricPickerButton.setText("Stats: " + preset + " (" + selectedMetricKeys.size() + ")");
    }

    private String preferredMetricSide() {
        if (!teamMode && selectedPlayer != null && isPitcher(selectedPlayer)) return "pitch";
        if (teamMode && selectedMetricKeys.size() > 0) {
            int pitch = 0, hit = 0;
            for (Metric m : metrics) if (selectedMetricKeys.contains(m.key)) { if ("pitch".equals(m.side)) pitch++; else if ("hit".equals(m.side)) hit++; }
            if (pitch > hit) return "pitch";
        }
        return "hit";
    }

    private boolean isPitcher(Player p) {
        if (p == null || p.position == null) return false;
        String pos = p.position.toUpperCase(Locale.US);
        return pos.equals("P") || pos.equals("SP") || pos.equals("RP") || pos.contains("PITCH");
    }

    private ArrayList<Metric> metricsForCurrentContext() {
        String side = preferredMetricSide();
        ArrayList<Metric> list = new ArrayList<>();
        boolean browseAllRankingStats = rankingsModeActive || teamMode || selectedPlayer == null;
        for (Metric m : metrics) {
            if (browseAllRankingStats || m.side.equals(side) || m.side.equals("both")) list.add(m);
        }
        return list;
    }

    private void rebuildRankMetricSpinner() {
        rankMetrics.clear();
        rankMetrics.addAll(metricsForCurrentContext());
        ArrayList<String> metricLabels = new ArrayList<>();
        metricLabels.add("All");
        for (Metric m : rankMetrics) metricLabels.add(m.label);
        if (rankMetricSpinner != null) {
            ArrayAdapter<String> rankAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, metricLabels);
            rankMetricSpinner.setAdapter(rankAdapter);
        }
        int def = defaultRankingMetricIndex();
        if (selectedRankMetricPosition >= rankMetrics.size()) selectedRankMetricPosition = def;
        if (selectedRankMetricPosition < -1) selectedRankMetricPosition = def;
        if (selectedRankMetricPosition == -1 && def >= 0) selectedRankMetricPosition = def;
        if (rankMetricSpinner != null) rankMetricSpinner.setSelection(selectedRankMetricPosition < 0 ? 0 : selectedRankMetricPosition + 1);
        refreshRankMetricChips();
    }

    private Metric selectedRankMetric() {
        if (rankMetrics.isEmpty()) return metrics[0];
        if (selectedRankMetricPosition < 0) return null;
        return rankMetrics.get(Math.min(selectedRankMetricPosition, rankMetrics.size() - 1));
    }

    private ArrayList<Metric> selectedRankingMetrics() {
        ArrayList<Metric> out = new ArrayList<>();
        String side = preferredMetricSide();
        for (Metric m : metrics) {
            if (selectedMetricKeys.contains(m.key) && (m.side.equals(side) || m.side.equals("both") || teamMode)) out.add(m);
        }
        if (out.isEmpty()) out.addAll(metricsForCurrentContext());
        return out;
    }

    private void applySmartDefaultForSelection(Player p) {
        selectedMetricKeys.clear();
        selectedMetricKeys.addAll(metricKeysForPreset("all"));
        selectedRankMetricPosition = -1;
        rebuildRankMetricSpinner();
        updateMetricPickerLabel();
        syncMetricChecks();
    }


    private String metricPresetName(Set<String> keys) {
        if (keys.equals(metricKeysForPreset("hitterCore"))) return "Hitter Core";
        if (keys.equals(metricKeysForPreset("pitcherCore"))) return "Pitcher Core";
        if (keys.equals(metricKeysForPreset("standard"))) return "Standard";
        if (keys.equals(metricKeysForPreset("statcast"))) return "Statcast";
        if (keys.equals(metricKeysForPreset("contact"))) return "Contact";
        if (keys.equals(metricKeysForPreset("discipline"))) return "Discipline";
        if (keys.equals(metricKeysForPreset("luck"))) return "Luck";
        if (keys.equals(metricKeysForPreset("all"))) return "All";
        return "Custom";
    }

    private LinkedHashSet<String> metricKeysForPreset(String preset) {
        LinkedHashSet<String> keys = new LinkedHashSet<>();
        String side = preferredMetricSide();
        for (Metric m : metrics) {
            boolean include;
            if ("hitterCore".equals(preset) || ("core".equals(preset) && "hit".equals(side))) include = m.key.equals("avg") || m.key.equals("obp") || m.key.equals("slg") || m.key.equals("ops") || m.key.equals("wOBA") || m.key.equals("xwOBA") || m.key.equals("luck") || m.key.equals("barrelPct");
            else if ("pitcherCore".equals(preset) || ("core".equals(preset) && "pitch".equals(side))) include = m.key.equals("era") || m.key.equals("whip") || m.key.equals("k9") || m.key.equals("bb9") || m.key.equals("kbb") || m.key.equals("ip");
            else if ("standard".equals(preset)) include = m.side.equals(side) && (m.group.startsWith("Standard") || m.type.equals("count") || m.type.equals("pitching"));
            else if ("statcast".equals(preset) || "expected".equals(preset)) include = m.side.equals("hit") && (m.group.startsWith("Statcast") || m.key.equals("luck"));
            else if ("contact".equals(preset)) include = m.side.equals("hit") && m.group.equals("Contact Quality");
            else if ("discipline".equals(preset)) include = m.side.equals("hit") && m.group.equals("Plate Discipline");
            else if ("luck".equals(preset)) include = m.key.equals("wOBA") || m.key.equals("xwOBA") || m.key.equals("luck");
            else if ("pitching".equals(preset)) include = m.side.equals("pitch");
            else if ("all".equals(preset)) include = teamMode || m.side.equals(side);
            else include = false;
            if (include) keys.add(m.key);
        }
        return keys;
    }

    private void showMetricPicker() {
        final LinkedHashMap<String, CheckBox> boxes = new LinkedHashMap<>();
        LinearLayout shell = new LinearLayout(this);
        shell.setOrientation(LinearLayout.VERTICAL);
        shell.setPadding(dp(4), dp(2), dp(4), dp(2));

        String side = preferredMetricSide();
        TextView hint = text(("pitch".equals(side) ? "Pitching" : "Hitting") + " stats are shown based on the selected player/team. Use presets for the common views, or customize below.", 12, MUTED, false);
        hint.setPadding(0, 0, 0, dp(8));
        shell.addView(hint);
        ArrayList<Metric> pickerMetrics = teamMode ? new ArrayList<>(Arrays.asList(metrics)) : metricsForCurrentContext();

        LinearLayout row1 = new LinearLayout(this); row1.setOrientation(LinearLayout.HORIZONTAL); shell.addView(row1, matchWrap());
        LinearLayout row2 = new LinearLayout(this); row2.setOrientation(LinearLayout.HORIZONTAL); shell.addView(row2, matchWrap());
        row1.addView(dialogPresetChip("Recommended", () -> setDialogPreset(boxes, "core")), weightLp());
        row1.addView(dialogPresetChip("Standard", () -> setDialogPreset(boxes, "standard")), weightLp());
        row1.addView(dialogPresetChip("All", () -> setDialogPreset(boxes, "all")), weightLp());
        if (teamMode) {
            row2.addView(dialogPresetChip("Hitting", () -> setDialogPreset(boxes, "hitterCore")), weightLp());
            row2.addView(dialogPresetChip("Pitching", () -> setDialogPreset(boxes, "pitcherCore")), weightLp());
            row2.addView(dialogPresetChip("Statcast", () -> setDialogPreset(boxes, "statcast")), weightLp());
        } else if ("hit".equals(side)) {
            row2.addView(dialogPresetChip("Statcast", () -> setDialogPreset(boxes, "statcast")), weightLp());
            row2.addView(dialogPresetChip("Contact", () -> setDialogPreset(boxes, "contact")), weightLp());
            row2.addView(dialogPresetChip("Luck", () -> setDialogPreset(boxes, "luck")), weightLp());
        } else {
            row2.addView(dialogPresetChip("Pitching", () -> setDialogPreset(boxes, "pitching")), weightLp());
            row2.addView(dialogPresetChip("Run prevention", () -> setDialogPreset(boxes, "pitcherCore")), weightLp());
            row2.addView(new Space(this), weightLp());
        }

        String lastGroup = "";
        for (Metric m : pickerMetrics) {
            if (!m.group.equals(lastGroup)) {
                TextView sub = text(m.group, 12, MUTED, true);
                sub.setPadding(0, dp(10), 0, dp(3));
                shell.addView(sub);
                lastGroup = m.group;
            }
            CheckBox cb = new CheckBox(this);
            cb.setText(m.label);
            cb.setTextColor(INK);
            cb.setTextSize(14);
            cb.setButtonTintList(ColorStateList.valueOf(TEAL));
            cb.setPadding(dp(4), dp(2), dp(4), dp(2));
            cb.setChecked(selectedMetricKeys.contains(m.key));
            boxes.put(m.key, cb);
            shell.addView(cb, matchWrap());
        }

        ScrollView scroller = new ScrollView(this);
        scroller.addView(shell);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Stats shown")
                .setView(scroller)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Apply", (d, which) -> {
                    selectedMetricKeys.clear();
                    for (Metric m : pickerMetrics) {
                        CheckBox cb = boxes.get(m.key);
                        if (cb != null && cb.isChecked()) selectedMetricKeys.add(m.key);
                    }
                    rebuildRankMetricSpinner();
                    updateMetricPickerLabel();
                    syncMetricChecks();
                    refreshCurrentResults();
                    refreshRankingsIfActive();
                })
                .create();
        dialog.show();
    }

    private TextView dialogPresetChip(String label, Runnable action) {
        TextView tv = filterChip(label, action);
        tv.setTextSize(12);
        tv.setPadding(dp(6), dp(7), dp(6), dp(7));
        return tv;
    }

    private void setDialogPreset(Map<String, CheckBox> boxes, String preset) {
        Set<String> keys = metricKeysForPreset(preset);
        for (Map.Entry<String, CheckBox> e : boxes.entrySet()) e.getValue().setChecked(keys.contains(e.getKey()));
    }

    private void renderSelectionPreview() {
        if (selectedPreviewBox == null) return;
        selectedPreviewBox.removeAllViews();
        boolean hasSelection = teamMode ? selectedTeam != null : selectedPlayer != null;
        selectedPreviewBox.setVisibility(hasSelection ? View.VISIBLE : View.GONE);
        if (!hasSelection) return;

        TeamPalette palette = teamMode ? paletteForTeam(selectedTeam) : paletteForAbbr(selectedPlayer.teamAbbr);
        selectedPreviewBox.setBackground(roundedGradient(new int[] { palette.primary, palette.secondary }, 20));
        selectedPreviewBox.setOnClickListener(v -> openProfileForCurrentSelection());
        selectedPreviewBox.setClickable(true);
        selectedPreviewBox.setForeground(ripple(true));

        if (teamMode) {
            View logo = teamLogoView(selectedTeam, 46);
            LinearLayout.LayoutParams logoLp = new LinearLayout.LayoutParams(dp(46), dp(46));
            logoLp.setMargins(0, 0, dp(11), 0);
            selectedPreviewBox.addView(logo, logoLp);
            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);
            col.addView(text(selectedTeam.name, 16, Color.WHITE, true));
            col.addView(text("Team profile · " + selectedTeam.abbr, 11, Color.rgb(228, 238, 248), false));
            selectedPreviewBox.addView(col, new LinearLayout.LayoutParams(0, -2, 1));
            TextView hint = text("Profile", 11, Color.WHITE, true);
            hint.setGravity(Gravity.CENTER);
            hint.setPadding(dp(9), dp(5), dp(9), dp(5));
            hint.setBackground(roundedStroke(Color.argb(34, 255, 255, 255), Color.argb(80, 255, 255, 255), 14, 1));
            selectedPreviewBox.addView(hint);
        } else {
            ImageView img = new ImageView(this);
            img.setScaleType(ImageView.ScaleType.FIT_CENTER);
            img.setAdjustViewBounds(true);
            img.setBackground(roundedStroke(Color.WHITE, Color.argb(90, 255, 255, 255), 18, 1));
            img.setPadding(dp(2), dp(2), dp(2), dp(2));
            LinearLayout.LayoutParams imgLp = new LinearLayout.LayoutParams(dp(46), dp(46));
            imgLp.setMargins(0, 0, dp(11), 0);
            selectedPreviewBox.addView(img, imgLp);
            loadPlayerImage(selectedPlayer.id, img);
            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);
            col.addView(text(selectedPlayer.fullName, 16, Color.WHITE, true));
            col.addView(text(selectedPlayer.teamAbbr + " · " + selectedPlayer.position, 11, Color.rgb(228, 238, 248), false));
            selectedPreviewBox.addView(col, new LinearLayout.LayoutParams(0, -2, 1));
            TextView hint = text("Profile", 11, Color.WHITE, true);
            hint.setGravity(Gravity.CENTER);
            hint.setPadding(dp(9), dp(5), dp(9), dp(5));
            hint.setBackground(roundedStroke(Color.argb(34, 255, 255, 255), Color.argb(80, 255, 255, 255), 14, 1));
            selectedPreviewBox.addView(hint);
        }
    }

    private void buildMetricFilters() {
        filterBox.removeAllViews();

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.VERTICAL);
        top.addView(text("Stats shown", 13, MUTED, true));
        TextView hint = text("Tap a preset or pick individual stats. No sideways scrolling.", 12, MUTED, false);
        hint.setPadding(0, dp(2), 0, dp(6));
        top.addView(hint);
        filterBox.addView(top, matchWrap());

        LinearLayout presetRow1 = new LinearLayout(this);
        presetRow1.setOrientation(LinearLayout.HORIZONTAL);
        presetRow1.addView(filterChip("Recommended", () -> applyMetricPreset("core")), weightLp());
        presetRow1.addView(filterChip("Standard", () -> applyMetricPreset("standard")), weightLp());
        presetRow1.addView(filterChip("Contact", () -> applyMetricPreset("contact")), weightLp());
        filterBox.addView(presetRow1, matchWrap());

        LinearLayout presetRow2 = new LinearLayout(this);
        presetRow2.setOrientation(LinearLayout.HORIZONTAL);
        presetRow2.addView(filterChip("Discipline", () -> applyMetricPreset("discipline")), weightLp());
        presetRow2.addView(filterChip("Luck", () -> applyMetricPreset("luck")), weightLp());
        presetRow2.addView(filterChip("All", () -> applyMetricPreset("all")), weightLp());
        filterBox.addView(presetRow2, matchWrap());

        metricChecks.clear();
        TextView individual = text("Individual stats", 12, MUTED, true);
        individual.setPadding(0, dp(8), 0, dp(2));
        filterBox.addView(individual);

        ArrayList<Metric> contextMetrics = metricsForCurrentContext();
        for (int i = 0; i < contextMetrics.size(); i += 2) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.addView(metricCheckChip(contextMetrics.get(i)), weightLp());
            if (i + 1 < contextMetrics.size()) row.addView(metricCheckChip(contextMetrics.get(i + 1)), weightLp());
            else row.addView(new Space(this), weightLp());
            filterBox.addView(row, matchWrap());
        }
    }

    private TextView filterChip(String label, Runnable onClick) {
        TextView tv = text(label, 13, INK, true);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(dp(8), dp(9), dp(8), dp(9));
        tv.setBackground(roundedStroke(Color.WHITE, LINE, 16, 1));
        tv.setOnClickListener(v -> onClick.run());
        return tv;
    }

    private CheckBox metricCheckChip(Metric m) {
        CheckBox cb = new CheckBox(this);
        cb.setText(m.label);
        cb.setTextColor(INK);
        cb.setTextSize(13);
        cb.setTypeface(Typeface.DEFAULT_BOLD);
        cb.setChecked(selectedMetricKeys.contains(m.key));
        cb.setButtonTintList(ColorStateList.valueOf(TEAL));
        cb.setPadding(dp(8), dp(6), dp(8), dp(6));
        cb.setBackground(roundedStroke(Color.rgb(248, 250, 253), LINE, 14, 1));
        cb.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (updatingMetricChecks) return;
            if (isChecked) selectedMetricKeys.add(m.key); else selectedMetricKeys.remove(m.key);
            refreshCurrentResults();
        });
        metricChecks.put(m.key, cb);
        return cb;
    }

    private void applyMetricPreset(String preset) {
        selectedMetricKeys.clear();
        selectedMetricKeys.addAll(metricKeysForPreset(preset));
        rebuildRankMetricSpinner();
        syncMetricChecks();
        updateMetricPickerLabel();
        refreshCurrentResults();
        refreshRankingsIfActive();
    }

    private void syncMetricChecks() {
        updatingMetricChecks = true;
        for (Map.Entry<String, CheckBox> e : metricChecks.entrySet()) e.getValue().setChecked(selectedMetricKeys.contains(e.getKey()));
        updatingMetricChecks = false;
    }

    private void wireEvents() {
        playerModeButton.setOnClickListener(v -> setMode(false));
        teamModeButton.setOnClickListener(v -> setMode(true));
        headToHeadButton.setOnClickListener(v -> setHeadToHeadMode(true));
        expectedViewButton.setOnClickListener(v -> setExpectedMode());

        searchInput.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { filterPlayers(s.toString()); }
            @Override public void afterTextChanged(Editable s) {}
        });
        searchInput.setOnEditorActionListener((v, actionId, event) -> {
            if ((actionId == EditorInfo.IME_ACTION_SEARCH || actionId == EditorInfo.IME_ACTION_DONE) && !filteredPlayers.isEmpty()) {
                selectedPlayer = filteredPlayers.get(0);
                searchInput.setText("");
                searchInput.clearFocus();
                suggestionsList.setVisibility(View.GONE);
                applySmartDefaultForSelection(selectedPlayer);
                renderSelectionPreview();
                hideKeyboard();
                refreshAfterPrimarySelection();
                return true;
            }
            return false;
        });

        compareSearchInput.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { filterComparePlayers(s.toString()); }
            @Override public void afterTextChanged(Editable s) {}
        });
        compareSearchInput.setOnEditorActionListener((v, actionId, event) -> {
            if ((actionId == EditorInfo.IME_ACTION_SEARCH || actionId == EditorInfo.IME_ACTION_DONE) && !filteredComparePlayers.isEmpty()) {
                comparePlayer = filteredComparePlayers.get(0);
                compareSearchInput.setText("");
                compareSearchInput.clearFocus();
                compareSuggestionsList.setVisibility(View.GONE);
                renderComparePreview();
                hideKeyboard();
                refreshHeadToHeadIfReady();
                return true;
            }
            return false;
        });

        suggestionsList.setOnItemClickListener((parent, view, position, id) -> {
            if (position < filteredPlayers.size()) {
                selectedPlayer = filteredPlayers.get(position);
                searchInput.setText("");
                searchInput.clearFocus();
                suggestionsList.setVisibility(View.GONE);
                applySmartDefaultForSelection(selectedPlayer);
                statusView.setText(isPitcher(selectedPlayer) ? "Pitcher selected · opening profile." : "Hitter selected · opening profile.");
                renderSelectionPreview();
                hideKeyboard();
                refreshAfterPrimarySelection();
            }
        });

        compareSuggestionsList.setOnItemClickListener((parent, view, position, id) -> {
            if (position < filteredComparePlayers.size()) {
                comparePlayer = filteredComparePlayers.get(position);
                compareSearchInput.setText("");
                compareSearchInput.clearFocus();
                compareSuggestionsList.setVisibility(View.GONE);
                statusView.setText("Second player selected · opening comparison.");
                renderComparePreview();
                hideKeyboard();
                refreshHeadToHeadIfReady();
            }
        });

        teamSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position >= 0 && position < allTeams.size()) {
                    selectedTeam = allTeams.get(position);
                    if (teamMode) {
                        buildTeamChips();
                        renderSelectionPreview();
                        statusView.setText("Team selected · opening profile.");
                        refreshAfterPrimarySelection();
                    }
                }
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });

        compareTeamSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position >= 0 && position < allTeams.size()) {
                    compareTeam = allTeams.get(position);
                    buildTeamChips();
                    if (teamMode && headToHeadMode) { renderComparePreview(); refreshHeadToHeadIfReady(); }
                }
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });

        seasonSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                try { selectedSeasonValue = Integer.parseInt(String.valueOf(parent.getItemAtPosition(position))); refreshSeasonChips(); } catch (Exception ignored) {}
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });

        rankMetricSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedRankMetricPosition = position <= 0 ? -1 : position - 1;
                refreshRankMetricChips();
                refreshRankingsIfActive();
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });

        metricPickerButton.setOnClickListener(v -> showMetricPicker());
        if (compareButton != null) compareButton.setOnClickListener(v -> compareSelected());
        standingsButton.setOnClickListener(v -> showStandings());
        copyButton.setOnClickListener(v -> copyCurrentTable());
        shareButton.setOnClickListener(v -> shareComparisonAsImage());
    }

    private void setMode(boolean useTeamMode) {
        boolean wasRankings = rankingsModeActive;
        teamMode = useTeamMode;
        expectedMode = false;
        playerModeButton.setTextColor(teamMode ? NAVY : Color.WHITE);
        playerModeButton.setBackground(teamMode ? roundedStroke(Color.WHITE, LINE, 16, 1) : rounded(NAVY, 16));
        teamModeButton.setTextColor(teamMode ? Color.WHITE : NAVY);
        teamModeButton.setBackground(teamMode ? rounded(NAVY, 16) : roundedStroke(Color.WHITE, LINE, 16, 1));
        searchInput.setVisibility(teamMode ? View.GONE : View.VISIBLE);
        suggestionsList.setVisibility(View.GONE);
        if (teamSpinner != null) teamSpinner.setVisibility(View.GONE);
        if (teamChipRow != null) teamChipRow.setVisibility(teamMode ? View.VISIBLE : View.GONE);
        buildTeamChips();
        applyHeadToHeadVisibility();
        selectedMetricKeys.clear();
        selectedMetricKeys.addAll(metricKeysForPreset("all"));
        selectedRankMetricPosition = -1;
        rebuildRankMetricSpinner();
        updateMetricPickerLabel();
        statusView.setText(statusTextForMode());
        renderSelectionPreview();
        renderComparePreview();
        rankingsModeActive = wasRankings;
        headToHeadMode = false;
        expectedMode = false;
        updateAnalysisModeButtons();
        updateViewModeButtons();
        resultsBox.setVisibility(View.GONE);
        standingsBox.removeAllViews();
        if (rankingsModeActive) {
            showStandings();
        } else if ((teamMode && selectedTeam != null) || (!teamMode && selectedPlayer != null)) {
            openProfileForCurrentSelection();
        }
    }

    private int currentSeason() {
        return selectedSeasonValue > 0 ? selectedSeasonValue : Calendar.getInstance().get(Calendar.YEAR);
    }

    private void setHeadToHeadMode(boolean useHeadToHead) {
        headToHeadMode = useHeadToHead;
        rankingsModeActive = false;
        expectedMode = false;
        updateAnalysisModeButtons();
        applyHeadToHeadVisibility();
        updateViewModeButtons();
        statusView.setText(statusTextForMode());
        renderComparePreview();
        standingsBox.removeAllViews();
        if (!refreshHeadToHeadIfReady()) resultsBox.setVisibility(View.GONE);
    }

    private void setExpectedMode() {
        headToHeadMode = false;
        rankingsModeActive = false;
        expectedMode = true;
        updateAnalysisModeButtons();
        applyHeadToHeadVisibility();
        updateViewModeButtons();
        statusView.setText(statusTextForMode());
        renderComparePreview();
        standingsBox.removeAllViews();
        if (!refreshExpectedIfReady()) resultsBox.setVisibility(View.GONE);
    }

    private boolean refreshHeadToHeadIfReady() {
        if (!headToHeadMode || isBusy()) return false;
        if (teamMode) {
            if (selectedTeam == null || compareTeam == null || selectedTeam.key().equals(compareTeam.key())) return false;
            compareTeamsSideBySide(selectedTeam, compareTeam, currentSeason());
            return true;
        }
        if (selectedPlayer == null || comparePlayer == null || selectedPlayer.id == comparePlayer.id) return false;
        comparePlayersSideBySide(selectedPlayer, comparePlayer, currentSeason());
        return true;
    }

    private boolean refreshExpectedIfReady() {
        if (!expectedMode || isBusy()) return false;
        if (teamMode) {
            if (selectedTeam == null) return false;
            compareTeam(selectedTeam, currentSeason());
            return true;
        }
        if (selectedPlayer == null) return false;
        comparePlayer(selectedPlayer, currentSeason());
        return true;
    }

    private void updateAnalysisModeButtons() {
        updateViewModeButtons();
    }

    private void applyHeadToHeadVisibility() {
        int show = headToHeadMode ? View.VISIBLE : View.GONE;
        if (compareSelectorLabel != null) compareSelectorLabel.setVisibility(show);
        if (compareSearchInput != null) compareSearchInput.setVisibility(headToHeadMode && !teamMode ? View.VISIBLE : View.GONE);
        if (compareTeamSpinner != null) compareTeamSpinner.setVisibility(View.GONE);
        if (compareTeamChipRow != null) compareTeamChipRow.setVisibility(headToHeadMode && teamMode ? View.VISIBLE : View.GONE);
        if (compareSuggestionsList != null) compareSuggestionsList.setVisibility(View.GONE);
        if (comparePreviewBox != null) comparePreviewBox.setVisibility(show);
    }

    private String statusTextForMode() {
        if (headToHeadMode) {
            return teamMode ? "Pick a second team — comparison opens automatically." : "Pick a second player — comparison opens automatically.";
        }
        if (expectedMode) {
            return teamMode ? "Actual vs expected opens for the selected team." : (selectedPlayer == null ? "Search and select a player first." : "Actual vs expected opens automatically.");
        }
        return teamMode ? "Pick a team. Profile opens automatically; tap Rankings for leaderboards." : (selectedPlayer == null ? "Search and select a player first." : "Profile opens automatically. Compare, xStats, and Rankings update immediately.");
    }

    private void loadTeamsAndPlayers() {
        setBusy(true, "Loading MLB teams and active players…");
        io.execute(() -> {
            try {
                LoadedData loaded = fetchTeamsAndActivePlayers();
                main.post(() -> {
                    allTeams.clear(); allTeams.addAll(loaded.teams);
                    allPlayers.clear(); allPlayers.addAll(loaded.players);
                    teamAdapter.clear();
                    compareTeamAdapter.clear();
                    for (Team t : allTeams) {
                        teamAdapter.add(t.name);
                        compareTeamAdapter.add(t.name);
                    }
                    teamAdapter.notifyDataSetChanged();
                    compareTeamAdapter.notifyDataSetChanged();
                    selectedTeam = null;
                    if (allTeams.size() > 1) compareTeam = allTeams.get(1); else if (!allTeams.isEmpty()) compareTeam = allTeams.get(0);
                    if (compareTeamSpinner != null && allTeams.size() > 1) compareTeamSpinner.setSelection(1);
                    buildTeamChips();
                    statusView.setText("Ready · search a hitter/pitcher or pick a team");
                    renderSelectionPreview();
                    setBusy(false, null);
                });
            } catch (Exception e) {
                main.post(() -> {
                    setBusy(false, null);
                    showError("Could not load MLB team/player list. Check connection and tap Retry.\n" + e.getMessage());
                    statusView.setText("Roster list unavailable.");
                });
            }
        });
    }

    private void filterPlayers(String raw) {
        if (teamMode) return;
        filteredPlayers.clear();
        String q = raw.trim().toLowerCase(Locale.US);
        if (q.length() < 2 || allPlayers.isEmpty()) {
            suggestionsList.setVisibility(View.GONE);
            suggestionsAdapter.notifyDataSetChanged();
            return;
        }
        for (Player p : allPlayers) {
            if (p.searchKey.contains(q)) {
                filteredPlayers.add(p);
                if (filteredPlayers.size() >= 24) break;
            }
        }
        suggestionsAdapter.notifyDataSetChanged();
        suggestionsList.setVisibility(filteredPlayers.isEmpty() ? View.GONE : View.VISIBLE);
    }

    private void filterComparePlayers(String raw) {
        if (teamMode || !headToHeadMode) return;
        filteredComparePlayers.clear();
        String q = raw.trim().toLowerCase(Locale.US);
        if (q.length() < 2 || allPlayers.isEmpty()) {
            compareSuggestionsList.setVisibility(View.GONE);
            compareSuggestionsAdapter.notifyDataSetChanged();
            return;
        }
        for (Player p : allPlayers) {
            if (selectedPlayer != null && p.id == selectedPlayer.id) continue;
            if (p.searchKey.contains(q)) {
                filteredComparePlayers.add(p);
                if (filteredComparePlayers.size() >= 24) break;
            }
        }
        compareSuggestionsAdapter.notifyDataSetChanged();
        compareSuggestionsList.setVisibility(filteredComparePlayers.isEmpty() ? View.GONE : View.VISIBLE);
    }

    private void renderComparePreview() {
        if (comparePreviewBox == null) return;
        comparePreviewBox.removeAllViews();
        boolean hasSelection = headToHeadMode && (teamMode ? compareTeam != null : comparePlayer != null);
        comparePreviewBox.setVisibility(hasSelection ? View.VISIBLE : View.GONE);
        if (!hasSelection) return;

        TeamPalette palette = teamMode ? paletteForTeam(compareTeam) : paletteForAbbr(comparePlayer.teamAbbr);
        comparePreviewBox.setBackground(roundedGradient(new int[] { softColor(palette.primary, 0.20f), palette.primary, palette.secondary }, 20));

        if (teamMode) {
            View logo = teamLogoView(compareTeam, 46);
            LinearLayout.LayoutParams logoLp = new LinearLayout.LayoutParams(dp(46), dp(46));
            logoLp.setMargins(0, 0, dp(11), 0);
            comparePreviewBox.addView(logo, logoLp);
            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);
            col.addView(text(compareTeam.name, 16, Color.WHITE, true));
            col.addView(text("Head-to-head opponent · " + compareTeam.abbr, 11, Color.rgb(228, 238, 248), false));
            comparePreviewBox.addView(col, new LinearLayout.LayoutParams(0, -2, 1));
        } else {
            ImageView img = new ImageView(this);
            img.setScaleType(ImageView.ScaleType.FIT_CENTER);
            img.setAdjustViewBounds(true);
            img.setBackground(roundedStroke(Color.WHITE, Color.argb(90, 255, 255, 255), 18, 1));
            img.setPadding(dp(2), dp(2), dp(2), dp(2));
            LinearLayout.LayoutParams imgLp = new LinearLayout.LayoutParams(dp(46), dp(46));
            imgLp.setMargins(0, 0, dp(11), 0);
            comparePreviewBox.addView(img, imgLp);
            loadPlayerImage(comparePlayer.id, img);
            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);
            col.addView(text(comparePlayer.fullName, 16, Color.WHITE, true));
            col.addView(text("Opponent · " + comparePlayer.teamAbbr + " · " + comparePlayer.position, 11, Color.rgb(228, 238, 248), false));
            comparePreviewBox.addView(col, new LinearLayout.LayoutParams(0, -2, 1));
        }
        TextView hint = text("VS", 11, Color.WHITE, true);
        hint.setGravity(Gravity.CENTER);
        hint.setPadding(dp(10), dp(5), dp(10), dp(5));
        hint.setBackground(roundedStroke(Color.argb(34, 255, 255, 255), Color.argb(80, 255, 255, 255), 14, 1));
        comparePreviewBox.addView(hint);
    }

    private void compareSelected() {
        hideKeyboard();
        showError(null);
        rankingsModeActive = false;
        updateViewModeButtons();
        standingsBox.removeAllViews();
        int season = currentSeason();
        if (headToHeadMode) {
            compareSideBySideSelected(season);
            return;
        }
        lastHeadToHead = null;
        if (teamMode) {
            if (selectedTeam == null) { showError("Pick a team first."); return; }
            compareTeam(selectedTeam, season);
        } else {
            if (selectedPlayer == null) { showError("Pick a player from the search results first."); return; }
            comparePlayer(selectedPlayer, season);
        }
    }

    private void compareSideBySideSelected(int season) {
        if (teamMode) {
            if (selectedTeam == null || compareTeam == null) { showError("Pick two teams first."); return; }
            if (selectedTeam.key().equals(compareTeam.key())) { showError("Pick two different teams."); return; }
            compareTeamsSideBySide(selectedTeam, compareTeam, season);
        } else {
            if (selectedPlayer == null || comparePlayer == null) { showError("Pick two players first."); return; }
            if (selectedPlayer.id == comparePlayer.id) { showError("Pick two different players."); return; }
            comparePlayersSideBySide(selectedPlayer, comparePlayer, season);
        }
    }

    private void comparePlayer(Player player, int season) {
        showProfileSkeleton();  // v29: skeleton while season data loads
        setBusy(true, "Loading selected season…");
        io.execute(() -> {
            try {
                ArrayList<LeaderboardEntry> entries = fetchLeaderboardForPlayer(player, season);
                LeaderboardEntry seasonEntry = findPlayerEntry(entries, player);
                Stats seasonStats = seasonEntry == null ? new Stats() : seasonEntry.stats;
                Stats leagueStats = computeLeagueAverage(entries);
                ArrayList<Metric> displayed = selectedMetricsForRows();
                HashMap<String, Integer> ranks = computePlayerRankMap(entries, season, player.id, displayed);
                HashMap<String, Integer> totals = computePlayerRankTotalMap(entries, season, displayed);
                HashMap<String, Double> percentiles = percentileMap(ranks, totals);
                Stats pendingCareer = new Stats();
                Comparison quick = new Comparison(false, player.fullName, player.teamAbbr, player.position, player.id, season, seasonStats, pendingCareer, leagueStats, new Date(), "Career loading…", player, null, ranks, totals, percentiles, new HashMap<>());
                main.post(() -> {
                    lastComparison = quick;
                    if (expectedMode) renderExpectedComparison(quick); else renderComparison(quick);
                    setBusy(false, expectedMode ? "Actual + expected loaded. Career numbers are filling in…" : "Season + league loaded. Career numbers are filling in…");
                });

                Stats careerStats = fetchPlayerCareerStats(player, season);
                LinkedHashMap<Integer, Stats> recentSeasons = fetchPlayerRecentSeasonStats(player, season);
                LinkedHashMap<String, Stats> recentWindows = fetchPlayerRecentWindows(player, season);
                Map<String, ArrayList<TrendPoint>> seasonTrends = fetchPlayerSeasonTrendMap(player, season);
                HashMap<String, Double> careerPercentiles = valuePercentileMapForPlayerEntries(entries, season, careerStats, displayed);
                Comparison complete = new Comparison(false, player.fullName, player.teamAbbr, player.position, player.id, season, seasonStats, careerStats, leagueStats, new Date(), "Career", player, null, ranks, totals, percentiles, careerPercentiles, recentSeasons, seasonTrends, recentWindows);
                main.post(() -> {
                    if (!teamMode && selectedPlayer != null && selectedPlayer.id == player.id && currentSeason() == season) {
                        lastComparison = complete;
                        if (expectedMode) renderExpectedComparison(complete); else renderComparison(complete);
                        statusView.setText(expectedMode ? "Complete · actual vs expected loaded" : "Complete · season, league, and career loaded");
                    }
                });
            } catch (Exception e) {
                main.post(() -> {
                    setBusy(false, null);
                    showError("Could not load player comparison. Baseball Savant may be slow/rate-limiting, or this player may have no leaderboard row for the selected season. " + e.getMessage());
                });
            }
        });
    }

    private void compareTeam(Team team, int season) {
        showProfileSkeleton();  // v29: skeleton while season data loads
        setBusy(true, "Loading selected season…");
        io.execute(() -> {
            try {
                ArrayList<LeaderboardEntry> entries = fetchLeaderboardForSelectedMetrics(season);
                Stats teamStats = aggregateTeamStats(entries).get(team.key());
                if (teamStats == null) teamStats = new Stats();
                Stats leagueStats = computeLeagueAverage(entries);
                ArrayList<Metric> displayed = selectedMetricsForRows();
                Map<String, Stats> teamStatsMap = aggregateTeamStats(entries);
                HashMap<String, Integer> ranks = computeTeamRankMap(teamStatsMap, team.key(), displayed);
                HashMap<String, Integer> totals = computeTeamRankTotalMap(teamStatsMap, displayed);
                HashMap<String, Double> percentiles = percentileMap(ranks, totals);
                Stats pendingHistory = new Stats();
                Comparison quick = new Comparison(true, team.name, team.abbr, "Team", 0, season, teamStats, pendingHistory, leagueStats, new Date(), "History loading…", null, team, ranks, totals, percentiles, new HashMap<>());
                main.post(() -> {
                    lastComparison = quick;
                    if (expectedMode) renderExpectedComparison(quick); else renderComparison(quick);
                    setBusy(false, expectedMode ? "Actual + expected loaded. Team history is filling in…" : "Season + league loaded. Team history is filling in…");
                });

                Stats historyStats = fetchTeamHistoryStats(team, season);
                LinkedHashMap<Integer, Stats> recentSeasons = fetchTeamRecentSeasonStats(team, season);
                Map<String, ArrayList<TrendPoint>> seasonTrends = fetchTeamSeasonTrendMap(team, season);
                HashMap<String, Double> historyPercentiles = valuePercentileMapForTeams(teamStatsMap, historyStats, displayed);
                Comparison complete = new Comparison(true, team.name, team.abbr, "Team", 0, season, teamStats, historyStats, leagueStats, new Date(), "2015–" + season + " team avg", null, team, ranks, totals, percentiles, historyPercentiles, recentSeasons, seasonTrends, new LinkedHashMap<>());
                main.post(() -> {
                    if (teamMode && selectedTeam != null && selectedTeam.key().equals(team.key()) && currentSeason() == season) {
                        lastComparison = complete;
                        if (expectedMode) renderExpectedComparison(complete); else renderComparison(complete);
                        statusView.setText(expectedMode ? "Complete · actual vs expected loaded" : "Complete · season, league, and team history loaded");
                    }
                });
            } catch (Exception e) {
                main.post(() -> {
                    setBusy(false, null);
                    showError("Could not load team comparison. " + e.getMessage());
                });
            }
        });
    }

    private void comparePlayersSideBySide(Player a, Player b, int season) {
        showProfileSkeleton();  // v29: skeleton while H2H loads
        setBusy(true, "Loading player side-by-side…");
        io.execute(() -> {
            try {
                ArrayList<LeaderboardEntry> entries = (isPitcher(a) || isPitcher(b)) ? fetchPitchingLeaderboard(season) : fetchLeaderboard(season);
                LeaderboardEntry entryA = findPlayerEntry(entries, a);
                LeaderboardEntry entryB = findPlayerEntry(entries, b);
                Stats statsA = entryA == null ? new Stats() : entryA.stats;
                Stats statsB = entryB == null ? new Stats() : entryB.stats;
                Stats leagueStats = computeLeagueAverage(entries);
                ArrayList<Metric> displayed = selectedMetricsForRows();
                HashMap<String, Integer> ranksA = computePlayerRankMap(entries, season, a.id, displayed);
                HashMap<String, Integer> ranksB = computePlayerRankMap(entries, season, b.id, displayed);
                HashMap<String, Integer> totals = computePlayerRankTotalMap(entries, season, displayed);
                HeadToHeadComparison h = new HeadToHeadComparison(false, a.fullName, b.fullName, a.teamAbbr + " · " + a.position, b.teamAbbr + " · " + b.position, a.id, b.id, season, statsA, statsB, leagueStats, a, b, null, null, ranksA, ranksB, totals, totals, percentileMap(ranksA, totals), percentileMap(ranksB, totals));
                main.post(() -> {
                    lastComparison = null;
                    lastHeadToHead = h;
                    renderHeadToHead(h);
                    setBusy(false, "Loaded side-by-side for " + season);
                });
            } catch (Exception e) {
                main.post(() -> {
                    setBusy(false, null);
                    showError("Could not load side-by-side player comparison. " + e.getMessage());
                });
            }
        });
    }

    private void compareTeamsSideBySide(Team a, Team b, int season) {
        showProfileSkeleton();  // v29: skeleton while H2H loads
        setBusy(true, "Loading team side-by-side…");
        io.execute(() -> {
            try {
                ArrayList<LeaderboardEntry> entries = fetchLeaderboardForSelectedMetrics(season);
                Map<String, Stats> teams = aggregateTeamStats(entries);
                Stats statsA = teams.get(a.key()); if (statsA == null) statsA = new Stats();
                Stats statsB = teams.get(b.key()); if (statsB == null) statsB = new Stats();
                Stats leagueStats = computeLeagueAverage(entries);
                ArrayList<Metric> displayed = selectedMetricsForRows();
                HashMap<String, Integer> ranksA = computeTeamRankMap(teams, a.key(), displayed);
                HashMap<String, Integer> ranksB = computeTeamRankMap(teams, b.key(), displayed);
                HashMap<String, Integer> totals = computeTeamRankTotalMap(teams, displayed);
                HeadToHeadComparison h = new HeadToHeadComparison(true, a.name, b.name, a.abbr, b.abbr, 0, 0, season, statsA, statsB, leagueStats, null, null, a, b, ranksA, ranksB, totals, totals, percentileMap(ranksA, totals), percentileMap(ranksB, totals));
                main.post(() -> {
                    lastComparison = null;
                    lastHeadToHead = h;
                    renderHeadToHead(h);
                    setBusy(false, "Loaded side-by-side for " + season);
                });
            } catch (Exception e) {
                main.post(() -> {
                    setBusy(false, null);
                    showError("Could not load side-by-side team comparison. " + e.getMessage());
                });
            }
        });
    }

    private void showStandings() {
        hideKeyboard();
        showError(null);
        headToHeadMode = false;
        expectedMode = false;
        rankingsModeActive = true;
        applyHeadToHeadVisibility();
        updateAnalysisModeButtons();
        rebuildRankMetricSpinner();
        updateViewModeButtons();
        resultsBox.setVisibility(View.GONE);
        int season = currentSeason();
        Metric metric = selectedRankMetric();
        if (metric == null) {
            showAllSelectedRankings(season);
            return;
        }
        setBusy(true, "Loading " + (teamMode ? "team" : "player") + " rankings…");
        io.execute(() -> {
            try {
                ArrayList<LeaderboardEntry> entries = fetchLeaderboardForMetric(season, metric);
                if (teamMode) renderTeamStandingsAsync(entries, season, metric);
                else renderPlayerStandingsAsync(entries, season, metric);
            } catch (Exception e) {
                main.post(() -> {
                    setBusy(false, null);
                    showError("Could not load rankings. " + e.getMessage());
                });
            }
        });
    }

    private void showAllSelectedRankings(int season) {
        setBusy(true, "Loading rankings across selected stats…");
        io.execute(() -> {
            try {
                ArrayList<Metric> selected = selectedRankingMetrics();
                if (teamMode) renderTeamAllStatsRankingsAsync(season, selected);
                else renderPlayerAllStatsRankingsAsync(season, selected);
            } catch (Exception e) {
                main.post(() -> {
                    setBusy(false, null);
                    showError("Could not load all-stat rankings. " + e.getMessage());
                });
            }
        });
    }

    private boolean hasRankingContextSelection(boolean teamRows) {
        return teamRows ? selectedTeam != null : selectedPlayer != null;
    }

    private void addRankingScopeToggle(LinearLayout card, boolean teamRows) {
        if (!hasRankingContextSelection(teamRows)) return;
        LinearLayout scope = new LinearLayout(this);
        scope.setOrientation(LinearLayout.HORIZONTAL);
        scope.setGravity(Gravity.CENTER_VERTICAL);
        scope.setPadding(0, dp(2), 0, dp(8));
        TextView league = choiceChip("League leaders", generalRankingsMode);
        league.setOnClickListener(v -> { generalRankingsMode = true; showStandings(); });
        TextView selected = choiceChip(teamRows ? "Selected team" : "Selected player", !generalRankingsMode);
        selected.setOnClickListener(v -> { generalRankingsMode = false; showStandings(); });
        scope.addView(league, new LinearLayout.LayoutParams(0, -2, 1));
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(0, -2, 1);
        sp.setMargins(dp(7), 0, 0, 0);
        scope.addView(selected, sp);
        card.addView(scope, matchWrap());
    }

    private void renderPlayerStandingsAsync(ArrayList<LeaderboardEntry> entries, int season, Metric metric) {
        ArrayList<LeaderboardEntry> eligible = eligiblePlayerEntries(entries, season, metric);
        main.post(() -> {
            renderPlayerStandings(eligible, season, metric);
            setBusy(false, null);
        });
    }

    private void renderTeamStandingsAsync(ArrayList<LeaderboardEntry> entries, int season, Metric metric) {
        Map<String, Stats> teamStats = aggregateTeamStats(entries);
        ArrayList<TeamStanding> teams = new ArrayList<>();
        for (Team t : allTeams) {
            Stats s = teamStats.get(t.key());
            if (s != null && s.get(metric.key) != null) teams.add(new TeamStanding(t, s));
        }
        teams.sort((a, b) -> compareMetricValues(a.stats.get(metric.key), b.stats.get(metric.key), metric));
        main.post(() -> {
            renderTeamStandings(teams, season, metric);
            setBusy(false, null);
        });
    }

    private ArrayList<LeaderboardEntry> eligiblePlayerEntries(ArrayList<LeaderboardEntry> entries, int season, Metric metric) {
        ArrayList<LeaderboardEntry> eligible = new ArrayList<>();
        for (LeaderboardEntry e : entries) {
            Double val = e.stats.get(metric.key);
            if (val == null) continue;
            int minPa = season == Calendar.getInstance().get(Calendar.YEAR) ? 50 : 100;
            int minBbe = season == Calendar.getInstance().get(Calendar.YEAR) ? 25 : 50;
            boolean contactMetric = metric.type.equals("contact") || metric.type.equals("rate");
            boolean pitchingMetric = "pitch".equals(metric.side);
            boolean eligibleSample = pitchingMetric ? (e.stats.ip >= (season == Calendar.getInstance().get(Calendar.YEAR) ? 10 : 25) || e.stats.pa >= minPa) : (e.stats.pa >= minPa && (!contactMetric || e.stats.bbe >= minBbe));
            if (eligibleSample) eligible.add(e);
        }
        sortEntries(eligible, metric);
        return eligible;
    }

    private void renderPlayerAllStatsRankingsAsync(int season, ArrayList<Metric> selected) throws Exception {
        ArrayList<AllRankRow> rows = new ArrayList<>();
        for (Metric m : selected) {
            ArrayList<LeaderboardEntry> entries = eligiblePlayerEntries(fetchLeaderboardForMetric(season, m), season, m);
            if (entries.isEmpty()) continue;
            LeaderboardEntry leader = entries.get(0);
            if (generalRankingsMode || selectedPlayer == null) {
                rows.add(new AllRankRow(m, 1, entries.size(), leader.name, leader.stats.get(m.key), leader.name, leader.stats.get(m.key), leader.playerId, null));
            } else {
                int rank = selectedPlayerRank(entries);
                LeaderboardEntry mine = rank > 0 ? entries.get(rank - 1) : null;
                rows.add(new AllRankRow(m, rank, entries.size(), mine == null ? selectedPlayer.fullName : mine.name, mine == null ? null : mine.stats.get(m.key), leader.name, leader.stats.get(m.key), selectedPlayer.id, null));
            }
        }
        main.post(() -> {
            renderAllStatsRankings(rows, season, false);
            setBusy(false, null);
        });
    }

    private void renderTeamAllStatsRankingsAsync(int season, ArrayList<Metric> selected) throws Exception {
        ArrayList<AllRankRow> rows = new ArrayList<>();
        for (Metric m : selected) {
            Map<String, Stats> teamStats = aggregateTeamStats(fetchLeaderboardForMetric(season, m));
            ArrayList<TeamStanding> teams = new ArrayList<>();
            for (Team t : allTeams) {
                Stats s = teamStats.get(t.key());
                if (s != null && s.get(m.key) != null) teams.add(new TeamStanding(t, s));
            }
            teams.sort((a, b) -> compareMetricValues(a.stats.get(m.key), b.stats.get(m.key), m));
            if (teams.isEmpty()) continue;
            TeamStanding leader = teams.get(0);
            if (generalRankingsMode || selectedTeam == null) {
                rows.add(new AllRankRow(m, 1, teams.size(), leader.team.name, leader.stats.get(m.key), leader.team.name, leader.stats.get(m.key), 0, leader.team));
            } else {
                int rank = selectedTeamRank(teams);
                TeamStanding mine = rank > 0 ? teams.get(rank - 1) : null;
                rows.add(new AllRankRow(m, rank, teams.size(), mine == null ? selectedTeam.name : mine.team.name, mine == null ? null : mine.stats.get(m.key), leader.team.name, leader.stats.get(m.key), 0, selectedTeam));
            }
        }
        main.post(() -> {
            renderAllStatsRankings(rows, season, true);
            setBusy(false, null);
        });
    }

    private void renderAllStatsRankings(ArrayList<AllRankRow> rows, int season, boolean teamRows) {
        standingsBox.removeAllViews();
        LinearLayout card = verticalCard(22, null);
        card.setPadding(dp(14), dp(14), dp(14), dp(14));
        standingsBox.addView(card, matchWrap());
        String subject = teamRows ? ((generalRankingsMode || selectedTeam == null) ? "Team leaders" : selectedTeam.name) : ((generalRankingsMode || selectedPlayer == null) ? "Player leaders" : selectedPlayer.fullName);
        card.addView(text(subject, 20, INK, true));
        addRankingScopeToggle(card, teamRows);
        TextView sub = text(season + " season · rank, value, and current leader", 12, MUTED, false);
        sub.setPadding(0, dp(3), 0, dp(8));
        card.addView(sub);
        lastStandingsText = subject + " " + season + " rankings across selected stats\nMetric\tRank\tValue\tLeader\tLeader Value\n";
        if (rows.isEmpty()) {
            TextView empty = text("No ranking rows found for the selected stats. Try a different stat preset.", 14, MUTED, false);
            empty.setPadding(0, dp(10), 0, dp(10));
            card.addView(empty);
        }
        for (AllRankRow r : rows) {
            card.addView(allRankRow(r, teamRows));
            lastStandingsText += r.metric.label + "\t" + (r.rank > 0 ? "#" + r.rank + " of " + r.total : "Not ranked") + "\t" + format(r.value, r.metric) + "\t" + r.leaderName + "\t" + format(r.leaderValue, r.metric) + "\n";
        }
        resultsBox.setVisibility(View.GONE);
    }

    private View allRankRow(AllRankRow r, boolean teamRows) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(8), dp(8), dp(8), dp(8));
        row.setBackground(rounded(Color.WHITE, 13));
        row.setForeground(ripple(false));
        row.setClickable(true);
        row.setOnClickListener(v -> openProfileFromRanking(r, teamRows));

        if (teamRows && r.team != null) {
            View logo = teamLogoView(r.team, 34);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(34), dp(34));
            lp.setMargins(0, 0, dp(8), 0);
            row.addView(logo, lp);
        } else if (!teamRows && r.playerId > 0) {
            ImageView avatar = new ImageView(this);
            avatar.setScaleType(ImageView.ScaleType.FIT_CENTER);
            avatar.setBackground(roundedStroke(Color.rgb(235, 241, 248), LINE, 17, 1));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(34), dp(34));
            lp.setMargins(0, 0, dp(8), 0);
            row.addView(avatar, lp);
            loadPlayerImage(r.playerId, avatar);
        }

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        String rankText = r.rank > 0 ? "#" + r.rank + " of " + r.total : "Not ranked";
        col.addView(text(r.metric.label + " · " + rankText, 13, INK, true));
        col.addView(text("Leader: " + r.leaderName + " " + format(r.leaderValue, r.metric), 10, MUTED, false));
        row.addView(col, new LinearLayout.LayoutParams(0, -2, 1));

        TextView val = text(format(r.value, r.metric), 14, NAVY, true);
        val.setGravity(Gravity.RIGHT);
        row.addView(val);

        LinearLayout.LayoutParams lp = matchWrap();
        lp.setMargins(0, dp(3), 0, dp(3));
        row.setLayoutParams(lp);
        return row;
    }

    private void openProfileFromRanking(AllRankRow r, boolean teamRows) {
        if (r == null) return;
        rankingsModeActive = false;
        generalRankingsMode = false;
        if (teamRows) {
            Team t = r.team;
            if (t == null) t = findTeamByName(r.subjectName);
            if (t == null) t = findTeamByName(r.leaderName);
            if (t != null) {
                teamMode = true;
                selectedTeam = t;
                if (teamSpinner != null) teamSpinner.setSelection(Math.max(0, allTeams.indexOf(t)));
                setMode(true);
            }
        } else if (r.playerId > 0) {
            Player p = findPlayerById(r.playerId);
            if (p != null) {
                teamMode = false;
                selectedPlayer = p;
                applySmartDefaultForSelection(p);
                setMode(false);
            }
        }
        updateViewModeButtons();
        renderSelectionPreview();
        openProfileForCurrentSelection();
    }

    private ArrayList<Metric> selectedMetricsForRows() {
        ArrayList<Metric> out = new ArrayList<>();
        for (Metric m : metrics) if (selectedMetricKeys.contains(m.key)) out.add(m);
        return out;
    }

    private HashMap<String, Integer> computePlayerRankMap(ArrayList<LeaderboardEntry> entries, int season, int playerId, ArrayList<Metric> metricList) {
        HashMap<String, Integer> ranks = new HashMap<>();
        if (playerId <= 0) return ranks;
        for (Metric m : metricList) {
            ArrayList<LeaderboardEntry> eligible = eligiblePlayerEntries(entries, season, m);
            for (int i = 0; i < eligible.size(); i++) {
                if (eligible.get(i).playerId == playerId) {
                    ranks.put(m.key, i + 1);
                    break;
                }
            }
        }
        return ranks;
    }

    private HashMap<String, Integer> computeTeamRankMap(Map<String, Stats> teamStats, String teamKey, ArrayList<Metric> metricList) {
        HashMap<String, Integer> ranks = new HashMap<>();
        for (Metric m : metricList) {
            ArrayList<TeamStanding> teams = new ArrayList<>();
            for (Team t : allTeams) {
                Stats s = teamStats.get(t.key());
                if (s != null && s.get(m.key) != null) teams.add(new TeamStanding(t, s));
            }
            teams.sort((a, b) -> compareMetricValues(a.stats.get(m.key), b.stats.get(m.key), m));
            for (int i = 0; i < teams.size(); i++) {
                if (teams.get(i).team.key().equals(teamKey)) {
                    ranks.put(m.key, i + 1);
                    break;
                }
            }
        }
        return ranks;
    }

    private HashMap<String, Integer> computePlayerRankTotalMap(ArrayList<LeaderboardEntry> entries, int season, ArrayList<Metric> metricList) {
        HashMap<String, Integer> totals = new HashMap<>();
        for (Metric m : metricList) totals.put(m.key, eligiblePlayerEntries(entries, season, m).size());
        return totals;
    }

    private HashMap<String, Integer> computeTeamRankTotalMap(Map<String, Stats> teamStats, ArrayList<Metric> metricList) {
        HashMap<String, Integer> totals = new HashMap<>();
        for (Metric m : metricList) {
            int total = 0;
            for (Team t : allTeams) {
                Stats s = teamStats.get(t.key());
                if (s != null && s.get(m.key) != null) total++;
            }
            totals.put(m.key, total);
        }
        return totals;
    }

    private HashMap<String, Double> percentileMap(Map<String, Integer> ranks, Map<String, Integer> totals) {
        HashMap<String, Double> out = new HashMap<>();
        if (ranks == null || totals == null) return out;
        for (String key : ranks.keySet()) {
            Double pct = percentileFromRank(ranks.get(key), totals.get(key));
            if (pct != null) out.put(key, pct);
        }
        return out;
    }

    private Double percentileFromRank(Integer rank, Integer total) {
        if (rank == null || total == null || rank <= 0 || total <= 0) return null;
        if (total == 1) return 100.0;
        return Math.max(0, Math.min(100, 100.0 * (total - rank) / (double) (total - 1)));
    }

    private String percentileLabel(Double pct) {
        if (pct == null || Double.isNaN(pct)) return "—";
        return Math.round(Math.max(0, Math.min(100, pct))) + "% percentile";
    }

    private String rankPercentileLabel(Integer rank, Integer total, Double pct) {
        String rankText = rank == null || rank <= 0 ? "Not ranked" : "#" + rank + (total == null || total <= 0 ? "" : " of " + total);
        String pctText = pct == null ? "" : " · " + percentileLabel(pct);
        return rankText + pctText;
    }

    private String rankOnlyLabel(Integer rank, Integer total) {
        if (rank == null || rank <= 0) return "Not ranked";
        return "#" + rank + (total == null || total <= 0 ? "" : " of " + total);
    }

    private String percentileBigLabel(Double pct) {
        if (pct == null || Double.isNaN(pct)) return "—";
        return Math.round(Math.max(0, Math.min(100, pct))) + "%";
    }

    /** v30: Returns a tier label from a percentile value. */
    private String percentileTierLabel(Double pct) {
        if (pct == null || Double.isNaN(pct)) return "—";
        int p = (int) Math.round(Math.max(0, Math.min(100, pct)));
        if (p >= 95) return "Elite";
        if (p >= 80) return "Great";
        if (p >= 60) return "Above avg";
        if (p >= 40) return "Average";
        if (p >= 20) return "Below avg";
        return "Poor";
    }

    private HashMap<String, Double> valuePercentileMapForPlayerEntries(ArrayList<LeaderboardEntry> entries, int season, Stats stats, ArrayList<Metric> metricList) {
        HashMap<String, Double> out = new HashMap<>();
        if (stats == null) return out;
        for (Metric m : metricList) {
            Double value = stats.get(m.key);
            if (value == null || Double.isNaN(value)) continue;
            ArrayList<Double> vals = new ArrayList<>();
            for (LeaderboardEntry e : eligiblePlayerEntries(entries, season, m)) {
                Double v = e.stats.get(m.key);
                if (v != null && !Double.isNaN(v)) vals.add(v);
            }
            Double pct = percentileForValue(vals, value, m);
            if (pct != null) out.put(m.key, pct);
        }
        return out;
    }

    private HashMap<String, Double> valuePercentileMapForTeams(Map<String, Stats> teamStats, Stats stats, ArrayList<Metric> metricList) {
        HashMap<String, Double> out = new HashMap<>();
        if (stats == null) return out;
        for (Metric m : metricList) {
            Double value = stats.get(m.key);
            if (value == null || Double.isNaN(value)) continue;
            ArrayList<Double> vals = new ArrayList<>();
            for (Stats s : teamStats.values()) {
                Double v = s.get(m.key);
                if (v != null && !Double.isNaN(v)) vals.add(v);
            }
            Double pct = percentileForValue(vals, value, m);
            if (pct != null) out.put(m.key, pct);
        }
        return out;
    }

    private Double percentileForValue(ArrayList<Double> values, Double value, Metric m) {
        if (values == null || values.isEmpty() || value == null || Double.isNaN(value)) return null;
        int better = 0;
        for (Double v : values) {
            if (v == null || Double.isNaN(v)) continue;
            int cmp = compareMetricValues(v, value, m);
            if (cmp < 0) better++;
        }
        return percentileFromRank(better + 1, values.size());
    }

    private void renderComparison(Comparison c) {
        hideProfileSkeleton();  // v29: remove skeleton before rendering content
        resultsBox.setVisibility(View.VISIBLE);
        headerBox.removeAllViews();
        metricBox.removeAllViews();
        if (copyButton != null) copyButton.setVisibility(View.VISIBLE);
        if (shareButton != null) shareButton.setVisibility(View.VISIBLE);

        TeamPalette palette = paletteForComparison(c);

        LinearLayout card = verticalCard(24, null);
        card.setPadding(dp(14), dp(14), dp(14), dp(14));
        card.setBackground(roundedGradient(new int[] {
                darkColor(palette.primary, 0.28f),
                darkColor(palette.secondary, 0.50f),
                Color.rgb(10, 14, 22)
        }, 24));
        card.setElevation(dp(5));
        headerBox.addView(card, matchWrap());

        LinearLayout topMeta = new LinearLayout(this);
        topMeta.setOrientation(LinearLayout.HORIZONTAL);
        topMeta.setGravity(Gravity.CENTER_VERTICAL);
        TextView profileLabel = text(c.isTeam ? "TEAM PROFILE" : "PLAYER PROFILE", 10, softColor(palette.primary, 0.15f), true);
        profileLabel.setLetterSpacing(0.10f);
        topMeta.addView(profileLabel, new LinearLayout.LayoutParams(0, -2, 1));
        TextView seasonBadge = text(c.season + " SEASON", 10, Color.rgb(235, 242, 251), true);
        seasonBadge.setGravity(Gravity.CENTER);
        seasonBadge.setPadding(dp(10), dp(5), dp(10), dp(5));
        seasonBadge.setBackground(roundedStroke(Color.argb(36, 255, 255, 255), Color.argb(72, 255, 255, 255), 15, 1));
        topMeta.addView(seasonBadge);
        card.addView(topMeta, matchWrap());

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams topLp = matchWrap();
        topLp.setMargins(0, dp(10), 0, dp(6));
        card.addView(top, topLp);

        FrameLayout avatarFrame = new FrameLayout(this);
        avatarFrame.setPadding(dp(4), dp(4), dp(4), dp(4));
        avatarFrame.setBackground(roundedGradient(new int[] { palette.primary, softColor(palette.secondary, 0.14f) }, 30));
        avatarFrame.setElevation(dp(3));
        FrameLayout matte = new FrameLayout(this);
        matte.setPadding(dp(3), dp(3), dp(3), dp(3));
        matte.setBackground(rounded(Color.argb(248, 255, 255, 255), 26));
        applyRoundedClip(matte, 26);
        avatarFrame.addView(matte, new FrameLayout.LayoutParams(-1, -1));
        if (!c.isTeam) {
            ImageView img = new ImageView(this);
            img.setScaleType(ImageView.ScaleType.CENTER_CROP);
            img.setAdjustViewBounds(false);
            img.setBackground(rounded(Color.WHITE, 24));
            applyRoundedClip(img, 24);
            matte.addView(img, new FrameLayout.LayoutParams(-1, -1));
            loadPlayerImage(c.mlbId, img);
        } else {
            View teamLogo = teamLogoView(c.team, 70);
            FrameLayout.LayoutParams logoLp = new FrameLayout.LayoutParams(-2, -2);
            logoLp.gravity = Gravity.CENTER;
            matte.addView(teamLogo, logoLp);
        }
        LinearLayout.LayoutParams imgLp = new LinearLayout.LayoutParams(dp(96), dp(96));
        imgLp.setMargins(0, 0, dp(13), 0);
        top.addView(avatarFrame, imgLp);

        LinearLayout titleCol = new LinearLayout(this);
        titleCol.setOrientation(LinearLayout.VERTICAL);
        top.addView(titleCol, new LinearLayout.LayoutParams(0, -2, 1));
        TextView name = text(c.name, 26, Color.WHITE, true);
        name.setLetterSpacing(0.02f);
        titleCol.addView(name);
        TextView meta = text(c.meta, 11, Color.rgb(222, 231, 244), false);
        meta.setPadding(0, dp(3), 0, dp(8));
        titleCol.addView(meta);
        LinearLayout miniPills = new LinearLayout(this);
        miniPills.setOrientation(LinearLayout.HORIZONTAL);
        if (c.seasonStats.ip > 0 && (c.seasonStats.get("era") != null || c.seasonStats.get("whip") != null)) {
            miniPills.addView(profileDataPill(new DecimalFormat("0.0").format(c.seasonStats.ip), "IP", palette), weightLp());
            miniPills.addView(profileDataPill(fmtCount(c.seasonStats.pa), "BF", palette), weightLp());
        } else {
            miniPills.addView(profileDataPill(fmtCount(c.seasonStats.pa), c.isTeam ? "PA" : "PA", palette), weightLp());
            miniPills.addView(profileDataPill(fmtCount(c.seasonStats.bbe), "BBE", palette), weightLp());
        }
        titleCol.addView(miniPills, matchWrap());

        addBaseballCardSummary(card, c, palette);

        LinearLayout sectionRow = new LinearLayout(this);
        sectionRow.setOrientation(LinearLayout.HORIZONTAL);
        sectionRow.setGravity(Gravity.CENTER_VERTICAL);
        sectionRow.setPadding(0, dp(9), 0, dp(3));
        TextView tableTitle = text("Profile comparison", 18, INK, true);
        sectionRow.addView(tableTitle, new LinearLayout.LayoutParams(0, -2, 1));
        sectionRow.addView(comparisonLegend(c.thirdLabelShort(), palette));
        metricBox.addView(sectionRow, matchWrap());
        TextView scaleHint = text("Bar position = league percentile: 0% left · 50% MLB average · 100% right.", 10, MUTED, false);
        scaleHint.setPadding(dp(1), 0, dp(1), dp(5));
        metricBox.addView(scaleHint, matchWrap());

        int count = 0;
        for (Metric m : metrics) {
            if (!selectedMetricKeys.contains(m.key)) continue;
            renderMetricRow(c, m, palette);
            count++;
        }
        if (count == 0) {
            TextView empty = text("No stats available for this selection.", 14, MUTED, false);
            empty.setPadding(0, dp(10), 0, dp(10));
            metricBox.addView(empty);
        }
        if (suppressNextAutoScroll) suppressNextAutoScroll = false;
        else scrollToResultsTop();
    }

    private void addBaseballCardSummary(LinearLayout card, Comparison c, TeamPalette palette) {
        LinearLayout shell = new LinearLayout(this);
        shell.setOrientation(LinearLayout.VERTICAL);
        shell.setPadding(dp(10), dp(10), dp(10), dp(10));
        LinearLayout.LayoutParams shellLp = matchWrap();
        shellLp.setMargins(0, dp(10), 0, 0);
        shell.setBackground(roundedStroke(Color.argb(34, 255, 255, 255), Color.argb(66, 255, 255, 255), 20, 1));
        card.addView(shell, shellLp);
        View accent = new View(this);
        accent.setBackground(roundedGradient(new int[] { palette.primary, palette.secondary }, 8));
        LinearLayout.LayoutParams accentLp = new LinearLayout.LayoutParams(-1, dp(5));
        accentLp.setMargins(0, 0, 0, dp(8));
        shell.addView(accent, accentLp);

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        shell.addView(head, matchWrap());
        LinearLayout headText = new LinearLayout(this);
        headText.setOrientation(LinearLayout.VERTICAL);
        TextView title = text(c.isTeam ? "TEAM CARD" : "PLAYER CARD", 10, palette.primary, true);
        title.setLetterSpacing(0.08f);
        headText.addView(title);
        headText.addView(text(c.isTeam ? "Recent seasons + 2015+ avg" : "Recent seasons + career", 12, Color.rgb(234, 241, 249), true));
        head.addView(headText, new LinearLayout.LayoutParams(0, -2, 1));
        TextView chip = text(String.valueOf(c.season), 10, Color.WHITE, true);
        chip.setGravity(Gravity.CENTER);
        chip.setPadding(dp(9), dp(4), dp(9), dp(4));
        chip.setBackground(roundedGradient(new int[] { palette.primary, palette.secondary }, 14));
        head.addView(chip);

        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        LinearLayout table = new LinearLayout(this);
        table.setOrientation(LinearLayout.VERTICAL);
        hsv.addView(table, new HorizontalScrollView.LayoutParams(-2, -2));
        LinearLayout.LayoutParams hsvLp = matchWrap();
        hsvLp.setMargins(0, dp(7), 0, 0);
        shell.addView(hsv, hsvLp);

        Metric[] cols = summaryMetricsForCard(c);
        table.addView(baseballCardHeaderRow(cols, palette));
        TreeMap<Integer, Stats> seasonsForCard = new TreeMap<>();
        if (c.recentSeasons != null) seasonsForCard.putAll(c.recentSeasons);
        seasonsForCard.put(c.season, c.seasonStats);
        ArrayList<Integer> yearsForCard = new ArrayList<>(seasonsForCard.keySet());
        if (yearsForCard.size() > 3) yearsForCard = new ArrayList<>(yearsForCard.subList(yearsForCard.size() - 3, yearsForCard.size()));
        if (yearsForCard.isEmpty()) {
            table.addView(baseballCardStatRow("MLB", c.leagueStats, cols, palette, false, false));
        } else {
            for (Integer y : yearsForCard) {
                table.addView(baseballCardStatRow(String.valueOf(y), seasonsForCard.get(y), cols, palette, y == c.season, false));
            }
        }
        table.addView(baseballCardStatRow(c.isTeam ? "2015+" : "Career", c.careerStats, cols, palette, false, true));
        addRecentWindowsSummary(shell, c, palette);
    }

    private void addRecentWindowsSummary(LinearLayout parent, Comparison c, TeamPalette palette) {
        if (c == null || c.isTeam || c.season != Calendar.getInstance().get(Calendar.YEAR) || c.recentWindows == null || c.recentWindows.isEmpty()) return;
        Metric[] cols = recentWindowMetricsForCard(c);
        if (cols.length == 0) return;

        LinearLayout section = new LinearLayout(this);
        section.setOrientation(LinearLayout.VERTICAL);
        section.setPadding(0, dp(8), 0, 0);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text("Recent form", 10, Color.rgb(190, 202, 218), true);
        title.setLetterSpacing(0.08f);
        header.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        section.addView(header, matchWrap());

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(9), dp(7), dp(9), dp(7));
        panel.setBackground(roundedStroke(Color.argb(28, 255, 255, 255), Color.argb(54, 255, 255, 255), 16, 1));
        LinearLayout.LayoutParams panelLp = matchWrap();
        panelLp.setMargins(0, dp(4), 0, 0);

        ArrayList<Map.Entry<String, Stats>> windows = new ArrayList<>(c.recentWindows.entrySet());
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.addView(text("", 9, MUTED, true), new LinearLayout.LayoutParams(dp(52), -2));
        for (Map.Entry<String, Stats> e : windows) {
            TextView w = text(cleanRecentWindowLabel(e.getKey()), 9, palette.primary, true);
            w.setGravity(Gravity.CENTER);
            w.setLetterSpacing(0.08f);
            top.addView(w, new LinearLayout.LayoutParams(0, -2, 1));
        }
        panel.addView(top, matchWrap());

        for (Metric m : cols) {
            LinearLayout line = new LinearLayout(this);
            line.setOrientation(LinearLayout.HORIZONTAL);
            line.setGravity(Gravity.CENTER_VERTICAL);
            line.setPadding(0, dp(5), 0, 0);
            TextView lab = text(m.label, 9, Color.rgb(184, 196, 212), true);
            lab.setLetterSpacing(0.06f);
            line.addView(lab, new LinearLayout.LayoutParams(dp(52), -2));
            for (Map.Entry<String, Stats> e : windows) {
                Double v = e.getValue() == null ? null : e.getValue().get(m.key);
                TextView val = text(format(v, m), 11, Color.rgb(240, 245, 252), true);
                val.setGravity(Gravity.CENTER);
                val.setPadding(dp(2), dp(3), dp(2), dp(3));
                val.setBackground(roundedStroke(Color.argb(32, 255, 255, 255), Color.argb(58, 255, 255, 255), 12, 1));
                LinearLayout.LayoutParams vlp = new LinearLayout.LayoutParams(0, -2, 1);
                vlp.setMargins(dp(4), 0, 0, 0);
                line.addView(val, vlp);
            }
            panel.addView(line, matchWrap());
        }
        section.addView(panel, panelLp);
        parent.addView(section, matchWrap());
    }

    private String cleanRecentWindowLabel(String raw) {
        String s = safe(raw).replace("Last", "").replace("last", "").trim();
        s = s.replace("days", "d").replace("day", "d").replace(" ", "");
        return s.toUpperCase(Locale.US);
    }

    private Metric[] recentWindowMetricsForCard(Comparison c) {
        boolean pitch = c != null && c.player != null && isPitcher(c.player);
        String[] keys = pitch ? new String[] { "era", "whip", "k9" } : new String[] { "avg", "ops", "hr" };
        ArrayList<Metric> cols = new ArrayList<>();
        for (String k : keys) {
            Metric m = metricByKey(k);
            if (m != null) cols.add(m);
        }
        return cols.toArray(new Metric[0]);
    }

    private Metric[] summaryMetricsForCard(Comparison c) {
        boolean pitch = !c.isTeam && c.player != null && isPitcher(c.player);
        if (!pitch && c.isTeam) {
            int pitchCount = 0, hitCount = 0;
            for (Metric m : selectedMetricsForRows()) { if ("pitch".equals(m.side)) pitchCount++; else hitCount++; }
            pitch = pitchCount > hitCount;
        }
        String[] keys = pitch ? new String[] { "era", "whip", "k9", "kbb" } : new String[] { "avg", "ops", "wOBA", "xwOBA" };
        ArrayList<Metric> cols = new ArrayList<>();
        for (String k : keys) {
            Metric m = metricByKey(k);
            if (m != null) cols.add(m);
        }
        return cols.toArray(new Metric[0]);
    }

    private LinearLayout baseballCardHeaderRow(Metric[] cols, TeamPalette palette) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, 0, 0, dp(4));
        TextView season = tableCell("Season", 56, Color.rgb(178, 190, 207), true, Gravity.LEFT);
        row.addView(season);
        for (Metric m : cols) row.addView(tableCell(m.label, 68, Color.rgb(178, 190, 207), true, Gravity.CENTER));
        return row;
    }

    private LinearLayout baseballCardStatRow(String label, Stats stats, Metric[] cols, TeamPalette palette, boolean current, boolean career) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(7), dp(5), dp(7), dp(5));
        LinearLayout.LayoutParams rowLp = matchWrap();
        rowLp.setMargins(0, dp(3), 0, dp(3));
        row.setLayoutParams(rowLp);
        row.setBackground(career ? roundedStroke(Color.argb(54, 255, 255, 255), softColor(palette.primary, 0.56f), 14, 1) : roundedStroke(current ? Color.argb(56, Color.red(palette.primary), Color.green(palette.primary), Color.blue(palette.primary)) : Color.argb(22, 255, 255, 255), current ? softColor(palette.primary, 0.38f) : Color.argb(44, 255, 255, 255), 14, 1));
        row.addView(tableCell(label, 56, current ? softColor(palette.primary, 0.12f) : Color.rgb(235, 242, 250), true, Gravity.LEFT));
        for (Metric m : cols) {
            Double val = stats == null ? null : stats.get(m.key);
            row.addView(tableCell(format(val, m), 68, current || career ? softColor(palette.primary, 0.12f) : Color.rgb(235, 242, 250), current || career, Gravity.CENTER));
        }
        return row;
    }

    private TextView tableCell(String value, int widthDp, int color, boolean bold, int gravity) {
        TextView tv = text(value == null ? "—" : value, 11, color, bold);
        tv.setGravity(gravity);
        tv.setSingleLine(true);
        tv.setPadding(dp(3), 0, dp(3), 0);
        tv.setMinWidth(dp(widthDp));
        tv.setFontFeatureSettings("'tnum' 1");  // v29: tabular figures for baseball-card cells
        return tv;
    }

    private void renderExpectedComparison(Comparison c) {
        renderComparison(c);
        TeamPalette palette = paletteForComparison(c);
        metricBox.removeAllViews();

        LinearLayout sectionRow = new LinearLayout(this);
        sectionRow.setOrientation(LinearLayout.HORIZONTAL);
        sectionRow.setGravity(Gravity.CENTER_VERTICAL);
        sectionRow.setPadding(0, dp(9), 0, dp(3));
        sectionRow.addView(text("Actual vs expected", 18, INK, true), new LinearLayout.LayoutParams(0, -2, 1));
        TextView badge = text("xStats", 11, Color.WHITE, true);
        badge.setGravity(Gravity.CENTER);
        badge.setPadding(dp(9), dp(5), dp(9), dp(5));
        badge.setBackground(roundedGradient(new int[] { palette.primary, palette.secondary }, 14));
        sectionRow.addView(badge);
        metricBox.addView(sectionRow, matchWrap());

        TextView hint = text("This mode compares what happened to Statcast's expected version of the same stat. Positive gap = outperforming expected; negative gap = underperforming expected.", 11, MUTED, false);
        hint.setPadding(dp(1), 0, dp(1), dp(6));
        metricBox.addView(hint, matchWrap());

        int count = 0;
        count += renderExpectedActualRow(c, "avg", "xBA", "Batting average", palette) ? 1 : 0;
        count += renderExpectedActualRow(c, "slg", "xSLG", "Slugging", palette) ? 1 : 0;
        count += renderExpectedActualRow(c, "wOBA", "xwOBA", "wOBA", palette) ? 1 : 0;
        count += renderLuckExplainerRow(c, palette) ? 1 : 0;
        if (count == 0) {
            TextView empty = text("No actual/expected stat pairs are available for this selection. Try a hitter or team with Statcast hitting data.", 14, MUTED, false);
            empty.setPadding(0, dp(10), 0, dp(10));
            metricBox.addView(empty);
        }
    }

    private boolean renderExpectedActualRow(Comparison c, String actualKey, String expectedKey, String label, TeamPalette palette) {
        Metric actualMetric = metricByKey(actualKey);
        Metric expectedMetric = metricByKey(expectedKey);
        Double actual = c.seasonStats.get(actualKey);
        Double expected = c.seasonStats.get(expectedKey);
        if (actual == null && expected == null) return false;
        Double gap = diff(actual, expected);
        Double actualPct = c.percentile == null ? null : c.percentile.get(actualKey);
        Double expectedPct = c.percentile == null ? null : c.percentile.get(expectedKey);

        LinearLayout row = verticalCard(18, null);
        row.setPadding(dp(12), dp(10), dp(12), dp(10));
        row.setBackground(roundedStroke(Color.WHITE, softColor(palette.primary, 0.70f), 18, 1));
        LinearLayout.LayoutParams rowLp = matchWrap();
        rowLp.setMargins(0, dp(7), 0, 0);
        metricBox.addView(row, rowLp);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout titleCol = new LinearLayout(this);
        titleCol.setOrientation(LinearLayout.VERTICAL);
        titleCol.addView(text(label, 16, INK, true));
        titleCol.addView(text(actualMetric.label + " vs " + expectedMetric.label, 11, MUTED, false));
        top.addView(titleCol, new LinearLayout.LayoutParams(0, -2, 1));
        TextView gapBadge = text(gap == null ? "No gap" : "Gap " + signedFormat(gap, actualMetric), 11, Color.WHITE, true);
        gapBadge.setGravity(Gravity.CENTER);
        gapBadge.setPadding(dp(9), dp(5), dp(9), dp(5));
        int gapColor = gap == null || Math.abs(gap) < 0.000001 ? Color.rgb(70, 88, 125) : (gap > 0 ? palette.primary : palette.secondary);
        gapBadge.setBackground(roundedGradient(new int[] { gapColor, softColor(gapColor, 0.10f) }, 14));
        top.addView(gapBadge);
        row.addView(top);

        ExpectedActualBarView bar = new ExpectedActualBarView(this, actualMetric, actual, expected, actualPct, expectedPct, palette);
        LinearLayout.LayoutParams barLp = new LinearLayout.LayoutParams(-1, dp(54));
        barLp.setMargins(0, dp(7), 0, 0);
        row.addView(bar, barLp);

        LinearLayout values = new LinearLayout(this);
        values.setOrientation(LinearLayout.HORIZONTAL);
        values.setPadding(0, dp(5), 0, 0);
        values.addView(statValueColumn("Actual", format(actual, actualMetric), actualPct == null ? "Observed" : percentileBigLabel(actualPct) + " percentile", palette.primary, true), weightLp());
        values.addView(statValueColumn("Expected", format(expected, expectedMetric), expectedPct == null ? "xStat" : percentileBigLabel(expectedPct) + " percentile", palette.secondary, false), weightLp());
        values.addView(statValueColumn("Gap", gap == null ? "—" : signedFormat(gap, actualMetric), gap == null ? "Actual - expected" : (gap > 0 ? "Over expected" : (gap < 0 ? "Under expected" : "Even")), Color.rgb(70, 88, 125), false), weightLp());
        row.addView(values);
        return true;
    }

    private boolean renderLuckExplainerRow(Comparison c, TeamPalette palette) {
        Double luck = c.seasonStats.get("luck");
        if (luck == null) return false;
        Metric m = metricByKey("luck");
        LinearLayout row = verticalCard(18, null);
        row.setPadding(dp(12), dp(10), dp(12), dp(10));
        row.setBackground(roundedStroke(Color.WHITE, softColor(palette.primary, 0.70f), 18, 1));
        LinearLayout.LayoutParams rowLp = matchWrap();
        rowLp.setMargins(0, dp(7), 0, 0);
        metricBox.addView(row, rowLp);
        row.addView(text("Luck index", 16, INK, true));
        TextView detail = text("wOBA - xwOBA. Positive means results are running ahead of expected quality of contact; negative means results are lagging expected quality.", 11, MUTED, false);
        detail.setPadding(0, dp(3), 0, dp(6));
        row.addView(detail);
        LinearLayout values = new LinearLayout(this);
        values.setOrientation(LinearLayout.HORIZONTAL);
        values.addView(statValueColumn("wOBA", format(c.seasonStats.get("wOBA"), metricByKey("wOBA")), "Actual", palette.primary, true), weightLp());
        values.addView(statValueColumn("xwOBA", format(c.seasonStats.get("xwOBA"), metricByKey("xwOBA")), "Expected", palette.secondary, false), weightLp());
        values.addView(statValueColumn("Luck", signedFormat(luck, m), luck > 0 ? "Lucky" : (luck < 0 ? "Unlucky" : "Neutral"), Color.rgb(70, 88, 125), false), weightLp());
        row.addView(values);
        return true;
    }



    private void renderHeadToHead(HeadToHeadComparison h) {
        hideProfileSkeleton();  // v29: remove skeleton before rendering content
        resultsBox.setVisibility(View.VISIBLE);
        headerBox.removeAllViews();
        metricBox.removeAllViews();

        TeamPalette paletteA = paletteForHeadToHeadSide(h, true);
        TeamPalette paletteB = paletteForHeadToHeadSide(h, false);

        // v30.1: Unified dark battle card replaces old white header + separate duel card
        addBattleCard(h, paletteA, paletteB);

        LinearLayout sectionRow = new LinearLayout(this);
        sectionRow.setOrientation(LinearLayout.HORIZONTAL);
        sectionRow.setGravity(Gravity.CENTER_VERTICAL);
        sectionRow.setPadding(0, dp(9), 0, dp(3));
        sectionRow.addView(text("Side-by-side stats", 18, INK, true), new LinearLayout.LayoutParams(0, -2, 1));
        sectionRow.addView(headToHeadLegend(h, paletteA, paletteB));
        metricBox.addView(sectionRow, matchWrap());

        int count = 0;
        for (Metric m : metrics) {
            if (!selectedMetricKeys.contains(m.key)) continue;
            renderHeadToHeadMetricRow(h, m, paletteA, paletteB);
            count++;
        }
        if (count == 0) {
            TextView empty = text("No stats available for this selection.", 14, MUTED, false);
            empty.setPadding(0, dp(10), 0, dp(10));
            metricBox.addView(empty);
        }
        scrollToResultsTop();
    }

    private View headToHeadSideTile(HeadToHeadComparison h, boolean leftSide, TeamPalette palette) {
        LinearLayout tile = new LinearLayout(this);
        tile.setOrientation(LinearLayout.HORIZONTAL);
        tile.setGravity(Gravity.CENTER_VERTICAL);
        tile.setPadding(dp(9), dp(9), dp(9), dp(9));
        tile.setBackground(roundedStroke(Color.WHITE, softColor(palette.primary, 0.55f), 18, 1));
        if (h.isTeam) {
            View logo = teamLogoView(leftSide ? h.teamA : h.teamB, 44);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(44), dp(44));
            lp.setMargins(0, 0, dp(8), 0);
            tile.addView(logo, lp);
        } else {
            ImageView img = new ImageView(this);
            img.setScaleType(ImageView.ScaleType.FIT_CENTER);
            img.setAdjustViewBounds(true);
            img.setBackground(roundedStroke(Color.rgb(235, 241, 248), LINE, 18, 1));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(44), dp(44));
            lp.setMargins(0, 0, dp(8), 0);
            tile.addView(img, lp);
            loadPlayerImage(leftSide ? h.idA : h.idB, img);
        }
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.addView(text(leftSide ? h.nameA : h.nameB, 14, INK, true));
        col.addView(text(leftSide ? h.metaA : h.metaB, 10, MUTED, false));
        tile.addView(col, new LinearLayout.LayoutParams(0, -2, 1));
        return tile;
    }

    private View headToHeadLegend(HeadToHeadComparison h, TeamPalette paletteA, TeamPalette paletteB) {
        LinearLayout legend = new LinearLayout(this);
        legend.setOrientation(LinearLayout.VERTICAL);
        legend.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        legend.addView(legendMini(shortName(h.nameA), paletteA.primary));
        legend.addView(legendMini("MLB", Color.rgb(70, 88, 125)));
        legend.addView(legendMini(shortName(h.nameB), paletteB.primary));
        return legend;
    }

    // v43: electric-energy polish - VS arcs and winner-side stat rail sparks.
    private void addBattleCard(HeadToHeadComparison h, TeamPalette paletteA, TeamPalette paletteB) {
        PremiumShareCardView card = new PremiumShareCardView(this, h, paletteA, paletteB);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, dp(8));
        headerBox.addView(card, lp);
    }

    class PremiumShareCardView extends View {
        final HeadToHeadComparison h;
        final TeamPalette paletteA, paletteB;
        final ArrayList<Metric> allMetrics;
        final ArrayList<Metric> shareMetrics;
        final int aWins, bWins, decided;
        Bitmap iconA, iconB;
        Bitmap logoA, logoB;
        final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.DITHER_FLAG);
        final Paint strokePaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.DITHER_FLAG);

        PremiumShareCardView(Context context, HeadToHeadComparison h, TeamPalette paletteA, TeamPalette paletteB) {
            super(context);
            this.h = h;
            this.paletteA = paletteA;
            this.paletteB = paletteB;
            this.allMetrics = collectHeadToHeadMetrics(h, 99);
            this.shareMetrics = collectHeadToHeadMetrics(h, 8);
            int[] wins = countHeadToHeadWins(h, allMetrics);
            this.aWins = wins[0];
            this.bWins = wins[1];
            this.decided = Math.max(0, aWins + bWins);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            Team logoTeamA = h.isTeam ? h.teamA : findTeamByName(h.playerA == null ? "" : h.playerA.teamAbbr);
            Team logoTeamB = h.isTeam ? h.teamB : findTeamByName(h.playerB == null ? "" : h.playerB.teamAbbr);
            if (logoTeamA != null) loadTeamLogoBitmap(logoTeamA, bitmap -> { logoA = bitmap; invalidate(); });
            if (logoTeamB != null) loadTeamLogoBitmap(logoTeamB, bitmap -> { logoB = bitmap; invalidate(); });
            if (h.isTeam) {
                loadTeamLogoBitmap(h.teamA, bitmap -> { iconA = bitmap; invalidate(); });
                loadTeamLogoBitmap(h.teamB, bitmap -> { iconB = bitmap; invalidate(); });
            } else {
                loadPlayerImageBitmap(h.idA, bitmap -> { iconA = bitmap; invalidate(); });
                loadPlayerImageBitmap(h.idB, bitmap -> { iconB = bitmap; invalidate(); });
            }
        }

        @Override protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
            int w = MeasureSpec.getSize(widthMeasureSpec);
            if (w <= 0) w = dp(360);
            int hPx = Math.max(dp(760), Math.round(w * 2.05f));
            setMeasuredDimension(w, hPx);
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth();
            float hgt = getHeight();
            float pad = dp(4);
            RectF card = new RectF(pad, pad, w - pad, hgt - pad);
            float radius = dp(28);

            paint.setStyle(Paint.Style.FILL);
            paint.setShader(new LinearGradient(card.left, card.top, card.right, card.bottom,
                    new int[] {
                            darkColor(paletteA.primary, 0.24f),
                            darkColor(paletteA.secondary, 0.58f),
                            Color.rgb(9, 16, 28),
                            darkColor(paletteB.secondary, 0.52f),
                            darkColor(paletteB.primary, 0.22f)
                    },
                    new float[] {0f, 0.26f, 0.50f, 0.74f, 1f}, Shader.TileMode.CLAMP));
            paint.setShadowLayer(dp(10), 0, dp(5), Color.argb(38, 0, 0, 0));
            canvas.drawRoundRect(card, radius, radius, paint);
            paint.clearShadowLayer();
            paint.setShader(null);

            int save = canvas.save();
            Path clip = new Path();
            clip.addRoundRect(card, radius, radius, Path.Direction.CW);
            canvas.clipPath(clip);
            drawAtmosphere(canvas, card, true, paletteA);
            drawAtmosphere(canvas, card, false, paletteB);
            drawVignette(canvas, card);

            float titleY = card.top + dp(34);
            drawText(canvas, h.season + " STATCAST MATCHUP", card.centerX(), titleY, dp(10), Color.rgb(222, 230, 241), true, Paint.Align.CENTER, 0.13f);
            drawPill(canvas, allMetrics.size() + " STATS", card.centerX(), titleY + dp(26), dp(86), dp(26), Color.argb(36, 255, 255, 255), Color.argb(72, 255, 255, 255), Color.WHITE, dp(10));

            int accentA = readableTeamColor(paletteA.primary, paletteA.secondary, true);
            int accentB = readableTeamColor(paletteB.primary, paletteB.secondary, false);
            drawCornerTeamLogo(canvas, logoA, sideAbbr(true), card.left + dp(34), card.top + dp(58), dp(70), accentA, true);
            drawCornerTeamLogo(canvas, logoB, sideAbbr(false), card.right - dp(34), card.top + dp(58), dp(70), Color.WHITE, false);

            float portraitR = Math.min(dp(72), w * 0.19f);
            float leftCx = card.left + w * 0.25f;
            float rightCx = card.right - w * 0.25f;
            float portraitCy = card.top + dp(145);
            float vsCx = card.centerX();
            float vsCy = portraitCy + dp(2);

            drawBattleBeam(canvas, leftCx + portraitR, vsCy, vsCx - dp(24), vsCy, accentA, true);
            drawBattleBeam(canvas, rightCx - portraitR, vsCy, vsCx + dp(24), vsCy, accentB, false);
            drawPortrait(canvas, iconA, leftCx, portraitCy, portraitR, paletteA, initials(h.nameA));
            drawPortrait(canvas, iconB, rightCx, portraitCy, portraitR, paletteB, initials(h.nameB));
            drawVsBadge(canvas, vsCx, vsCy, dp(25));

            drawPlayerNameBlock(canvas, h.nameA, h.metaA, leftCx, portraitCy + portraitR + dp(36), paletteA, true);
            drawPlayerNameBlock(canvas, h.nameB, h.metaB, rightCx, portraitCy + portraitR + dp(36), paletteB, false);

            float scoreTop = card.top + dp(348);
            RectF score = new RectF(card.left + dp(30), scoreTop, card.right - dp(30), scoreTop + dp(112));
            drawScoreBlock(canvas, score);

            float keyY = score.bottom + dp(34);
            drawKeyStatBody(canvas, card, keyY);
            canvas.restoreToCount(save);

            strokePaint.setShader(null);
            strokePaint.setStyle(Paint.Style.STROKE);
            strokePaint.setStrokeWidth(dp(1));
            strokePaint.setColor(Color.argb(70, 255, 255, 255));
            canvas.drawRoundRect(card, radius, radius, strokePaint);
        }

        private void drawAtmosphere(Canvas canvas, RectF card, boolean left, TeamPalette palette) {
            float sideLeft = left ? card.left : card.centerX();
            float sideRight = left ? card.centerX() : card.right;
            int alpha = left ? 36 : 42;
            paint.setShader(null);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.argb(alpha, 0, 0, 0));
            float base = card.top + dp(270);
            for (int i = 0; i < 9; i++) {
                float bw = dp(12 + (i % 3) * 7);
                float bh = dp(28 + (i % 4) * 9);
                float x = sideLeft + dp(18) + i * ((sideRight - sideLeft - dp(38)) / 9f);
                canvas.drawRect(x, base - bh, x + bw, base, paint);
            }
            strokePaint.setShader(null);
            strokePaint.setStyle(Paint.Style.STROKE);
            strokePaint.setStrokeWidth(dp(2));
            strokePaint.setStrokeCap(Paint.Cap.ROUND);
            strokePaint.setColor(Color.argb(44, 255, 255, 255));
            float palmX = left ? card.left + dp(34) : card.right - dp(58);
            float palmBase = card.top + dp(278);
            drawPalm(canvas, palmX, palmBase, left ? 0.82f : 0.92f, strokePaint);
            float palmX2 = left ? card.left + dp(68) : card.right - dp(98);
            drawPalm(canvas, palmX2, palmBase + dp(6), left ? 0.55f : 0.62f, strokePaint);

            paint.setStyle(Paint.Style.FILL);
            paint.setShader(new LinearGradient(sideLeft, card.top, sideRight, card.bottom,
                    new int[] { Color.argb(42, Color.red(palette.primary), Color.green(palette.primary), Color.blue(palette.primary)), Color.TRANSPARENT }, null, Shader.TileMode.CLAMP));
            canvas.drawRect(sideLeft, card.top, sideRight, card.bottom, paint);
            paint.setShader(null);
        }

        private void drawPalm(Canvas c, float x, float y, float scale, Paint p) {
            float h = dp(74) * scale;
            c.drawLine(x, y, x + dp(8) * scale, y - h, p);
            float cx = x + dp(8) * scale, cy = y - h;
            for (int i = -3; i <= 3; i++) {
                float ang = (float) (-Math.PI / 2 + i * 0.35f);
                float len = dp(28) * scale * (1f - Math.abs(i) * 0.06f);
                c.drawLine(cx, cy, cx + (float)Math.cos(ang) * len, cy + (float)Math.sin(ang) * len, p);
            }
        }

        private void drawVignette(Canvas canvas, RectF card) {
            paint.setStyle(Paint.Style.FILL);
            paint.setShader(new LinearGradient(card.left, card.top, card.left, card.bottom,
                    new int[] { Color.argb(18, 255, 255, 255), Color.TRANSPARENT, Color.argb(118, 0, 0, 0) },
                    new float[] {0f, 0.42f, 1f}, Shader.TileMode.CLAMP));
            canvas.drawRect(card, paint);
            paint.setShader(null);
        }

        private void drawCornerTeamLogo(Canvas canvas, Bitmap logo, String fallback, float x, float y, float size, int color, boolean left) {
            // v41: use the transparent logo asset as a true watermark — no circle/badge behind it.
            if (logo != null && logo.getWidth() > 0 && logo.getHeight() > 0) {
                float leftX = left ? x : x - size;
                RectF box = new RectF(leftX, y - size * 0.78f, leftX + size, y + size * 0.22f);
                Paint bp = paintForBitmap();
                bp.setAlpha(left ? 138 : 164);
                bp.setShadowLayer(dp(8), 0, 0, Color.argb(70, Color.red(color), Color.green(color), Color.blue(color)));
                float bw = logo.getWidth(), bh = logo.getHeight();
                float scale = Math.min(box.width() / bw, box.height() / bh);
                float dw = bw * scale, dh = bh * scale;
                Rect src = new Rect(0, 0, logo.getWidth(), logo.getHeight());
                RectF dst = new RectF(box.centerX() - dw / 2f, box.centerY() - dh / 2f, box.centerX() + dw / 2f, box.centerY() + dh / 2f);
                canvas.drawBitmap(logo, src, dst, bp);
                return;
            }
            drawCornerTeamMark(canvas, fallback, x, y, color, left ? Paint.Align.LEFT : Paint.Align.RIGHT);
        }

        private void drawCornerTeamMark(Canvas canvas, String mark, float x, float y, int color, Paint.Align align) {
            paint.setShader(null);
            paint.setStyle(Paint.Style.FILL);
            paint.setTypeface(tfBold);
            paint.setTextAlign(align);
            paint.setTextSize(dp(34));
            paint.setColor(Color.argb(118, Color.red(color), Color.green(color), Color.blue(color)));
            canvas.drawText(mark, x, y, paint);
        }

        private String sideAbbr(boolean left) {
            if (h.isTeam) {
                Team t = left ? h.teamA : h.teamB;
                return t == null ? "" : prettyAbbr(t.abbr);
            }
            Player p = left ? h.playerA : h.playerB;
            return p == null ? "" : prettyAbbr(p.teamAbbr);
        }

        private String prettyAbbr(String abbr) {
            String s = safe(abbr).toUpperCase(Locale.US);
            if (s.equals("LAD")) return "LA";
            if (s.equals("SDP")) return "SD";
            if (s.equals("SFG")) return "SF";
            return s;
        }

        private void drawBattleBeam(Canvas canvas, float x1, float y1, float x2, float y2, int color, boolean left) {
            strokePaint.setStyle(Paint.Style.STROKE);
            strokePaint.setStrokeCap(Paint.Cap.ROUND);

            // v40: make the team-color energy lines obvious, like the approved prototype.
            strokePaint.setStrokeWidth(dp(20));
            strokePaint.setShader(new LinearGradient(x1, y1, x2, y2,
                    left ? new int[] { Color.argb(10, Color.red(color), Color.green(color), Color.blue(color)), Color.argb(150, Color.red(color), Color.green(color), Color.blue(color)), Color.argb(245, 255, 255, 255) }
                         : new int[] { Color.argb(245, 255, 255, 255), Color.argb(150, Color.red(color), Color.green(color), Color.blue(color)), Color.argb(10, Color.red(color), Color.green(color), Color.blue(color)) },
                    null, Shader.TileMode.CLAMP));
            strokePaint.setShadowLayer(dp(22), 0, 0, Color.argb(220, Color.red(color), Color.green(color), Color.blue(color)));
            canvas.drawLine(x1, y1, x2, y2, strokePaint);

            strokePaint.setStrokeWidth(dp(8));
            strokePaint.setShader(new LinearGradient(x1, y1, x2, y2,
                    left ? new int[] { Color.argb(35, Color.red(color), Color.green(color), Color.blue(color)), Color.argb(255, Color.red(color), Color.green(color), Color.blue(color)), Color.WHITE }
                         : new int[] { Color.WHITE, Color.argb(255, Color.red(color), Color.green(color), Color.blue(color)), Color.argb(35, Color.red(color), Color.green(color), Color.blue(color)) },
                    null, Shader.TileMode.CLAMP));
            strokePaint.setShadowLayer(dp(10), 0, 0, color);
            canvas.drawLine(x1, y1, x2, y2, strokePaint);

            strokePaint.clearShadowLayer();
            strokePaint.setShader(null);
            strokePaint.setStrokeWidth(dp(2));
            strokePaint.setColor(Color.argb(245, 255, 255, 255));
            canvas.drawLine(x1, y1, x2, y2, strokePaint);

            paint.setStyle(Paint.Style.FILL);
            paint.setShader(new RadialGradient(x2, y2, dp(22),
                    new int[] { Color.argb(210, 255, 255, 255), Color.argb(120, Color.red(color), Color.green(color), Color.blue(color)), Color.TRANSPARENT },
                    new float[] {0f, 0.42f, 1f}, Shader.TileMode.CLAMP));
            canvas.drawCircle(x2, y2, dp(22), paint);
            paint.setShader(null);
        }

        private void drawPortrait(Canvas canvas, Bitmap bmp, float cx, float cy, float r, TeamPalette palette, String fallback) {
            int accent = readableTeamColor(palette.primary, palette.secondary, true);
            int deep = darkColor(palette.primary, 0.45f);

            // v41: softer portrait bloom. The color glow now fades into the hero instead of ending as a hard ring.
            paint.setStyle(Paint.Style.FILL);
            paint.setShader(new RadialGradient(cx, cy, r + dp(46),
                    new int[] {
                            Color.TRANSPARENT,
                            Color.argb(90, Color.red(accent), Color.green(accent), Color.blue(accent)),
                            Color.argb(44, Color.red(accent), Color.green(accent), Color.blue(accent)),
                            Color.TRANSPARENT
                    },
                    new float[] {0.50f, 0.70f, 0.84f, 1f}, Shader.TileMode.CLAMP));
            canvas.drawCircle(cx, cy, r + dp(46), paint);
            paint.setShader(null);

            paint.setColor(Color.argb(245, 5, 10, 18));
            canvas.drawCircle(cx, cy, r + dp(7), paint);

            strokePaint.setStyle(Paint.Style.STROKE);
            strokePaint.setStrokeWidth(dp(4));
            strokePaint.setShader(new LinearGradient(cx - r, cy - r, cx + r, cy + r,
                    new int[] { softColor(accent, 0.03f), Color.WHITE, accent }, null, Shader.TileMode.CLAMP));
            strokePaint.setShadowLayer(dp(9), 0, 0, Color.argb(135, Color.red(accent), Color.green(accent), Color.blue(accent)));
            canvas.drawCircle(cx, cy, r + dp(4), strokePaint);
            strokePaint.clearShadowLayer();
            strokePaint.setShader(null);

            RectF box = new RectF(cx - r, cy - r, cx + r, cy + r);
            Path clip = new Path();
            clip.addCircle(cx, cy, r, Path.Direction.CW);
            int save = canvas.save();
            canvas.clipPath(clip);

            paint.setStyle(Paint.Style.FILL);
            paint.setShader(new RadialGradient(cx, cy, r,
                    new int[] { softColor(accent, 0.86f), darkColor(accent, 0.15f), deep },
                    new float[] {0f, 0.64f, 1f}, Shader.TileMode.CLAMP));
            canvas.drawCircle(cx, cy, r, paint);
            paint.setShader(null);

            if (bmp != null) drawBitmapFitInside(canvas, bmp, box, 1.02f);
            else drawText(canvas, fallback, cx, cy + dp(8), dp(24), accent, true, Paint.Align.CENTER, 0.02f);

            // Darken only the very edge so white/solid source backgrounds melt into the circle.
            paint.setStyle(Paint.Style.FILL);
            paint.setShader(new RadialGradient(cx, cy, r,
                    new int[] { Color.TRANSPARENT, Color.TRANSPARENT, Color.argb(138, 4, 9, 16) },
                    new float[] {0f, 0.70f, 1f}, Shader.TileMode.CLAMP));
            canvas.drawCircle(cx, cy, r, paint);
            paint.setShader(null);
            canvas.restoreToCount(save);
        }

        private void drawBitmapCenterCrop(Canvas canvas, Bitmap bitmap, RectF box) {
            if (bitmap == null || bitmap.getWidth() <= 0 || bitmap.getHeight() <= 0) return;
            float bw = bitmap.getWidth(), bh = bitmap.getHeight();
            float scale = Math.max(box.width() / bw, box.height() / bh);
            float dw = bw * scale, dh = bh * scale;
            Rect src = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());
            RectF dst = new RectF(box.centerX() - dw / 2f, box.centerY() - dh / 2f, box.centerX() + dw / 2f, box.centerY() + dh / 2f);
            canvas.drawBitmap(bitmap, src, dst, paintForBitmap());
        }

        private void drawBitmapFitInside(Canvas canvas, Bitmap bitmap, RectF box, float fill) {
            if (bitmap == null || bitmap.getWidth() <= 0 || bitmap.getHeight() <= 0) return;
            float bw = bitmap.getWidth(), bh = bitmap.getHeight();
            float scale = Math.min((box.width() * fill) / bw, (box.height() * fill) / bh);
            float dw = bw * scale, dh = bh * scale;
            Rect src = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());
            // Slight vertical bias keeps hats/faces better framed for MLB headshots/spots.
            RectF dst = new RectF(box.centerX() - dw / 2f, box.centerY() - dh / 2f + dp(2), box.centerX() + dw / 2f, box.centerY() + dh / 2f + dp(2));
            canvas.drawBitmap(bitmap, src, dst, paintForBitmap());
        }

        private void drawVsBadge(Canvas canvas, float cx, float cy, float r) {
            int leftColor = readableTeamColor(paletteA.primary, paletteA.secondary, true);
            int rightColor = readableTeamColor(paletteB.primary, paletteB.secondary, false);

            // v45: build fix for softened electric pass. v44 look retained; float dp overload added.
            // v44: keep the electric battle look, but render it as a softer premium energy beam.
            paint.setStyle(Paint.Style.FILL);
            paint.setShader(new RadialGradient(cx - r * 0.68f, cy, r * 2.35f,
                    new int[] {
                            Color.argb(150, Color.red(leftColor), Color.green(leftColor), Color.blue(leftColor)),
                            Color.argb(58, Color.red(leftColor), Color.green(leftColor), Color.blue(leftColor)),
                            Color.TRANSPARENT
                    }, new float[] {0f, 0.44f, 1f}, Shader.TileMode.CLAMP));
            canvas.drawCircle(cx - r * 0.15f, cy, r * 2.05f, paint);
            paint.setShader(new RadialGradient(cx + r * 0.68f, cy, r * 2.35f,
                    new int[] {
                            Color.argb(150, Color.red(rightColor), Color.green(rightColor), Color.blue(rightColor)),
                            Color.argb(58, Color.red(rightColor), Color.green(rightColor), Color.blue(rightColor)),
                            Color.TRANSPARENT
                    }, new float[] {0f, 0.44f, 1f}, Shader.TileMode.CLAMP));
            canvas.drawCircle(cx + r * 0.15f, cy, r * 2.05f, paint);

            paint.setShader(new LinearGradient(cx - r, cy, cx + r, cy,
                    new int[] {
                            darkColor(leftColor, 0.18f),
                            Color.rgb(5, 10, 18),
                            darkColor(rightColor, 0.16f)
                    }, new float[] {0f, 0.50f, 1f}, Shader.TileMode.CLAMP));
            paint.setShadowLayer(dp(12), 0, 0, Color.argb(110, 255, 255, 255));
            canvas.drawCircle(cx, cy, r, paint);
            paint.clearShadowLayer();
            paint.setShader(null);

            // Softer side-to-center energy lines instead of harsh zig-zag lightning.
            drawElectricBolt(canvas, cx - r * 2.15f, cy - dp(0.5f), cx - r * 0.34f, cy - dp(0.5f), leftColor, dp(1.2f), 7, dp(1.4f), 132);
            drawElectricBolt(canvas, cx + r * 2.15f, cy + dp(0.5f), cx + r * 0.34f, cy + dp(0.5f), rightColor, dp(1.2f), 7, dp(1.4f), 132);
            drawElectricStar(canvas, cx - r * 0.20f, cy, leftColor, dp(7), 0.42f);
            drawElectricStar(canvas, cx + r * 0.20f, cy, rightColor, dp(7), 0.42f);

            strokePaint.setStyle(Paint.Style.STROKE);
            strokePaint.setStrokeWidth(dp(2));
            strokePaint.setShader(new LinearGradient(cx - r, cy, cx + r, cy,
                    new int[] { leftColor, Color.WHITE, rightColor },
                    new float[] {0f, 0.50f, 1f}, Shader.TileMode.CLAMP));
            strokePaint.setShadowLayer(dp(7), 0, 0, Color.argb(98, 255, 255, 255));
            canvas.drawCircle(cx, cy, r, strokePaint);
            strokePaint.clearShadowLayer();
            strokePaint.setShader(null);

            drawText(canvas, "VS", cx, cy + dp(5), dp(13), Color.WHITE, true, Paint.Align.CENTER, 0.10f);
        }

        private void drawPlayerNameBlock(Canvas canvas, String name, String meta, float cx, float y, TeamPalette palette, boolean left) {
            String[] parts = safe(name).trim().split("\\s+");
            String first = parts.length > 1 ? parts[0] : safe(name);
            String last = parts.length > 1 ? parts[parts.length - 1] : "";
            if (last.equalsIgnoreCase("Jr.") && parts.length > 2) last = parts[parts.length - 2] + " JR.";
            drawText(canvas, first.toUpperCase(Locale.US), cx, y, dp(12), Color.rgb(220, 229, 241), false, Paint.Align.CENTER, 0.18f);
            drawText(canvas, last.toUpperCase(Locale.US), cx, y + dp(30), dp(23), Color.WHITE, true, Paint.Align.CENTER, 0.07f);
            drawText(canvas, safe(meta).toUpperCase(Locale.US), cx, y + dp(58), dp(11), softColor(palette.primary, 0.16f), true, Paint.Align.CENTER, 0.11f);
        }

        private void drawScoreBlock(Canvas canvas, RectF score) {
            paint.setStyle(Paint.Style.FILL);
            paint.setShader(new LinearGradient(score.left, score.top, score.right, score.bottom,
                    new int[] { Color.argb(98, 255, 255, 255), Color.argb(38, 255, 255, 255), Color.argb(22, 255, 255, 255) },
                    new float[] {0f, 0.48f, 1f}, Shader.TileMode.CLAMP));
            paint.setShadowLayer(dp(10), 0, dp(4), Color.argb(62, 0, 0, 0));
            canvas.drawRoundRect(score, dp(20), dp(20), paint);
            paint.clearShadowLayer();
            paint.setShader(null);
            strokePaint.setStyle(Paint.Style.STROKE);
            strokePaint.setStrokeWidth(dp(1));
            strokePaint.setColor(Color.argb(96, 255, 255, 255));
            canvas.drawRoundRect(score, dp(20), dp(20), strokePaint);

            boolean aAhead = aWins > bWins;
            boolean bAhead = bWins > aWins;
            int high = Math.max(aWins, bWins), low = Math.min(aWins, bWins);
            int highColor = aAhead ? readableTeamColor(paletteA.primary, paletteA.secondary, true) : (bAhead ? readableTeamColor(paletteB.primary, paletteB.secondary, false) : Color.WHITE);
            int lowColor = aAhead ? readableTeamColor(paletteB.primary, paletteB.secondary, false) : (bAhead ? readableTeamColor(paletteA.primary, paletteA.secondary, true) : Color.WHITE);
            String leader = aAhead ? shortName(h.nameA).toUpperCase(Locale.US) : (bAhead ? shortName(h.nameB).toUpperCase(Locale.US) : "EVEN");

            drawText(canvas, aAhead || bAhead ? leader + " LEADS" : "EVEN MATCHUP", score.centerX(), score.top + dp(28), dp(11), Color.rgb(248, 252, 255), true, Paint.Align.CENTER, 0.13f);
            float midY = score.top + dp(73);
            paint.setShadowLayer(dp(9), 0, 0, Color.argb(150, Color.red(highColor), Color.green(highColor), Color.blue(highColor)));
            drawText(canvas, String.valueOf(high), score.centerX() - dp(58), midY, dp(46), highColor, true, Paint.Align.CENTER, 0.00f);
            paint.clearShadowLayer();
            drawText(canvas, "–", score.centerX(), midY - dp(2), dp(35), Color.WHITE, true, Paint.Align.CENTER, 0.00f);
            paint.setShadowLayer(dp(6), 0, 0, Color.argb(112, Color.red(lowColor), Color.green(lowColor), Color.blue(lowColor)));
            drawText(canvas, String.valueOf(low), score.centerX() + dp(58), midY, dp(46), lowColor, true, Paint.Align.CENTER, 0.00f);
            paint.clearShadowLayer();
            // v42: remove the subtitle so the score panel stays clean and the bar is not blocked.
            float barY = score.bottom - dp(20);
            RectF track = new RectF(score.left + dp(28), barY - dp(5), score.right - dp(28), barY + dp(5));
            paint.setShader(null);
            paint.setColor(Color.argb(88, 255, 255, 255));
            canvas.drawRoundRect(track, dp(7), dp(7), paint);
            paint.setShader(new LinearGradient(track.left, track.top, track.right, track.bottom,
                    new int[] { readableTeamColor(paletteA.primary, paletteA.secondary, true), softColor(readableTeamColor(paletteA.primary, paletteA.secondary, true), 0.25f), softColor(readableTeamColor(paletteB.primary, paletteB.secondary, false), 0.22f), readableTeamColor(paletteB.primary, paletteB.secondary, false) },
                    new float[] {0f, 0.28f, 0.56f, 1f}, Shader.TileMode.CLAMP));
            paint.setShadowLayer(dp(7), 0, 0, Color.argb(85, Color.red(highColor), Color.green(highColor), Color.blue(highColor)));
            canvas.drawRoundRect(track, dp(7), dp(7), paint);
            paint.clearShadowLayer();
            paint.setShader(null);
        }

        private void drawKeyStatBody(Canvas canvas, RectF card, float keyY) {
            drawText(canvas, "KEY STAT EDGE", card.left + dp(48), keyY, dp(11), Color.WHITE, true, Paint.Align.LEFT, 0.12f);
            paint.setStyle(Paint.Style.FILL);
            paint.setShader(null);
            paint.setColor(Color.argb(48, 255, 255, 255));
            canvas.drawCircle(card.left + dp(28), keyY - dp(5), dp(14), paint);
            strokePaint.setStyle(Paint.Style.STROKE);
            strokePaint.setStrokeWidth(dp(3));
            strokePaint.setStrokeCap(Paint.Cap.ROUND);
            strokePaint.setColor(Color.WHITE);
            float bx = card.left + dp(22), by = keyY - dp(10);
            canvas.drawLine(bx, by + dp(9), bx, by + dp(15), strokePaint);
            canvas.drawLine(bx + dp(6), by + dp(5), bx + dp(6), by + dp(15), strokePaint);
            canvas.drawLine(bx + dp(12), by + dp(1), bx + dp(12), by + dp(15), strokePaint);

            float panelTop = keyY + dp(20);
            float panelBottom = card.bottom - dp(22);
            RectF panel = new RectF(card.left + dp(24), panelTop, card.right - dp(24), panelBottom);
            paint.setShader(new LinearGradient(panel.left, panel.top, panel.right, panel.bottom,
                    new int[] { Color.argb(132, 7, 14, 24), Color.argb(118, 10, 24, 40), Color.argb(138, 5, 18, 32) },
                    null, Shader.TileMode.CLAMP));
            paint.setStyle(Paint.Style.FILL);
            paint.setShadowLayer(dp(8), 0, dp(4), Color.argb(55, 0, 0, 0));
            canvas.drawRoundRect(panel, dp(16), dp(16), paint);
            paint.clearShadowLayer();
            paint.setShader(null);
            strokePaint.setStyle(Paint.Style.STROKE);
            strokePaint.setStrokeWidth(dp(1));
            strokePaint.setColor(Color.argb(58, 255, 255, 255));
            canvas.drawRoundRect(panel, dp(16), dp(16), strokePaint);

            int rowCount = Math.max(1, shareMetrics.size());
            float rowH = panel.height() / rowCount;
            for (int i = 0; i < shareMetrics.size(); i++) {
                Metric m = shareMetrics.get(i);
                float top = panel.top + i * rowH;
                float bottom = top + rowH;
                if (i > 0) {
                    strokePaint.setStyle(Paint.Style.STROKE);
                    strokePaint.setStrokeWidth(dp(1));
                    strokePaint.setShader(null);
                    strokePaint.setColor(Color.argb(34, 255, 255, 255));
                    canvas.drawLine(panel.left + dp(2), top, panel.right - dp(2), top, strokePaint);
                }
                drawShareMetric(canvas, m, panel, top, bottom);
            }
        }

        private void drawShareMetric(Canvas canvas, Metric m, RectF panel, float top, float bottom) {
            Double a = h.statsA.get(m.key), b = h.statsB.get(m.key);
            int winner = headToHeadWinner(h, m);
            int aStrong = readableTeamColor(paletteA.primary, paletteA.secondary, true);
            int bStrong = readableTeamColor(paletteB.primary, paletteB.secondary, false);
            int aColor = winner < 0 ? aStrong : Color.argb(238, Color.red(aStrong), Color.green(aStrong), Color.blue(aStrong));
            int bColor = winner > 0 ? bStrong : Color.argb(245, Color.red(bStrong), Color.green(bStrong), Color.blue(bStrong));
            float rowH = bottom - top;
            float cy = (top + bottom) / 2f;

            // v42: strict, repeatable vertical rhythm. Values and stat labels share one optical center;
            // the blended rail sits on a separate fixed baseline below them, so rows don't drift.
            float valueSize = dp(winner != 0 ? 20 : 19);
            float labelSize = dp(11);
            float textCenterY = top + rowH * 0.42f;
            float valueBaseline = centeredTextBaseline(textCenterY, valueSize, true);
            float labelBaseline = centeredTextBaseline(textCenterY, labelSize, true);
            float railY = top + rowH * 0.72f;

            float innerPad = dp(34);
            float leftValueX = panel.left + innerPad;
            float rightValueX = panel.right - innerPad;
            float valueCol = Math.min(dp(106), panel.width() * 0.30f);
            float railLeft = panel.left + valueCol + dp(18);
            float railRight = panel.right - valueCol - dp(18);
            if (railRight - railLeft < dp(110)) {
                railLeft = panel.left + dp(112);
                railRight = panel.right - dp(112);
            }
            float cX = (railLeft + railRight) / 2f;

            paint.setShadowLayer(dp(4), 0, 0, Color.argb(104, 0, 0, 0));
            drawText(canvas, shareFormat(a, m), leftValueX, valueBaseline, valueSize, aColor, true, Paint.Align.LEFT, 0.00f);
            drawText(canvas, shareFormat(b, m), rightValueX, valueBaseline, valueSize, bColor, true, Paint.Align.RIGHT, 0.00f);
            paint.clearShadowLayer();

            drawText(canvas, m.label, cX, labelBaseline, labelSize, Color.rgb(252, 253, 255), true, Paint.Align.CENTER, 0.10f);

            float half = Math.max(dp(40), (railRight - railLeft) / 2f);
            float leftMid = cX;
            float rightMid = cX;

            strokePaint.setStyle(Paint.Style.STROKE);
            strokePaint.setStrokeCap(Paint.Cap.ROUND);

            // Base rail: clear full-width gold → light center → Dodgers blue blend.
            strokePaint.setStrokeWidth(dp(5));
            strokePaint.setShader(new LinearGradient(railLeft, railY, railRight, railY,
                    new int[] {
                            Color.argb(188, Color.red(aStrong), Color.green(aStrong), Color.blue(aStrong)),
                            Color.argb(92, 236, 242, 250),
                            Color.argb(202, Color.red(bStrong), Color.green(bStrong), Color.blue(bStrong))
                    },
                    new float[] {0f, 0.50f, 1f}, Shader.TileMode.CLAMP));
            canvas.drawLine(railLeft, railY, railRight, railY, strokePaint);

            double[] domain = metricScaleDomain(m, new Double[] { a, b });
            float pa = normalizedForRail(a, domain, m);
            float pb = normalizedForRail(b, domain, m);
            float leftLen = Math.max(dp(16), half * pa);
            float rightLen = Math.max(dp(16), half * pb);
            leftLen = Math.min(leftLen, half);
            rightLen = Math.min(rightLen, half);

            // Left fill travels toward the center and fades out before the label.
            strokePaint.setStrokeWidth(dp(winner < 0 ? 6 : 5));
            strokePaint.setShader(new LinearGradient(leftMid - leftLen, railY, leftMid, railY,
                    new int[] {
                            Color.argb(winner < 0 ? 255 : 220, Color.red(aStrong), Color.green(aStrong), Color.blue(aStrong)),
                            Color.argb(winner < 0 ? 210 : 142, Color.red(aStrong), Color.green(aStrong), Color.blue(aStrong)),
                            Color.argb(24, Color.red(aStrong), Color.green(aStrong), Color.blue(aStrong))
                    },
                    new float[] {0f, 0.72f, 1f}, Shader.TileMode.CLAMP));
            strokePaint.setShadowLayer(dp(winner < 0 ? 6 : 3), 0, 0, Color.argb(winner < 0 ? 118 : 54, Color.red(aStrong), Color.green(aStrong), Color.blue(aStrong)));
            canvas.drawLine(leftMid - leftLen, railY, leftMid, railY, strokePaint);

            // Right fill travels toward the center and fades out before the label.
            strokePaint.setStrokeWidth(dp(winner > 0 ? 6 : 5));
            strokePaint.setShader(new LinearGradient(rightMid, railY, rightMid + rightLen, railY,
                    new int[] {
                            Color.argb(24, Color.red(bStrong), Color.green(bStrong), Color.blue(bStrong)),
                            Color.argb(winner > 0 ? 220 : 150, Color.red(bStrong), Color.green(bStrong), Color.blue(bStrong)),
                            Color.argb(winner > 0 ? 255 : 224, Color.red(bStrong), Color.green(bStrong), Color.blue(bStrong))
                    },
                    new float[] {0f, 0.30f, 1f}, Shader.TileMode.CLAMP));
            strokePaint.setShadowLayer(dp(winner > 0 ? 6 : 3), 0, 0, Color.argb(winner > 0 ? 128 : 58, Color.red(bStrong), Color.green(bStrong), Color.blue(bStrong)));
            canvas.drawLine(rightMid, railY, rightMid + rightLen, railY, strokePaint);
            strokePaint.clearShadowLayer();

            // Center bridge keeps the two side rails visually connected without fighting the stat label.
            strokePaint.setStrokeWidth(dp(2));
            strokePaint.setShader(new LinearGradient(cX - dp(26), railY, cX + dp(26), railY,
                    new int[] { Color.argb(82, Color.red(aStrong), Color.green(aStrong), Color.blue(aStrong)), Color.argb(172, 238, 246, 255), Color.argb(88, Color.red(bStrong), Color.green(bStrong), Color.blue(bStrong)) },
                    null, Shader.TileMode.CLAMP));
            canvas.drawLine(cX - dp(24), railY, cX + dp(24), railY, strokePaint);
            strokePaint.setShader(null);

            // v43: the winner gets a small electric pulse at the meaningful endpoint of that stat's rail.
            if (winner != 0) {
                int sparkColor = winner < 0 ? aStrong : bStrong;
                float sparkX = winner < 0 ? leftMid - leftLen : rightMid + rightLen;
                sparkX = Math.max(railLeft + dp(8), Math.min(railRight - dp(8), sparkX));
                drawRailElectricPulse(canvas, sparkX, railY, sparkColor, winner < 0);
            }
        }

        private void drawRailElectricPulse(Canvas canvas, float x, float y, int color, boolean leftWinner) {
            // v44: smaller plasma-style winner pulse. It sits on the winning end of the rail and glows,
            // but no longer fights with the stat label.
            float len = dp(26);
            float x1 = leftWinner ? x - len : x - dp(8);
            float x2 = leftWinner ? x + dp(8) : x + len;
            drawElectricBolt(canvas, x1, y, x2, y, color, dp(0.9f), 6, dp(1.1f), 104);
            drawElectricBolt(canvas, x1 + dp(2), y + dp(1.1f), x2 - dp(2), y + dp(1.1f), color, dp(0.45f), 5, dp(0.8f), 78);
            drawElectricStar(canvas, x, y, color, dp(5.5f), 0.36f);
        }

        private void drawElectricStar(Canvas canvas, float x, float y, int color, float radius, float strength) {
            paint.setStyle(Paint.Style.FILL);
            paint.setShader(new RadialGradient(x, y, radius * 2.0f,
                    new int[] {
                            Color.argb((int)(155 * strength), 255, 255, 255),
                            Color.argb((int)(96 * strength), Color.red(color), Color.green(color), Color.blue(color)),
                            Color.TRANSPARENT
                    }, new float[] {0f, 0.30f, 1f}, Shader.TileMode.CLAMP));
            canvas.drawCircle(x, y, radius * 2.0f, paint);
            paint.setShader(null);

            strokePaint.setStyle(Paint.Style.STROKE);
            strokePaint.setStrokeCap(Paint.Cap.ROUND);
            strokePaint.setStrokeWidth(dp(0.9f));
            strokePaint.setColor(Color.argb((int)(145 * strength), 245, 252, 255));
            strokePaint.setShadowLayer(dp(3), 0, 0, Color.argb((int)(96 * strength), Color.red(color), Color.green(color), Color.blue(color)));
            canvas.drawLine(x - radius * 0.72f, y, x + radius * 0.72f, y, strokePaint);
            canvas.drawLine(x, y - radius * 0.32f, x, y + radius * 0.32f, strokePaint);
            strokePaint.clearShadowLayer();
        }

        private void drawElectricBolt(Canvas canvas, float x1, float y1, float x2, float y2, int color, float amplitude, int segments, float width, int alpha) {
            Path path = new Path();
            float dx = x2 - x1;
            float dy = y2 - y1;
            float len = (float)Math.sqrt(dx * dx + dy * dy);
            if (len <= 1f) return;
            float nx = -dy / len;
            float ny = dx / len;
            path.moveTo(x1, y1);
            for (int i = 1; i < segments; i++) {
                float t = i / (float)segments;
                float wave = (float)Math.sin(t * Math.PI);
                float jitter = ((i % 2 == 0) ? 1f : -1f) * amplitude * wave * (0.72f + 0.28f * (float)Math.sin(i * 1.35f));
                float px = x1 + dx * t + nx * jitter;
                float py = y1 + dy * t + ny * jitter;
                path.lineTo(px, py);
            }
            path.lineTo(x2, y2);

            strokePaint.setStyle(Paint.Style.STROKE);
            strokePaint.setStrokeCap(Paint.Cap.ROUND);
            strokePaint.setStrokeJoin(Paint.Join.ROUND);
            strokePaint.setShader(null);
            strokePaint.setStrokeWidth(width * 2.4f);
            strokePaint.setColor(Color.argb(Math.max(18, alpha / 5), Color.red(color), Color.green(color), Color.blue(color)));
            strokePaint.setShadowLayer(width * 3f, 0, 0, Color.argb(Math.min(150, alpha), Color.red(color), Color.green(color), Color.blue(color)));
            canvas.drawPath(path, strokePaint);
            strokePaint.clearShadowLayer();

            strokePaint.setStrokeWidth(width);
            strokePaint.setColor(Color.argb(Math.max(50, (int)(alpha * 0.78f)), 235, 248, 255));
            strokePaint.setShadowLayer(width * 1.3f, 0, 0, Color.argb(Math.min(132, alpha), Color.red(color), Color.green(color), Color.blue(color)));
            canvas.drawPath(path, strokePaint);
            strokePaint.clearShadowLayer();
        }

        private int readableTeamColor(int primary, int secondary, boolean leftSide) {
            // Very dark primaries like Padres brown are beautiful in the hero, but need gold/cream for text.
            // For blue teams, keep the primary blue but brighten it enough to read on navy.
            int luminance = (int)(0.299 * Color.red(primary) + 0.587 * Color.green(primary) + 0.114 * Color.blue(primary));
            if (luminance < 92) return leftSide ? softColor(secondary, 0.06f) : softColor(primary, 0.18f);
            return softColor(primary, 0.02f);
        }

        private String shareFormat(Double v, Metric m) {
            String s = format(v, m);
            if (s.startsWith("0.")) return s.substring(1);
            if (s.startsWith("-0.")) return "-" + s.substring(2);
            return s;
        }

        private float normalizedForRail(Double v, double[] domain, Metric m) {
            if (v == null || Double.isNaN(v)) return 0.05f;
            double lo = domain[0], hi = domain[1];
            if (hi <= lo) return 0.5f;
            double norm = (v - lo) / (hi - lo);
            if (m.higherGood != null && !m.higherGood) norm = 1.0 - norm;
            return (float)Math.max(0.08, Math.min(1.0, norm));
        }

        private float centeredTextBaseline(float centerY, float sizePx, boolean bold) {
            paint.setTextSize(sizePx);
            paint.setTypeface(bold ? tfBold : tfRegular);
            Paint.FontMetrics fm = paint.getFontMetrics();
            return centerY - (fm.ascent + fm.descent) / 2f;
        }

        private void drawText(Canvas canvas, String value, float x, float baseline, float sizePx, int color, boolean bold, Paint.Align align, float letterSpacing) {
            paint.setShader(null);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(color);
            paint.setTextSize(sizePx);
            paint.setTypeface(bold ? tfBold : tfRegular);
            paint.setTextAlign(align);
            if (letterSpacing <= 0.01f || value == null || value.length() <= 1) {
                canvas.drawText(value == null ? "" : value, x, baseline, paint);
                return;
            }
            String s = value;
            float extra = sizePx * letterSpacing;
            float total = paint.measureText(s) + extra * (s.length() - 1);
            float start = x;
            if (align == Paint.Align.CENTER) start = x - total / 2f;
            else if (align == Paint.Align.RIGHT) start = x - total;
            paint.setTextAlign(Paint.Align.LEFT);
            for (int i = 0; i < s.length(); i++) {
                String ch = s.substring(i, i + 1);
                canvas.drawText(ch, start, baseline, paint);
                start += paint.measureText(ch) + extra;
            }
            paint.setTextAlign(align);
        }

        private void drawPill(Canvas canvas, String label, float cx, float cy, float w, float h, int fill, int stroke, int textColor, float sp) {
            RectF r = new RectF(cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f);
            paint.setStyle(Paint.Style.FILL);
            paint.setShader(null);
            paint.setColor(fill);
            canvas.drawRoundRect(r, h / 2f, h / 2f, paint);
            strokePaint.setStyle(Paint.Style.STROKE);
            strokePaint.setStrokeWidth(dp(1));
            strokePaint.setColor(stroke);
            canvas.drawRoundRect(r, h / 2f, h / 2f, strokePaint);
            drawText(canvas, label, cx, cy + dp(4), sp, textColor, true, Paint.Align.CENTER, 0.05f);
        }
    }

    private ArrayList<Metric> collectHeadToHeadMetrics(HeadToHeadComparison h, int max) {
        ArrayList<Metric> ordered = new ArrayList<>();
        String[] preferred = new String[] {
                "ops", "wOBA", "xwOBA", "avg", "obp", "slg", "hr", "rbi", "r", "sb",
                "era", "whip", "k9", "bb9", "kbb", "pitchK", "pitchBB", "ip", "kPct", "bbPct"
        };
        for (String key : preferred) {
            Metric m = findMetricByKey(key);
            if (m == null || ordered.contains(m)) continue;
            if (!selectedMetricKeys.contains(m.key)) continue;
            if (h.statsA.get(m.key) == null && h.statsB.get(m.key) == null) continue;
            ordered.add(m);
            if (ordered.size() >= max) return ordered;
        }
        for (Metric m : metrics) {
            if (!selectedMetricKeys.contains(m.key)) continue;
            if (ordered.contains(m)) continue;
            if (h.statsA.get(m.key) == null && h.statsB.get(m.key) == null) continue;
            ordered.add(m);
            if (ordered.size() >= max) break;
        }
        return ordered;
    }

    private int[] countHeadToHeadWins(HeadToHeadComparison h, ArrayList<Metric> metricList) {
        int aWins = 0, bWins = 0;
        for (Metric m : metricList) {
            int winner = headToHeadWinner(h, m);
            if (winner < 0) aWins++;
            else if (winner > 0) bWins++;
        }
        return new int[] { aWins, bWins };
    }

    // returns -1 for left/A, +1 for right/B, 0 for tie/unknown
    private int headToHeadWinner(HeadToHeadComparison h, Metric m) {
        Double vA = h.statsA.get(m.key);
        Double vB = h.statsB.get(m.key);
        if (vA == null || vB == null) return 0;
        double d = vA - vB;
        if (Math.abs(d) < 0.000001) return 0;
        boolean aLeads = m.higherGood == null ? d > 0 : (m.higherGood ? d > 0 : d < 0);
        return aLeads ? -1 : 1;
    }

    private int darkColor(int color, float amountBlack) {
        int r = Math.round(Color.red(color) * (1f - amountBlack));
        int g = Math.round(Color.green(color) * (1f - amountBlack));
        int b = Math.round(Color.blue(color) * (1f - amountBlack));
        return Color.rgb(Math.max(0, r), Math.max(0, g), Math.max(0, b));
    }

    private void applyRoundedClip(View v, int radiusDp) {
        if (Build.VERSION.SDK_INT >= 21) {
            final float radius = dp(radiusDp);
            v.setClipToOutline(true);
            v.setOutlineProvider(new ViewOutlineProvider() {
                @Override public void getOutline(View view, Outline outline) {
                    outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), radius);
                }
            });
        }
    }

    private View sharePlayerTile(HeadToHeadComparison h, boolean left, TeamPalette palette, boolean onDark) {
        LinearLayout tile = new LinearLayout(this);
        tile.setOrientation(LinearLayout.VERTICAL);
        tile.setGravity(left ? Gravity.LEFT : Gravity.RIGHT);
        tile.setPadding(dp(2), 0, dp(2), 0);

        FrameLayout outer = new FrameLayout(this);
        outer.setPadding(dp(4), dp(4), dp(4), dp(4));
        outer.setBackground(roundedGradient(new int[] { palette.primary, softColor(palette.secondary, 0.12f) }, 28));
        outer.setElevation(dp(3));

        FrameLayout matte = new FrameLayout(this);
        matte.setPadding(dp(3), dp(3), dp(3), dp(3));
        matte.setBackground(rounded(Color.argb(248, 255, 255, 255), 24));
        applyRoundedClip(matte, 24);
        outer.addView(matte, new FrameLayout.LayoutParams(-1, -1));

        if (h.isTeam) {
            View logo = teamLogoView(left ? h.teamA : h.teamB, 56);
            FrameLayout.LayoutParams logoLp = new FrameLayout.LayoutParams(-2, -2);
            logoLp.gravity = Gravity.CENTER;
            matte.addView(logo, logoLp);
        } else {
            ImageView img = new ImageView(this);
            img.setScaleType(ImageView.ScaleType.CENTER_CROP);
            img.setAdjustViewBounds(false);
            img.setBackground(rounded(Color.WHITE, 22));
            applyRoundedClip(img, 22);
            matte.addView(img, new FrameLayout.LayoutParams(-1, -1));
            loadPlayerImage(left ? h.idA : h.idB, img);
        }

        LinearLayout.LayoutParams frameLp = new LinearLayout.LayoutParams(dp(76), dp(76));
        frameLp.gravity = left ? Gravity.LEFT : Gravity.RIGHT;
        tile.addView(outer, frameLp);

        int nameColor = onDark ? Color.WHITE : INK;
        int metaColor = onDark ? Color.rgb(225, 234, 246) : Color.rgb(98, 110, 130);
        TextView name = text(twoLineName(left ? h.nameA : h.nameB), 16, nameColor, true);
        name.setPadding(0, dp(8), 0, 0);
        name.setGravity(left ? Gravity.LEFT : Gravity.RIGHT);
        name.setMaxLines(2);
        tile.addView(name, matchWrap());
        TextView meta = text(left ? h.metaA : h.metaB, 10, metaColor, false);
        meta.setGravity(left ? Gravity.LEFT : Gravity.RIGHT);
        meta.setPadding(0, dp(3), 0, 0);
        tile.addView(meta, matchWrap());
        return tile;
    }

    private String twoLineName(String name) {
        String s = safe(name).trim();
        String[] parts = s.split("\\s+");
        if (parts.length >= 3 && s.length() > 15) return parts[0] + "\n" + s.substring(parts[0].length()).trim();
        if (parts.length == 2 && s.length() > 14) return parts[0] + "\n" + parts[1];
        return s;
    }

    private LinearLayout shareScoreBlock(String name, String wins, int color, boolean active, boolean onDark) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(dp(4), dp(2), dp(4), dp(2));

        TextView num = text(wins, active ? 32 : 24, active ? Color.WHITE : Color.rgb(225, 233, 244), true);
        num.setGravity(Gravity.CENTER);
        num.setFontFeatureSettings("'tnum' 1");
        if (active) {
            num.setPadding(dp(12), dp(5), dp(12), dp(5));
            num.setBackground(roundedGradient(new int[] { color, softColor(color, 0.12f) }, 18));
        }
        box.addView(num, matchWrap());

        TextView label = text(name, 9, onDark ? Color.rgb(214, 224, 239) : Color.rgb(108, 119, 138), true);
        label.setGravity(Gravity.CENTER);
        label.setSingleLine(true);
        label.setPadding(0, dp(4), 0, 0);
        box.addView(label, matchWrap());
        return box;
    }

    private View shareMetricRow(HeadToHeadComparison h, Metric m, TeamPalette paletteA, TeamPalette paletteB) {
        Double a = h.statsA.get(m.key);
        Double b = h.statsB.get(m.key);
        int winner = headToHeadWinner(h, m);
        int winnerColor = winner < 0 ? paletteA.primary : (winner > 0 ? paletteB.primary : Color.rgb(112, 122, 138));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(dp(11), dp(9), dp(11), dp(9));
        LinearLayout.LayoutParams lp = matchWrap();
        lp.setMargins(0, dp(5), 0, 0);
        row.setLayoutParams(lp);
        row.setBackground(roundedStroke(Color.rgb(252, 253, 255), Color.rgb(229, 235, 245), 18, 1));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView leftValue = shareMetricValue(format(a, m), winner < 0 ? paletteA.primary : Color.rgb(42, 49, 63), winner < 0, Gravity.LEFT);
        top.addView(leftValue, new LinearLayout.LayoutParams(0, -2, 1));

        LinearLayout center = new LinearLayout(this);
        center.setOrientation(LinearLayout.VERTICAL);
        center.setGravity(Gravity.CENTER);
        TextView label = text(m.label.toUpperCase(Locale.US), 11, Color.rgb(54, 63, 78), true);
        label.setGravity(Gravity.CENTER);
        label.setLetterSpacing(0.08f);
        center.addView(label, matchWrap());
        TextView edge = text(winner == 0 ? "EVEN" : (winner < 0 ? shortName(h.nameA).toUpperCase(Locale.US) : shortName(h.nameB).toUpperCase(Locale.US)), 8, winnerColor, true);
        edge.setGravity(Gravity.CENTER);
        edge.setSingleLine(true);
        center.addView(edge, matchWrap());
        top.addView(center, new LinearLayout.LayoutParams(0, -2, 0.9f));

        TextView rightValue = shareMetricValue(format(b, m), winner > 0 ? paletteB.primary : Color.rgb(42, 49, 63), winner > 0, Gravity.RIGHT);
        top.addView(rightValue, new LinearLayout.LayoutParams(0, -2, 1));
        row.addView(top, matchWrap());

        View rail = new View(this);
        int[] railColors;
        if (winner < 0) {
            railColors = new int[] { softColor(paletteA.primary, 0.18f), softColor(paletteA.primary, 0.62f), Color.rgb(226, 232, 242), softColor(paletteB.primary, 0.78f) };
        } else if (winner > 0) {
            railColors = new int[] { softColor(paletteA.primary, 0.78f), Color.rgb(226, 232, 242), softColor(paletteB.primary, 0.60f), softColor(paletteB.primary, 0.18f) };
        } else {
            railColors = new int[] { softColor(paletteA.primary, 0.70f), Color.rgb(226, 232, 242), softColor(paletteB.primary, 0.70f) };
        }
        rail.setBackground(roundedGradient(railColors, 6));
        LinearLayout.LayoutParams railLp = new LinearLayout.LayoutParams(-1, dp(6));
        railLp.setMargins(0, dp(8), 0, 0);
        row.addView(rail, railLp);
        return row;
    }

    private TextView shareMetricValue(String value, int color, boolean winner, int gravity) {
        TextView tv = text(value, winner ? 20 : 18, color, true);
        tv.setGravity(gravity | Gravity.CENTER_VERTICAL);
        tv.setFontFeatureSettings("'tnum' 1");
        tv.setSingleLine(true);
        tv.setPadding(winner ? dp(9) : 0, winner ? dp(5) : 0, winner ? dp(9) : 0, winner ? dp(5) : 0);
        if (winner) tv.setBackground(roundedStroke(softColor(color, 0.90f), softColor(color, 0.62f), 15, 1));
        return tv;
    }

    private View categoryPill(String label, String winner, TeamPalette paletteA, TeamPalette paletteB) {
        int color = NAVY;
        if (winner.startsWith("A:")) { color = paletteA.primary; winner = winner.substring(2); }
        else if (winner.startsWith("B:")) { color = paletteB.primary; winner = winner.substring(2); }
        else if (winner.startsWith("T:")) { winner = winner.substring(2); }
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(dp(5), dp(8), dp(5), dp(8));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
        lp.setMargins(dp(2), 0, dp(2), 0);
        box.setLayoutParams(lp);
        box.setBackground(roundedStroke(softColor(color, 0.93f), softColor(color, 0.65f), 15, 1));
        TextView top = text(label.toUpperCase(Locale.US), 8, Color.rgb(112, 124, 144), true);
        top.setGravity(Gravity.CENTER);
        top.setLetterSpacing(0.05f);
        box.addView(top, matchWrap());
        TextView bottom = text(winner, 10, color, true);
        bottom.setGravity(Gravity.CENTER);
        bottom.setSingleLine(true);
        bottom.setPadding(0, dp(2), 0, 0);
        box.addView(bottom, matchWrap());
        return box;
    }

    private String categoryWinner(HeadToHeadComparison h, String[] keys) {
        int a = 0, b = 0;
        for (String key : keys) {
            Metric m = findMetricByKey(key);
            if (m == null) continue;
            if (!selectedMetricKeys.contains(m.key)) continue;
            int w = headToHeadWinner(h, m);
            if (w < 0) a++; else if (w > 0) b++;
        }
        if (a == 0 && b == 0) return "T:—";
        if (a == b) return "T:Split";
        return (a > b ? "A:" + shortName(h.nameA) : "B:" + shortName(h.nameB));
    }

    // v30: Face-off layout for H2H stat cards — value+tier columns flanking the bar, gap significance footer
    private void renderHeadToHeadMetricRow(HeadToHeadComparison h, Metric m, TeamPalette paletteA, TeamPalette paletteB) {
        Double valueA = h.statsA.get(m.key);
        Double valueB = h.statsB.get(m.key);
        Double leagueValue = h.leagueStats == null ? null : h.leagueStats.get(m.key);
        Double delta = diff(valueA, valueB);
        if (valueA == null && valueB == null) return;

        Integer rankA = h.rankA == null ? null : h.rankA.get(m.key);
        Integer rankB = h.rankB == null ? null : h.rankB.get(m.key);
        Integer totalA = h.rankTotalA == null ? null : h.rankTotalA.get(m.key);
        Integer totalB = h.rankTotalB == null ? null : h.rankTotalB.get(m.key);
        Double pctA = h.percentileA == null ? null : h.percentileA.get(m.key);
        Double pctB = h.percentileB == null ? null : h.percentileB.get(m.key);

        boolean aLeads = false, bLeads = false;
        String leader = "Even";
        int leaderColor = Color.rgb(70, 88, 125);
        if (delta != null && Math.abs(delta) > 0.000001) {
            aLeads = m.higherGood == null ? delta > 0 : (m.higherGood ? delta > 0 : delta < 0);
            bLeads = !aLeads;
            leader = shortName(aLeads ? h.nameA : h.nameB) + " leads";
            leaderColor = aLeads ? paletteA.primary : paletteB.primary;
        }

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(dp(14), dp(12), dp(14), dp(12));
        LinearLayout.LayoutParams rowLp = matchWrap();
        rowLp.setMargins(0, dp(7), 0, 0);
        row.setBackground(roundedStroke(CARD, softColor(paletteA.primary, 0.68f), 20, 1));
        metricBox.addView(row, rowLp);

        // ── Top: metric label + leader badge ────────────────────────────────
        LinearLayout topLine = new LinearLayout(this);
        topLine.setOrientation(LinearLayout.HORIZONTAL);
        topLine.setGravity(Gravity.CENTER_VERTICAL);
        topLine.addView(text(m.label, 16, INK, true), new LinearLayout.LayoutParams(0, -2, 1));
        TextView leaderBadge = text(leader, 11, Color.WHITE, true);
        leaderBadge.setGravity(Gravity.CENTER);
        leaderBadge.setPadding(dp(10), dp(5), dp(10), dp(5));
        leaderBadge.setBackground(roundedGradient(new int[] { leaderColor, softColor(leaderColor, 0.12f) }, 14));
        topLine.addView(leaderBadge);
        row.addView(topLine, matchWrap());

        // ── Face-off: Player A | vs | Player B ──────────────────────────────
        LinearLayout faceOff = new LinearLayout(this);
        faceOff.setOrientation(LinearLayout.HORIZONTAL);
        faceOff.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams foLp = matchWrap();
        foLp.setMargins(0, dp(10), 0, dp(4));

        // Side A box
        LinearLayout sideA = new LinearLayout(this);
        sideA.setOrientation(LinearLayout.VERTICAL);
        sideA.setGravity(Gravity.CENTER);
        sideA.setPadding(dp(10), dp(9), dp(10), dp(9));
        sideA.setBackground(aLeads
                ? roundedGradient(new int[] { softColor(paletteA.primary, 0.86f), Color.WHITE }, 14)
                : rounded(Color.rgb(247, 249, 253), 14));
        TextView valA = text(valueA == null ? "—" : format(valueA, m), aLeads ? 22 : 18, aLeads ? paletteA.primary : INK, true);
        valA.setGravity(Gravity.CENTER);
        valA.setFontFeatureSettings("'tnum' 1");
        sideA.addView(valA, matchWrap());
        String tierA = percentileTierLabel(pctA);
        String rankLabelA = pctA == null ? "" : "  " + Math.round(Math.max(0, Math.min(100, pctA))) + "%";
        TextView ctxA = text(tierA + rankLabelA, 9, aLeads ? paletteA.primary : MUTED, true);
        ctxA.setGravity(Gravity.CENTER);
        ctxA.setPadding(0, dp(2), 0, 0);
        sideA.addView(ctxA, matchWrap());
        faceOff.addView(sideA, new LinearLayout.LayoutParams(0, -2, 1));

        // Center "vs"
        TextView vsTv = text("vs", 10, MUTED, false);
        vsTv.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams vsLp = new LinearLayout.LayoutParams(dp(28), -2);
        vsLp.gravity = Gravity.CENTER_VERTICAL;
        faceOff.addView(vsTv, vsLp);

        // Side B box
        LinearLayout sideB = new LinearLayout(this);
        sideB.setOrientation(LinearLayout.VERTICAL);
        sideB.setGravity(Gravity.CENTER);
        sideB.setPadding(dp(10), dp(9), dp(10), dp(9));
        sideB.setBackground(bLeads
                ? roundedGradient(new int[] { Color.WHITE, softColor(paletteB.primary, 0.86f) }, 14)
                : rounded(Color.rgb(247, 249, 253), 14));
        TextView valB = text(valueB == null ? "—" : format(valueB, m), bLeads ? 22 : 18, bLeads ? paletteB.primary : INK, true);
        valB.setGravity(Gravity.CENTER);
        valB.setFontFeatureSettings("'tnum' 1");
        sideB.addView(valB, matchWrap());
        String tierB = percentileTierLabel(pctB);
        String rankLabelB = pctB == null ? "" : "  " + Math.round(Math.max(0, Math.min(100, pctB))) + "%";
        TextView ctxB = text(tierB + rankLabelB, 9, bLeads ? paletteB.primary : MUTED, true);
        ctxB.setGravity(Gravity.CENTER);
        ctxB.setPadding(0, dp(2), 0, 0);
        sideB.addView(ctxB, matchWrap());
        faceOff.addView(sideB, new LinearLayout.LayoutParams(0, -2, 1));

        row.addView(faceOff, foLp);

        // ── Percentile bar ───────────────────────────────────────────────────
        HeadToHeadBarView bar = new HeadToHeadBarView(this, m,
                new Double[] { valueA, valueB, leagueValue },
                new Double[] { pctA, pctB, 50.0 },
                paletteA, paletteB, h.nameA, h.nameB);
        LinearLayout.LayoutParams barLp = new LinearLayout.LayoutParams(-1, dp(64));
        barLp.setMargins(0, dp(2), 0, 0);
        row.addView(bar, barLp);
        if (h.isTeam) {
            loadTeamLogoBitmap(h.teamA, bar::setIconA);
            loadTeamLogoBitmap(h.teamB, bar::setIconB);
        } else {
            loadPlayerImageBitmap(h.idA, bar::setIconA);
            loadPlayerImageBitmap(h.idB, bar::setIconB);
        }

        // ── Gap significance footer: rank left · delta+context center · rank right ──
        LinearLayout gapRow = new LinearLayout(this);
        gapRow.setOrientation(LinearLayout.HORIZONTAL);
        gapRow.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams gapLp = matchWrap();
        gapLp.setMargins(0, dp(7), 0, 0);

        TextView rankTvA = text(rankOnlyLabel(rankA, totalA), 10, paletteA.primary, true);
        rankTvA.setFontFeatureSettings("'tnum' 1");
        gapRow.addView(rankTvA, new LinearLayout.LayoutParams(0, -2, 1));

        String gapCtx = "";
        if (delta != null && leagueValue != null) {
            double distA = valueA == null ? 0 : Math.abs(valueA - leagueValue);
            double distB = valueB == null ? 0 : Math.abs(valueB - leagueValue);
            double maxDist = Math.max(distA, distB);
            if (maxDist > 0.00001) {
                double ratio = Math.abs(delta) / maxDist;
                if (ratio > 1.5)      gapCtx = " · dominant";
                else if (ratio > 0.6) gapCtx = " · clear gap";
                else if (ratio > 0.2) gapCtx = " · slim edge";
                else                  gapCtx = " · marginal";
            }
        }
        String gapStr = delta == null ? "—" : signedFormat(delta, m);
        TextView gapTv = text(gapStr + gapCtx, 10, MUTED, false);
        gapTv.setGravity(Gravity.CENTER);
        gapTv.setFontFeatureSettings("'tnum' 1");
        gapRow.addView(gapTv, new LinearLayout.LayoutParams(0, -2, 1));

        TextView rankTvB = text(rankOnlyLabel(rankB, totalB), 10, paletteB.primary, true);
        rankTvB.setGravity(Gravity.RIGHT);
        rankTvB.setFontFeatureSettings("'tnum' 1");
        gapRow.addView(rankTvB, new LinearLayout.LayoutParams(0, -2, 1));

        row.addView(gapRow, gapLp);
    }

    private TeamPalette paletteForHeadToHeadSide(HeadToHeadComparison h, boolean leftSide) {
        if (h == null) return defaultPalette();
        if (h.isTeam) return paletteForTeam(leftSide ? h.teamA : h.teamB);
        Player p = leftSide ? h.playerA : h.playerB;
        return paletteForAbbr(p == null ? "" : p.teamAbbr);
    }

    private int deltaColorForHeadToHead(Double delta, Metric m, TeamPalette paletteA, TeamPalette paletteB) {
        if (delta == null || delta == 0) return MUTED;
        boolean leftBetter = delta > 0;
        if (m.higherGood != null && !m.higherGood) leftBetter = delta < 0;
        return leftBetter ? paletteA.primary : paletteB.primary;
    }

    private String shortName(String name) {
        String s = safe(name).trim();
        if (s.length() <= 12) return s;
        String[] parts = s.split("\\s+");
        if (parts.length >= 2) return parts[parts.length - 1];
        return s.substring(0, 12);
    }


    private void refreshCurrentResults() {
        if (resultsBox.getVisibility() != View.VISIBLE) return;
        if (lastHeadToHead != null) renderHeadToHead(lastHeadToHead);
        else if (lastComparison != null) renderComparison(lastComparison);
    }

    private TextView summaryPill(String label, String value) {
        TextView tv = text(label + "\n" + value, 12, INK, true);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(dp(6), dp(9), dp(6), dp(9));
        tv.setBackground(roundedStroke(Color.rgb(248, 250, 253), LINE, 16, 1));
        tv.setLineSpacing(dp(2), 1.0f);
        return tv;
    }

    private TextView profileDataPill(String value, String label, TeamPalette palette) {
        TextView tv = text(label + "\n" + value, 11, Color.WHITE, true);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(dp(7), dp(6), dp(7), dp(6));
        tv.setLineSpacing(dp(1), 1.0f);
        tv.setBackground(roundedStroke(Color.argb(34, 255, 255, 255), Color.argb(70, 255, 255, 255), 14, 1));
        tv.setFontFeatureSettings("'tnum' 1");
        return tv;
    }

    private TextView smallDataPill(String value) {
        TextView tv = text(value, 11, Color.rgb(64, 75, 94), true);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(dp(6), dp(4), dp(6), dp(4));
        tv.setBackground(roundedStroke(Color.WHITE, Color.rgb(222, 231, 242), 12, 1));
        tv.setFontFeatureSettings("'tnum' 1");  // v29: tabular figures for count pills
        return tv;
    }

    private TextView insightTile(String label, String value, int accent) {
        TextView tv = text(label + "\n" + value, 12, accent, true);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(dp(6), dp(8), dp(6), dp(8));
        tv.setBackground(roundedStroke(Color.WHITE, Color.rgb(224, 232, 243), 16, 1));
        tv.setLineSpacing(dp(2), 1.0f);
        return tv;
    }

    private String keyStatSummary(Stats s) {
        if (s == null) return "—";
        Double w = s.get("wOBA");
        Double x = s.get("xwOBA");
        Double l = s.get("luck");
        String luckText = l == null ? "" : " · Luck " + new DecimalFormat("+0.000;-0.000").format(l);
        return "wOBA " + format(w, metricByKey("wOBA")) + "\nxwOBA " + format(x, metricByKey("xwOBA")) + luckText;
    }

    private Metric metricByKey(String key) {
        for (Metric m : metrics) if (m.key.equals(key)) return m;
        return metrics[0];
    }

    private Metric findMetricByKey(String key) {
        for (Metric m : metrics) if (m.key.equals(key)) return m;
        return null;
    }


    private View comparisonLegend(String thirdLabelShort, TeamPalette palette) {
        LinearLayout legend = new LinearLayout(this);
        legend.setOrientation(LinearLayout.HORIZONTAL);
        legend.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        legend.addView(legendMini("Selected", palette.primary));
        legend.addView(legendMini("League", Color.rgb(70, 88, 125)));
        legend.addView(legendMini(thirdLabelShort, palette.secondary));
        return legend;
    }


    private TextView legendMini(String label, int color) {
        TextView tv = text("● " + label, 9, color, true);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(dp(3), dp(2), dp(3), dp(2));
        return tv;
    }


    private void renderMetricRow(Comparison c, Metric m, TeamPalette palette) {
        Double seasonValue = c.seasonStats.get(m.key);
        Double leagueValue = c.leagueStats == null ? null : c.leagueStats.get(m.key);
        Double careerValue = c.careerStats.get(m.key);
        Double vsLeague = diff(seasonValue, leagueValue);

        LinearLayout row = verticalCard(18, null);
        row.setPadding(dp(12), dp(10), dp(12), dp(10));
        row.setBackground(roundedStroke(Color.WHITE, softColor(palette.primary, 0.70f), 18, 1));
        LinearLayout.LayoutParams rowLp = matchWrap();
        rowLp.setMargins(0, dp(7), 0, 0);
        metricBox.addView(row, rowLp);

        Integer rank = c.rank == null ? null : c.rank.get(m.key);
        Integer total = c.rankTotal == null ? null : c.rankTotal.get(m.key);
        Double pct = c.percentile == null ? null : c.percentile.get(m.key);
        Double thirdPct = c.thirdPercentile == null ? null : c.thirdPercentile.get(m.key);

        LinearLayout topLine = new LinearLayout(this);
        topLine.setOrientation(LinearLayout.HORIZONTAL);
        topLine.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout metricTitle = new LinearLayout(this);
        metricTitle.setOrientation(LinearLayout.HORIZONTAL);
        metricTitle.setGravity(Gravity.CENTER_VERTICAL);
        TextView label = text(m.label, 16, INK, true);
        metricTitle.addView(label);
        String desc = metricDescription(m.key);
        if (!desc.isEmpty()) {
            TextView info = text("i", 9, MUTED, true);
            info.setGravity(Gravity.CENTER);
            info.setPadding(dp(5), 0, dp(5), 0);
            info.setBackground(roundedStroke(Color.TRANSPARENT, Color.rgb(210, 220, 234), 9, 1));
            LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(dp(18), dp(18));
            ip.setMargins(dp(6), 0, 0, 0);
            metricTitle.addView(info, ip);
            info.setOnClickListener(v -> showMetricGlossary(m));
            info.setForeground(ripple(false));
        }
        topLine.addView(metricTitle, new LinearLayout.LayoutParams(0, -2, 1));

        TextView pctBadge = text(pct == null ? "No percentile" : percentileLabel(pct), 11, Color.WHITE, true);
        pctBadge.setGravity(Gravity.CENTER);
        pctBadge.setPadding(dp(9), dp(5), dp(9), dp(5));
        pctBadge.setBackground(roundedGradient(new int[] { palette.primary, softColor(palette.primary, 0.08f) }, 14));
        topLine.addView(pctBadge);
        row.addView(topLine);

        String rankLine = rank == null ? "League rank unavailable for this stat" : "League rank: #" + rank + (total == null || total <= 0 ? "" : " of " + total);
        TextView rankTv = text(rankLine, 11, Color.rgb(88, 99, 118), false);
        rankTv.setPadding(0, dp(5), 0, 0);
        row.addView(rankTv);

        ComparisonBarView bar = new ComparisonBarView(this, m,
                new Double[] { seasonValue, leagueValue, careerValue },
                new Double[] { pct, 50.0, thirdPct },
                c.thirdLabelShort(), palette, c.isTeam ? c.meta : c.name);
        LinearLayout.LayoutParams barLp = new LinearLayout.LayoutParams(-1, dp(72));
        barLp.setMargins(0, dp(5), 0, 0);
        row.addView(bar, barLp);
        if (c.isTeam) loadTeamLogoBitmap(c.team, bar::setCurrentIcon);
        else loadPlayerImageBitmap(c.mlbId, bar::setCurrentIcon);

        LinearLayout valueLine = new LinearLayout(this);
        valueLine.setOrientation(LinearLayout.HORIZONTAL);
        valueLine.setPadding(0, dp(4), 0, 0);
        valueLine.addView(statValueColumn("This year", format(seasonValue, m), "", palette.primary, true), weightLp());
        valueLine.addView(statValueColumn("MLB avg", format(leagueValue, m), "", Color.rgb(70, 88, 125), false), weightLp());
        valueLine.addView(statValueColumn(c.thirdLabelShort(), format(careerValue, m), "", palette.secondary, false), weightLp());
        row.addView(valueLine);

        renderTrendForMetric(row, c, m, palette);
    }

    private void addTrendModeControl(Comparison c, TeamPalette palette) {
        boolean hasSeason = c != null && c.seasonTrends != null && !c.seasonTrends.isEmpty();
        boolean hasSeasons = c != null && c.recentSeasons != null && c.recentSeasons.size() >= 2;
        if (!hasSeason && !hasSeasons) return;

        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setPadding(0, 0, 0, dp(7));
        LinearLayout title = new LinearLayout(this);
        title.setOrientation(LinearLayout.HORIZONTAL);
        title.setGravity(Gravity.CENTER_VERTICAL);
        title.addView(text("Trend", 11, INK, true), new LinearLayout.LayoutParams(0, -2, 1));
        TextView hint = text(trendModeCaption(), 9, MUTED, false);
        hint.setGravity(Gravity.RIGHT);
        title.addView(hint);
        wrap.addView(title, matchWrap());

        HorizontalScrollView scroller = new HorizontalScrollView(this);
        scroller.setHorizontalScrollBarEnabled(false);
        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        tabs.setPadding(0, dp(5), 0, 0);
        addTrendTab(tabs, "Season", "season", palette, hasSeason);
        addTrendTab(tabs, "30d", "30d", palette, hasSeason);
        addTrendTab(tabs, "15d", "15d", palette, hasSeason);
        addTrendTab(tabs, "7d", "7d", palette, hasSeason);
        addTrendTab(tabs, "Years", "years", palette, hasSeasons);
        scroller.addView(tabs, new HorizontalScrollView.LayoutParams(-2, -2));
        wrap.addView(scroller, matchWrap());
        metricBox.addView(wrap, matchWrap());
    }

    private void addTrendTab(LinearLayout tabs, String label, String mode, TeamPalette palette, boolean enabled) {
        TextView tv = text(label, 11, enabled ? (mode.equals(trendWindowMode) ? Color.WHITE : palette.primary) : Color.rgb(150, 158, 172), true);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(dp(11), dp(6), dp(11), dp(6));
        tv.setBackground(mode.equals(trendWindowMode) && enabled ? roundedGradient(new int[] { palette.primary, palette.secondary }, 14) : roundedStroke(Color.WHITE, Color.rgb(218, 226, 238), 14, 1));
        tv.setEnabled(enabled);
        if (enabled) tv.setOnClickListener(v -> {
            trendWindowMode = mode;
            if (lastComparison != null) {
                if (expectedMode) renderExpectedComparison(lastComparison); else renderComparison(lastComparison);
            }
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.setMargins(0, 0, dp(6), 0);
        tabs.addView(tv, lp);
    }

    private String trendModeCaption() {
        if ("years".equals(trendWindowMode)) return "season-to-season";
        if ("season".equals(trendWindowMode)) return "cumulative season";
        return trendWindowMode + " window average";
    }

    private String trendModeFor(Metric m) {
        if (m == null) return trendWindowMode;
        String mode = metricTrendModes.get(m.key);
        return mode == null ? trendWindowMode : mode;
    }

    private boolean isCurrentSeason(int season) {
        return season == Calendar.getInstance().get(Calendar.YEAR);
    }

    private boolean isRollingTrendMode(String mode) {
        return "7d".equals(mode) || "15d".equals(mode) || "30d".equals(mode);
    }

    private void addMetricTrendTabs(LinearLayout parent, Comparison c, Metric m, TeamPalette palette, boolean hasSeason, boolean hasSeasons, String mode) {
        boolean currentSeason = c != null && isCurrentSeason(c.season);
        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        tabs.setGravity(Gravity.CENTER_VERTICAL);
        tabs.setPadding(0, dp(6), 0, 0);
        tabs.addView(text("Trend", 10, Color.rgb(85, 96, 116), true), new LinearLayout.LayoutParams(0, -2, 1));
        addInlineTrendTab(tabs, m, "Season", "season", palette, hasTrendForMode(c, m, "season", hasSeasons), mode);
        if (currentSeason) {
            addInlineTrendTab(tabs, m, "30d", "30d", palette, hasTrendForMode(c, m, "30d", hasSeasons), mode);
            addInlineTrendTab(tabs, m, "15d", "15d", palette, hasTrendForMode(c, m, "15d", hasSeasons), mode);
            addInlineTrendTab(tabs, m, "7d", "7d", palette, hasTrendForMode(c, m, "7d", hasSeasons), mode);
        }
        addInlineTrendTab(tabs, m, "Years", "years", palette, hasSeasons, mode);
        parent.addView(tabs, matchWrap());
    }

    private boolean hasTrendForMode(Comparison c, Metric m, String mode, boolean hasSeasons) {
        if ("years".equals(mode)) return hasSeasons;
        if (c == null || c.seasonTrends == null || m == null) return false;
        return trendPointCount(c.seasonTrends.get(trendMetricKey(m.key, mode))) >= 2;
    }

    private void addInlineTrendTab(LinearLayout tabs, Metric m, String label, String mode, TeamPalette palette, boolean enabled, String activeMode) {
        TextView tv = text(label, 9, enabled ? (mode.equals(activeMode) ? Color.WHITE : palette.primary) : Color.rgb(160, 168, 180), true);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(dp(7), dp(4), dp(7), dp(4));
        tv.setBackground(mode.equals(activeMode) && enabled ? roundedGradient(new int[] { palette.primary, palette.secondary }, 12) : roundedStroke(Color.WHITE, Color.rgb(218, 226, 238), 12, 1));
        tv.setEnabled(enabled);
        if (enabled) tv.setOnClickListener(v -> {
            int keepY = mainScroll == null ? 0 : mainScroll.getScrollY();
            metricTrendModes.put(m.key, mode);
            suppressNextAutoScroll = true;
            if (lastComparison != null) {
                if (expectedMode) renderExpectedComparison(lastComparison); else renderComparison(lastComparison);
            }
            if (mainScroll != null) mainScroll.post(() -> mainScroll.scrollTo(0, keepY));
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.setMargins(dp(4), 0, 0, 0);
        tabs.addView(tv, lp);
    }

    private void renderTrendForMetric(LinearLayout parent, Comparison c, Metric m, TeamPalette palette) {
        if (c == null || m == null) return;
        boolean hasSeason = c.seasonTrends != null && !c.seasonTrends.isEmpty();
        boolean hasSeasons = c.recentSeasons != null && c.recentSeasons.size() >= 2;
        if (!hasSeason && !hasSeasons) return;
        String mode = trendModeFor(m);
        boolean currentSeason = isCurrentSeason(c.season);
        if (!currentSeason && isRollingTrendMode(mode)) mode = hasTrendForMode(c, m, "season", hasSeasons) ? "season" : "years";
        if (!hasTrendForMode(c, m, mode, hasSeasons)) {
            if (hasTrendForMode(c, m, "season", hasSeasons)) mode = "season";
            else if (hasSeasons) mode = "years";
        }
        addMetricTrendTabs(parent, c, m, palette, hasSeason, hasSeasons, mode);
        if ("years".equals(mode)) {
            if (hasSeasons) renderSparklineRow(parent, c.recentSeasons, m, palette);
            return;
        }
        ArrayList<TrendPoint> points = c.seasonTrends == null ? null : c.seasonTrends.get(trendMetricKey(m.key, mode));
        if (trendPointCount(points) >= 2) {
            String title = "season".equals(mode) ? "Season-to-date" : mode + (m.isCount() ? " cumulative total" : " period rate");
            renderTrendPointRow(parent, title, points, m, palette, mode);
        } else if (hasSeasons) {
            renderSparklineRow(parent, c.recentSeasons, m, palette);
        }
    }

    private String trendMetricKey(String metricKey, String mode) {
        if ("7d".equals(mode) || "15d".equals(mode) || "30d".equals(mode)) return metricKey + "__" + mode;
        return metricKey;
    }

    private int trendPointCount(ArrayList<TrendPoint> pts) {
        if (pts == null) return 0;
        int n = 0;
        for (TrendPoint p : pts) if (p != null && p.value != null && !Double.isNaN(p.value)) n++;
        return n;
    }

    private void renderTrendPointRow(LinearLayout parent, String title, ArrayList<TrendPoint> points, Metric m, TeamPalette palette, String mode) {
        if (trendPointCount(points) < 2) return;
        ArrayList<Double> values = new ArrayList<>();
        ArrayList<String> labels = new ArrayList<>();
        for (TrendPoint p : points) {
            values.add(p == null ? null : p.value);
            labels.add(p == null ? "" : p.label);
        }
        LinearLayout shell = new LinearLayout(this);
        shell.setOrientation(LinearLayout.VERTICAL);
        shell.setPadding(dp(9), dp(8), dp(9), dp(8));
        shell.setBackground(roundedStroke(Color.rgb(252, 253, 255), softColor(palette.primary, 0.68f), 16, 1));
        LinearLayout.LayoutParams shellLp = matchWrap();
        shellLp.setMargins(0, dp(7), 0, 0);

        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setOrientation(LinearLayout.HORIZONTAL);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView sparkTitle = text(title, 10, Color.rgb(85, 96, 116), true);
        sparkTitle.setLetterSpacing(0.06f);
        titleRow.addView(sparkTitle, new LinearLayout.LayoutParams(0, -2, 1));
        String chipText;
        if ("season".equals(mode) || "years".equals(mode)) chipText = "Current " + format(lastNonNull(values), m);
        else chipText = (m.isCount() ? "Total " : "Window ") + format(lastNonNull(values), m);
        TextView avgChip = text(chipText, 9, palette.primary, true);
        avgChip.setGravity(Gravity.CENTER);
        avgChip.setPadding(dp(7), dp(3), dp(7), dp(3));
        avgChip.setBackground(roundedStroke(Color.WHITE, softColor(palette.primary, 0.55f), 12, 1));
        titleRow.addView(avgChip);
        shell.addView(titleRow, matchWrap());

        SparklineView spark = new SparklineView(this, values, labels, m, palette.primary);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(-1, dp(76));
        slp.setMargins(0, dp(5), 0, 0);
        shell.addView(spark, slp);
        parent.addView(shell, shellLp);
    }

    private LinearLayout trendReferenceRow(ArrayList<Double> values, ArrayList<String> labels, Metric m) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        Double min = null, max = null;
        for (Double v : values) {
            if (v == null || Double.isNaN(v)) continue;
            min = min == null ? v : Math.min(min, v);
            max = max == null ? v : Math.max(max, v);
        }
        String firstLabel = labels == null || labels.isEmpty() ? "Start" : safe(labels.get(0));
        String lastLabel = labels == null || labels.isEmpty() ? "Now" : safe(labels.get(labels.size() - 1));
        row.addView(trendRefText(firstLabel, Gravity.LEFT), new LinearLayout.LayoutParams(0, -2, 1));
        row.addView(trendRefText("Range " + format(min, m) + "–" + format(max, m), Gravity.CENTER), new LinearLayout.LayoutParams(0, -2, 2));
        row.addView(trendRefText(lastLabel, Gravity.RIGHT), new LinearLayout.LayoutParams(0, -2, 1));
        return row;
    }

    private TextView trendRefText(String s, int gravity) {
        TextView tv = text(s, 8, MUTED, false);
        tv.setGravity(gravity);
        tv.setSingleLine(true);
        return tv;
    }

    private Double lastNonNull(ArrayList<Double> values) {
        if (values == null) return null;
        for (int i = values.size() - 1; i >= 0; i--) {
            Double v = values.get(i);
            if (v != null && !Double.isNaN(v)) return v;
        }
        return null;
    }

    private Double avgNonNull(ArrayList<Double> values) {
        if (values == null) return null;
        double sum = 0;
        int n = 0;
        for (Double v : values) {
            if (v == null || Double.isNaN(v)) continue;
            sum += v;
            n++;
        }
        return n == 0 ? null : sum / n;
    }

    private LinearLayout statValueColumn(String title, String value, String detail, int color, boolean emphasized) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(dp(6), dp(6), dp(6), dp(6));
        int bg = Color.WHITE;
        int stroke = emphasized ? softColor(color, 0.58f) : Color.rgb(225, 233, 244);
        box.setBackground(roundedGradient(new int[] { bg, emphasized ? softColor(color, 0.96f) : Color.rgb(252, 253, 255) }, 15));

        TextView top = text(title.toUpperCase(Locale.US), 8, emphasized ? color : Color.rgb(108, 119, 137), true);
        top.setGravity(Gravity.CENTER);
        top.setLetterSpacing(0.08f);
        box.addView(top, matchWrap());

        TextView primary = text(value == null ? "—" : value, 16, INK, true);
        primary.setGravity(Gravity.CENTER);
        primary.setPadding(0, dp(2), 0, 0);
        primary.setFontFeatureSettings("'tnum' 1");  // v29: tabular figures for stat values
        box.addView(primary, matchWrap());
        return box;
    }

    private View percentileDuelView(String nameA, Double pctA, int colorA, String nameB, Double pctB, int colorB) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(7), 0, dp(1));
        row.addView(percentileTile(shortName(nameA), pctA, colorA), weightLp());
        TextView mid = text("percentile", 9, MUTED, true);
        mid.setGravity(Gravity.CENTER);
        row.addView(mid, new LinearLayout.LayoutParams(dp(68), -1));
        row.addView(percentileTile(shortName(nameB), pctB, colorB), weightLp());
        return row;
    }

    private View percentileTile(String label, Double pct, int color) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(8), dp(6), dp(8), dp(6));
        box.setBackground(roundedStroke(Color.rgb(250, 252, 255), softColor(color, 0.55f), 14, 1));
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView name = text(label, 10, color, true);
        top.addView(name, new LinearLayout.LayoutParams(0, -2, 1));
        TextView pctText = text(percentileBigLabel(pct), 16, INK, true);
        pctText.setGravity(Gravity.RIGHT);
        pctText.setFontFeatureSettings("'tnum' 1");  // v29: tabular figures for percentile
        top.addView(pctText);
        box.addView(top, matchWrap());
        PercentileMiniBarView mini = new PercentileMiniBarView(this, color, pct);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(8));
        lp.setMargins(0, dp(5), 0, 0);
        box.addView(mini, lp);
        return box;
    }

    private TextView tinyValue(String label, String value, int color) {
        TextView tv = text(label + " " + value, 10, color, true);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(dp(2), dp(1), dp(2), dp(1));
        return tv;
    }



    private int metricAccentColor(Metric m, Double delta) {
        if (delta == null || m.higherGood == null) return NAVY;
        boolean good = delta > 0;
        if (!m.higherGood) good = delta < 0;
        return good ? TEAL_DARK : SALMON;
    }

    private TextView compactValue(String label, String value, int color) {
        TextView tv = text(label + " " + value, 11, color, true);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(dp(3), dp(1), dp(3), dp(1));
        return tv;
    }

    private void renderPlayerStandings(ArrayList<LeaderboardEntry> entries, int season, Metric metric) {
        standingsBox.removeAllViews();
        LinearLayout card = verticalCard(22, null);
        card.setPadding(dp(14), dp(14), dp(14), dp(14));
        standingsBox.addView(card, matchWrap());
        card.addView(text("Player leaders · " + metric.label, 20, INK, true));
        addRankingScopeToggle(card, false);
        boolean luckMode = metric.key.equals("luck");
        TextView sub = text(season + " season · top " + Math.min(30, entries.size()), 12, MUTED, false);
        sub.setPadding(0, dp(3), 0, dp(8));
        card.addView(sub);

        lastStandingsText = season + " player standings by " + metric.label + "\nRank\tPlayer\tTeam\t" + metric.label + "\tPA\tBBE\n";
        int selectedRank = generalRankingsMode ? -1 : selectedPlayerRank(entries);
        if (selectedRank > 0) {
            card.addView(sectionLabel("Selected player rank"));
            addPlayerStandingRow(card, selectedRank, entries.get(selectedRank - 1), metric);
            card.addView(sectionLabel(luckMode ? "Overall leaderboard" : "Top rankings"));
        }
        if (luckMode && entries.size() > 20) {
            card.addView(sectionLabel("Luckiest"));
            int topLimit = Math.min(12, entries.size());
            for (int i = 0; i < topLimit; i++) addPlayerStandingRow(card, i + 1, entries.get(i), metric);
            card.addView(sectionLabel("Unluckiest"));
            for (int i = entries.size() - 1, rank = entries.size(); i >= Math.max(topLimit, entries.size() - 12); i--, rank--) addPlayerStandingRow(card, rank, entries.get(i), metric);
        } else {
            int limit = Math.min(30, entries.size());
            for (int i = 0; i < limit; i++) addPlayerStandingRow(card, i + 1, entries.get(i), metric);
        }
        resultsBox.setVisibility(View.GONE);
    }

    private void addPlayerStandingRow(LinearLayout card, int rank, LeaderboardEntry e, Metric metric) {
        boolean highlight = !generalRankingsMode && selectedPlayer != null && e.playerId == selectedPlayer.id;
        card.addView(standingRow(rank, e.name, e.teamAbbrOrName(), format(e.stats.get(metric.key), metric), e.stats, highlight, e.playerId, null));
        lastStandingsText += rank + "\t" + e.name + "\t" + e.teamAbbrOrName() + "\t" + format(e.stats.get(metric.key), metric) + "\t" + e.stats.pa + "\t" + e.stats.bbe + "\n";
    }

    private TextView sectionLabel(String value) {
        TextView tv = text(value, 12, TEAL_DARK, true);
        tv.setPadding(0, dp(10), 0, dp(3));
        return tv;
    }

    private void renderTeamStandings(ArrayList<TeamStanding> teams, int season, Metric metric) {
        standingsBox.removeAllViews();
        LinearLayout card = verticalCard(22, null);
        card.setPadding(dp(14), dp(14), dp(14), dp(14));
        standingsBox.addView(card, matchWrap());
        card.addView(text("Team leaders · " + metric.label, 20, INK, true));
        addRankingScopeToggle(card, true);
        boolean luckMode = metric.key.equals("luck");
        TextView sub = text(season + " season · all MLB teams", 12, MUTED, false);
        sub.setPadding(0, dp(3), 0, dp(8));
        card.addView(sub);

        lastStandingsText = season + " team standings by " + metric.label + "\nRank\tTeam\t" + metric.label + "\tPA\tBBE\n";
        int selectedRank = generalRankingsMode ? -1 : selectedTeamRank(teams);
        if (selectedRank > 0) {
            card.addView(sectionLabel("Selected team rank"));
            addTeamStandingRow(card, selectedRank, teams.get(selectedRank - 1), metric);
            card.addView(sectionLabel(luckMode ? "Overall leaderboard" : "League table"));
        }
        if (luckMode && teams.size() > 20) {
            card.addView(sectionLabel("Luckiest"));
            int topLimit = Math.min(10, teams.size());
            for (int i = 0; i < topLimit; i++) addTeamStandingRow(card, i + 1, teams.get(i), metric);
            card.addView(sectionLabel("Unluckiest"));
            for (int i = teams.size() - 1, rank = teams.size(); i >= Math.max(topLimit, teams.size() - 10); i--, rank--) addTeamStandingRow(card, rank, teams.get(i), metric);
        } else {
            for (int i = 0; i < teams.size(); i++) addTeamStandingRow(card, i + 1, teams.get(i), metric);
        }
        resultsBox.setVisibility(View.GONE);
    }

    private void addTeamStandingRow(LinearLayout card, int rank, TeamStanding t, Metric metric) {
        boolean highlight = !generalRankingsMode && selectedTeam != null && t.team.key().equals(selectedTeam.key());
        card.addView(standingRow(rank, t.team.name, t.team.abbr, format(t.stats.get(metric.key), metric), t.stats, highlight, 0, t.team));
        lastStandingsText += rank + "\t" + t.team.name + "\t" + format(t.stats.get(metric.key), metric) + "\t" + t.stats.pa + "\t" + t.stats.bbe + "\n";
    }

    private int selectedPlayerRank(ArrayList<LeaderboardEntry> entries) {
        if (selectedPlayer == null) return -1;
        for (int i = 0; i < entries.size(); i++) if (entries.get(i).playerId == selectedPlayer.id) return i + 1;
        return -1;
    }

    private int selectedTeamRank(ArrayList<TeamStanding> teams) {
        if (selectedTeam == null) return -1;
        for (int i = 0; i < teams.size(); i++) if (teams.get(i).team.key().equals(selectedTeam.key())) return i + 1;
        return -1;
    }

    private View standingRow(int rank, String name, String meta, String value, Stats stats, boolean highlight, int playerId, Team team) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(7), dp(7), dp(7), dp(7));
        row.setBackground(rounded(highlight ? Color.rgb(231, 251, 248) : Color.WHITE, 13));

        TextView rankTv = text(String.valueOf(rank), 13, highlight ? TEAL_DARK : MUTED, true);
        rankTv.setGravity(Gravity.CENTER);
        row.addView(rankTv, new LinearLayout.LayoutParams(dp(30), -2));

        if (playerId > 0) {
            ImageView avatar = new ImageView(this);
            avatar.setScaleType(ImageView.ScaleType.FIT_CENTER);
            avatar.setBackground(roundedStroke(Color.rgb(235, 241, 248), LINE, 18, 1));
            LinearLayout.LayoutParams aLp = new LinearLayout.LayoutParams(dp(36), dp(36));
            aLp.setMargins(0, 0, dp(8), 0);
            row.addView(avatar, aLp);
            loadPlayerImage(playerId, avatar);
        } else if (team != null) {
            View logo = teamLogoView(team, 36);
            LinearLayout.LayoutParams aLp = new LinearLayout.LayoutParams(dp(36), dp(36));
            aLp.setMargins(0, 0, dp(8), 0);
            row.addView(logo, aLp);
        }

        LinearLayout nameCol = new LinearLayout(this);
        nameCol.setOrientation(LinearLayout.VERTICAL);
        nameCol.addView(text(name, 13, INK, true));
        nameCol.addView(text(meta + " · " + statLineSummary(stats), 10, MUTED, false));
        row.addView(nameCol, new LinearLayout.LayoutParams(0, -2, 1));

        TextView val = text(value, 14, NAVY, true);
        val.setGravity(Gravity.RIGHT);
        row.addView(val);

        LinearLayout.LayoutParams lp = matchWrap();
        lp.setMargins(0, dp(3), 0, dp(3));
        if (playerId > 0 || team != null) {
            row.setForeground(ripple(false));
            row.setClickable(true);
            row.setOnClickListener(v -> {
                rankingsModeActive = false;
                if (team != null) {
                    teamMode = true;
                    selectedTeam = team;
                    setMode(true);
                } else {
                    Player p = findPlayerById(playerId);
                    if (p != null) {
                        teamMode = false;
                        selectedPlayer = p;
                        applySmartDefaultForSelection(p);
                        setMode(false);
                    }
                }
                renderSelectionPreview();
                openProfileForCurrentSelection();
            });
        }
        row.setLayoutParams(lp);
        return row;
    }

    private Player findPlayerById(int id) {
        for (Player p : allPlayers) if (p != null && p.id == id) return p;
        return null;
    }

    private Team findTeamByName(String name) {
        String q = safe(name).toLowerCase(Locale.US).trim();
        if (q.isEmpty()) return null;
        for (Team t : allTeams) {
            if (t == null) continue;
            if (safe(t.name).toLowerCase(Locale.US).equals(q) || safe(t.abbr).toLowerCase(Locale.US).equals(q) || t.key().toLowerCase(Locale.US).equals(q)) return t;
        }
        return null;
    }

    private void copyCurrentTable() {
        String text;
        if (resultsBox.getVisibility() == View.VISIBLE && lastHeadToHead != null) text = headToHeadText(lastHeadToHead);
        else if (resultsBox.getVisibility() == View.VISIBLE && lastComparison != null) text = comparisonText(lastComparison);
        else text = lastStandingsText;
        if (text == null || text.trim().isEmpty()) return;
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("Statcast table", text));
        Toast.makeText(this, "Copied table", Toast.LENGTH_SHORT).show();
    }

    private String comparisonText(Comparison c) {
        StringBuilder sb = new StringBuilder();
        sb.append(c.name).append(" · ").append(c.season).append(" Statcast comparison\n");
        sb.append("Metric\tSeason\tLeague Avg\t").append(c.thirdLabel).append("\tVs League\tVs ").append(c.thirdLabel).append("\n");
        for (Metric m : metrics) {
            if (!selectedMetricKeys.contains(m.key)) continue;
            Double season = c.seasonStats.get(m.key);
            Double league = c.leagueStats == null ? null : c.leagueStats.get(m.key);
            Double career = c.careerStats.get(m.key);
            sb.append(m.label).append('\t')
                    .append(format(season, m)).append('\t')
                    .append(format(league, m)).append('\t')
                    .append(format(career, m)).append('\t')
                    .append(signedFormat(diff(season, league), m)).append('\t')
                    .append(signedFormat(diff(season, career), m)).append('\n');
        }
        return sb.toString();
    }

    private String headToHeadText(HeadToHeadComparison h) {
        StringBuilder sb = new StringBuilder();
        sb.append(h.nameA).append(" vs ").append(h.nameB).append(" · ").append(h.season).append(" Statcast side-by-side\n");
        sb.append("Metric\t").append(h.nameA).append("\tMLB Avg\t").append(h.nameB).append("\tDiff A-B\n");
        for (Metric m : metrics) {
            if (!selectedMetricKeys.contains(m.key)) continue;
            Double a = h.statsA.get(m.key);
            Double league = h.leagueStats == null ? null : h.leagueStats.get(m.key);
            Double b = h.statsB.get(m.key);
            sb.append(m.label).append('\t')
                    .append(format(a, m)).append('\t')
                    .append(format(league, m)).append('\t')
                    .append(format(b, m)).append('\t')
                    .append(signedFormat(diff(a, b), m)).append('\n');
        }
        return sb.toString();
    }

    // Data loading -----------------------------------------------------------------------------

    private LoadedData fetchTeamsAndActivePlayers() throws Exception {
        String teamsText = httpGet("https://statsapi.mlb.com/api/v1/teams?sportId=1&activeStatus=Y");
        JSONArray teams = new JSONObject(teamsText).optJSONArray("teams");
        ArrayList<Team> teamList = new ArrayList<>();
        LinkedHashMap<Integer, Team> teamsById = new LinkedHashMap<>();
        if (teams == null) return new LoadedData(teamList, new ArrayList<>());

        for (int i = 0; i < teams.length(); i++) {
            JSONObject teamJson = teams.getJSONObject(i);
            int teamId = teamJson.optInt("id");
            String name = teamJson.optString("name", "MLB");
            String abbr = teamJson.optString("abbreviation", teamJson.optString("teamCode", name));
            Team t = new Team(teamId, name, abbr);
            teamList.add(t);
            teamsById.put(teamId, t);
        }
        teamList.sort((a, b) -> a.name.compareToIgnoreCase(b.name));

        ArrayList<Player> fastPlayers = fetchPlayersFromSingleEndpoint(teamsById);
        if (!fastPlayers.isEmpty()) return new LoadedData(teamList, fastPlayers);

        // Fallback: roster-by-team, but in parallel. The original version did this sequentially and felt very slow.
        LinkedHashMap<Integer, Player> playersById = new LinkedHashMap<>();
        ExecutorService rosterPool = Executors.newFixedThreadPool(8);
        ArrayList<Future<ArrayList<Player>>> futures = new ArrayList<>();
        for (Team t : teamList) {
            futures.add(rosterPool.submit(() -> fetchRosterForTeam(t)));
        }
        for (Future<ArrayList<Player>> f : futures) {
            try {
                for (Player p : f.get()) playersById.put(p.id, p);
            } catch (Exception ignored) {}
        }
        rosterPool.shutdown();
        ArrayList<Player> players = new ArrayList<>(playersById.values());
        players.sort((a, b) -> a.fullName.compareToIgnoreCase(b.fullName));
        return new LoadedData(teamList, players);
    }

    private ArrayList<Player> fetchPlayersFromSingleEndpoint(Map<Integer, Team> teamsById) {
        ArrayList<Player> players = new ArrayList<>();
        try {
            int season = Calendar.getInstance().get(Calendar.YEAR);
            String url = "https://statsapi.mlb.com/api/v1/sports/1/players?season=" + season + "&activeStatus=Y&hydrate=currentTeam,primaryPosition";
            String text = httpGet(url);
            JSONArray people = new JSONObject(text).optJSONArray("people");
            if (people == null) return players;
            for (int i = 0; i < people.length(); i++) {
                JSONObject person = people.getJSONObject(i);
                int id = person.optInt("id");
                String fullName = person.optString("fullName", "");
                JSONObject currentTeam = person.optJSONObject("currentTeam");
                int teamId = currentTeam == null ? 0 : currentTeam.optInt("id");
                Team team = teamsById.get(teamId);
                String teamName = team == null ? (currentTeam == null ? "" : currentTeam.optString("name", "")) : team.name;
                String teamAbbr = team == null ? (currentTeam == null ? "" : currentTeam.optString("abbreviation", "")) : team.abbr;
                JSONObject pos = person.optJSONObject("primaryPosition");
                String position = pos == null ? "" : pos.optString("abbreviation", pos.optString("name", ""));
                if (id > 0 && !fullName.isEmpty() && !teamName.isEmpty()) players.add(new Player(id, fullName, teamName, teamAbbr, position));
            }
            players.sort((a, b) -> a.fullName.compareToIgnoreCase(b.fullName));
        } catch (Exception ignored) {}
        return players;
    }

    private ArrayList<Player> fetchRosterForTeam(Team team) {
        ArrayList<Player> players = new ArrayList<>();
        try {
            String rosterText = httpGet("https://statsapi.mlb.com/api/v1/teams/" + team.id + "/roster/active?hydrate=person");
            JSONArray roster = new JSONObject(rosterText).optJSONArray("roster");
            if (roster == null) return players;
            for (int j = 0; j < roster.length(); j++) {
                JSONObject item = roster.getJSONObject(j);
                JSONObject person = item.optJSONObject("person");
                JSONObject pos = item.optJSONObject("position");
                if (person == null) continue;
                int id = person.optInt("id");
                String fullName = person.optString("fullName", "");
                String position = pos == null ? "" : pos.optString("abbreviation", pos.optString("name", ""));
                if (id > 0 && !fullName.isEmpty()) players.add(new Player(id, fullName, team.name, team.abbr, position));
            }
        } catch (Exception ignored) {}
        return players;
    }

    private ArrayList<LeaderboardEntry> fetchLeaderboardForMetric(int season, Metric metric) throws Exception {
        return "pitch".equals(metric.side) ? fetchPitchingLeaderboard(season) : fetchLeaderboard(season);
    }

    private ArrayList<LeaderboardEntry> fetchLeaderboardForPlayer(Player p, int season) throws Exception {
        return isPitcher(p) ? fetchPitchingLeaderboard(season) : fetchLeaderboard(season);
    }

    private ArrayList<LeaderboardEntry> fetchLeaderboardForSelectedMetrics(int season) throws Exception {
        int pitch = 0, hit = 0;
        for (Metric m : metrics) if (selectedMetricKeys.contains(m.key)) { if ("pitch".equals(m.side)) pitch++; else if ("hit".equals(m.side)) hit++; }
        return pitch > hit ? fetchPitchingLeaderboard(season) : fetchLeaderboard(season);
    }

    private ArrayList<LeaderboardEntry> fetchLeaderboard(int season) throws Exception {
        ArrayList<LeaderboardEntry> cached = leaderboardCache.get(season);
        if (cached != null) return cached;
        String csv = httpGet(customLeaderboardUrl(season));
        List<Map<String, String>> rows = parseCsv(csv);
        if (rows.isEmpty()) throw new Exception("No Baseball Savant leaderboard rows returned for " + season + ".");
        ArrayList<LeaderboardEntry> entries = new ArrayList<>();
        for (Map<String, String> row : rows) {
            int id = intVal(pick(row, "player_id", "playerid", "player id", "batter", "entity_id"));
            String name = pickString(row, "player_name", "player name", "last_name, first_name", "name", "last_name first_name");
            if (name.isEmpty()) name = buildNameFromColumns(row);
            name = normalizePlayerName(name);
            String teamName = pickString(row, "team_name", "team name", "team", "team_name_alt");
            String teamAbbr = pickString(row, "team_abbrev", "team abbr", "team_abbreviation", "team_short", "team");
            if (id > 0) {
                Player p = playerById(id);
                if (p != null) {
                    if (teamName.isEmpty()) teamName = p.teamName;
                    if (teamAbbr.isEmpty()) teamAbbr = p.teamAbbr;
                    if (name.isEmpty()) name = p.fullName;
                }
            }
            Stats stats = statsFromLeaderboardRow(row);
            if ((!name.isEmpty() || id > 0) && (stats.pa > 0 || stats.bbe > 0 || stats.anyValue())) {
                entries.add(new LeaderboardEntry(id, name, teamName, teamAbbr, stats));
            }
        }
        mergeStandardStatsIntoEntries(entries, fetchStandardLeaderboard(season, false));
        leaderboardCache.put(season, entries);
        return entries;
    }

    private ArrayList<LeaderboardEntry> fetchPitchingLeaderboard(int season) throws Exception {
        ArrayList<LeaderboardEntry> cached = pitchingLeaderboardCache.get(season);
        if (cached != null) return cached;
        ArrayList<LeaderboardEntry> entries = fetchStandardLeaderboard(season, true);
        if (entries.isEmpty()) throw new Exception("No pitching rows returned for " + season + ".");
        pitchingLeaderboardCache.put(season, entries);
        return entries;
    }

    private String customLeaderboardUrl(int season) throws Exception {
        LinkedHashMap<String, String> params = new LinkedHashMap<>();
        params.put("year", String.valueOf(season));
        params.put("type", "batter");
        params.put("filter", "");
        params.put("min", "1");
        params.put("selections", "pa,xba,xslg,woba,xwoba,exit_velocity_avg,launch_angle_avg,sweet_spot_percent,barrel_batted_rate,hard_hit_percent,k_percent,bb_percent");
        params.put("sort", "xwoba");
        params.put("sortDir", "desc");
        params.put("csv", "true");
        return "https://baseballsavant.mlb.com/leaderboard/custom" + toQuery(params);
    }

    private Stats statsFromLeaderboardRow(Map<String, String> row) {
        Stats s = new Stats();
        s.pa = intVal(pick(row, "pa", "PA"));
        s.bbe = intVal(pick(row, "batted_ball", "batted_balls", "batted balls", "bbe", "Batted Balls", "batted_ball_events"));
        if (s.bbe <= 0) s.bbe = intVal(pick(row, "bip", "balls in play"));
        if (s.bbe <= 0 && s.pa > 0) s.bbe = Math.max(1, (int) Math.round(s.pa * 0.68));
        s.put("wOBA", pick(row, "woba", "wOBA"));
        s.put("xBA", pick(row, "xba", "xBA"));
        s.put("xSLG", pick(row, "xslg", "xSLG"));
        s.put("xwOBA", pick(row, "xwoba", "xwOBA"));
        s.put("avgEV", pick(row, "exit_velocity_avg", "Avg EV (MPH)", "avg_ev", "avg exit velocity"));
        s.put("avgLA", pick(row, "launch_angle_avg", "Avg LA (°)", "avg_la", "avg launch angle"));
        s.put("hardHitPct", pick(row, "hard_hit_percent", "Hard Hit %", "hardhit_percent"));
        s.put("barrelPct", pick(row, "barrel_batted_rate", "Barrel%", "barrel_percent", "barrel_batted_rate"));
        s.put("sweetSpotPct", pick(row, "sweet_spot_percent", "LA Sweet-Spot %", "sweet spot %"));
        s.put("kPct", pick(row, "k_percent", "K%", "strikeout_percent", "k %"));
        s.put("bbPct", pick(row, "bb_percent", "BB%", "walk_percent", "bb %"));
        return s;
    }

    private ArrayList<LeaderboardEntry> fetchStandardLeaderboard(int season, boolean pitching) {
        ArrayList<LeaderboardEntry> out = new ArrayList<>();
        try {
            String group = pitching ? "pitching" : "hitting";
            String url = "https://statsapi.mlb.com/api/v1/stats?stats=season&group=" + group + "&playerPool=ALL&season=" + season + "&limit=10000";
            String text = httpGet(url);
            JSONArray statsArr = new JSONObject(text).optJSONArray("stats");
            if (statsArr == null || statsArr.length() == 0) return out;
            JSONArray splits = statsArr.getJSONObject(0).optJSONArray("splits");
            if (splits == null) return out;
            for (int i = 0; i < splits.length(); i++) {
                JSONObject split = splits.getJSONObject(i);
                JSONObject player = split.optJSONObject("player");
                JSONObject team = split.optJSONObject("team");
                JSONObject stat = split.optJSONObject("stat");
                if (player == null || stat == null) continue;
                int id = player.optInt("id");
                String name = player.optString("fullName", "");
                String teamName = team == null ? "" : team.optString("name", "");
                String teamAbbr = team == null ? "" : team.optString("abbreviation", team.optString("teamCode", ""));
                Player known = playerById(id);
                if (known != null) {
                    if (name.isEmpty()) name = known.fullName;
                    if (teamName.isEmpty()) teamName = known.teamName;
                    if (teamAbbr.isEmpty()) teamAbbr = known.teamAbbr;
                }
                Stats s = pitching ? statsFromPitchingJson(stat) : statsFromHittingJson(stat);
                if (id > 0 && !name.isEmpty() && (s.pa > 0 || s.bbe > 0 || s.ip > 0 || s.anyValue())) out.add(new LeaderboardEntry(id, name, teamName, teamAbbr, s));
            }
        } catch (Exception ignored) {}
        return out;
    }

    private Stats statsFromHittingJson(JSONObject stat) {
        Stats s = new Stats();
        int ab = intFromJson(stat, "atBats");
        int hits = intFromJson(stat, "hits");
        int doubles = intFromJson(stat, "doubles");
        int triples = intFromJson(stat, "triples");
        int hr = intFromJson(stat, "homeRuns");
        int bb = intFromJson(stat, "baseOnBalls");
        int hbp = intFromJson(stat, "hitByPitch");
        int sf = intFromJson(stat, "sacFlies");
        int so = intFromJson(stat, "strikeOuts");
        int tb = intFromJson(stat, "totalBases");
        if (tb <= 0 && (hits > 0 || hr > 0 || doubles > 0 || triples > 0)) {
            int singles = Math.max(0, hits - doubles - triples - hr);
            tb = singles + 2 * doubles + 3 * triples + 4 * hr;
        }
        int pa = intFromJson(stat, "plateAppearances");
        if (pa <= 0) pa = ab + bb + hbp + sf + intFromJson(stat, "sacBunts");
        s.pa = pa;
        s.bbe = Math.max(1, ab - so + sf);

        // Keep raw game-log inputs so rolling windows are calculated from ONLY that window,
        // not by averaging season-to-date rate fields returned by MLB's API.
        s.put("__ab", (double) ab);
        s.put("__h", (double) hits);
        s.put("__tb", (double) tb);
        s.put("__bb", (double) bb);
        s.put("__hbp", (double) hbp);
        s.put("__sf", (double) sf);
        s.put("__so", (double) so);

        Double avg = ab > 0 ? hits / (double) ab : num(stat.optString("avg", ""));
        Double obp = (ab + bb + hbp + sf) > 0 ? (hits + bb + hbp) / (double) (ab + bb + hbp + sf) : num(stat.optString("obp", ""));
        Double slg = ab > 0 ? tb / (double) ab : num(stat.optString("slg", ""));
        Double ops = obp != null && slg != null ? obp + slg : num(stat.optString("ops", ""));

        s.put("avg", avg);
        s.put("obp", obp);
        s.put("slg", slg);
        s.put("ops", ops);
        s.put("hr", (double) hr);
        s.put("rbi", (double) intFromJson(stat, "rbi"));
        s.put("r", (double) intFromJson(stat, "runs"));
        s.put("sb", (double) intFromJson(stat, "stolenBases"));
        if (pa > 0) {
            s.put("kPct", so * 100.0 / pa);
            s.put("bbPct", bb * 100.0 / pa);
        }
        return s;
    }

    private Stats statsFromPitchingJson(JSONObject stat) {
        Stats s = new Stats();
        double ip = inningsToDouble(stat.optString("inningsPitched", "0"));
        int bf = intFromJson(stat, "battersFaced");
        int k = intFromJson(stat, "strikeOuts");
        int bb = intFromJson(stat, "baseOnBalls");
        int hits = intFromJson(stat, "hits");
        int er = intFromJson(stat, "earnedRuns");
        int saves = intFromJson(stat, "saves");

        s.ip = ip;
        s.pa = bf;
        s.bbe = (int) Math.round(ip * 3.0);

        // Raw inputs for true rolling pitching rates over the selected window.
        s.put("__pip", ip);
        s.put("__bf", (double) bf);
        s.put("__pk", (double) k);
        s.put("__pbb", (double) bb);
        s.put("__ph", (double) hits);
        s.put("__er", (double) er);

        s.put("era", ip > 0 ? er * 9.0 / ip : num(stat.optString("era", "")));
        s.put("whip", ip > 0 ? (hits + bb) / ip : num(stat.optString("whip", "")));
        s.put("k9", ip > 0 ? k * 9.0 / ip : num(stat.optString("strikeoutsPer9Inn", "")));
        s.put("bb9", ip > 0 ? bb * 9.0 / ip : num(stat.optString("walksPer9Inn", "")));
        s.put("kbb", bb > 0 ? k / (double) bb : (k > 0 ? (double) k : num(stat.optString("strikeoutWalkRatio", ""))));
        s.put("pitchK", (double) k);
        s.put("pitchBB", (double) bb);
        s.put("saves", (double) saves);
        s.put("ip", ip);
        return s;
    }

    private int intFromJson(JSONObject obj, String key) {
        try { return Integer.parseInt(obj.optString(key, "0").replace(",", "")); } catch (Exception e) { return obj.optInt(key, 0); }
    }

    private double inningsToDouble(String ipText) {
        try {
            String[] parts = safe(ipText).split("\\.");
            double whole = parts.length > 0 && !parts[0].isEmpty() ? Double.parseDouble(parts[0]) : 0;
            double outs = parts.length > 1 && !parts[1].isEmpty() ? Double.parseDouble(parts[1]) : 0;
            return whole + outs / 3.0;
        } catch (Exception e) { return 0; }
    }

    private void mergeStandardStatsIntoEntries(ArrayList<LeaderboardEntry> entries, ArrayList<LeaderboardEntry> standard) {
        LinkedHashMap<Integer, LeaderboardEntry> byId = new LinkedHashMap<>();
        for (LeaderboardEntry e : entries) if (e.playerId > 0) byId.put(e.playerId, e);
        for (LeaderboardEntry std : standard) {
            LeaderboardEntry existing = byId.get(std.playerId);
            if (existing != null) existing.stats.mergeFrom(std.stats);
            else {
                entries.add(std);
                if (std.playerId > 0) byId.put(std.playerId, std);
            }
        }
    }

    private Stats computeLeagueAverage(ArrayList<LeaderboardEntry> entries) {
        WeightedStatsBuilder b = new WeightedStatsBuilder(metrics);
        for (LeaderboardEntry e : entries) b.add(e.stats);
        return b.build();
    }

    private LinkedHashMap<Integer, Stats> fetchPlayerRecentSeasonStats(Player player, int throughSeason) {
        LinkedHashMap<Integer, Stats> out = new LinkedHashMap<>();
        int first = Math.max(STATCAST_START_YEAR, throughSeason - 3);
        for (int y = throughSeason; y >= first; y--) {
            try {
                LeaderboardEntry e = findPlayerEntry(fetchLeaderboardForPlayer(player, y), player);
                if (e != null && e.stats != null && e.stats.anyValue()) out.put(y, e.stats);
            } catch (Exception ignored) {}
        }
        return out;
    }

    private LinkedHashMap<Integer, Stats> fetchTeamRecentSeasonStats(Team team, int throughSeason) {
        LinkedHashMap<Integer, Stats> out = new LinkedHashMap<>();
        int first = Math.max(STATCAST_START_YEAR, throughSeason - 3);
        for (int y = throughSeason; y >= first; y--) {
            try {
                Stats s = aggregateTeamStats(fetchLeaderboardForSelectedMetrics(y)).get(team.key());
                if (s != null && s.anyValue()) out.put(y, s);
            } catch (Exception ignored) {}
        }
        return out;
    }

    private Stats fetchPlayerCareerStats(Player player, int throughSeason) {
        WeightedStatsBuilder b = new WeightedStatsBuilder(metrics, true);
        ExecutorService pool = Executors.newFixedThreadPool(6);
        ArrayList<Future<Stats>> futures = new ArrayList<>();
        for (int y = STATCAST_START_YEAR; y <= throughSeason; y++) {
            final int year = y;
            futures.add(pool.submit(() -> {
                try {
                    LeaderboardEntry e = findPlayerEntry(fetchLeaderboardForPlayer(player, year), player);
                    return e == null ? null : e.stats;
                } catch (Exception ignored) { return null; }
            }));
        }
        for (Future<Stats> f : futures) {
            try { b.add(f.get()); } catch (Exception ignored) {}
        }
        pool.shutdown();
        return b.build();
    }

    private Stats fetchTeamHistoryStats(Team team, int throughSeason) {
        WeightedStatsBuilder b = new WeightedStatsBuilder(metrics, true);
        ExecutorService pool = Executors.newFixedThreadPool(6);
        ArrayList<Future<Stats>> futures = new ArrayList<>();
        for (int y = STATCAST_START_YEAR; y <= throughSeason; y++) {
            final int year = y;
            futures.add(pool.submit(() -> {
                try { return aggregateTeamStats(fetchLeaderboardForSelectedMetrics(year)).get(team.key()); }
                catch (Exception ignored) { return null; }
            }));
        }
        for (Future<Stats> f : futures) {
            try { b.add(f.get()); } catch (Exception ignored) {}
        }
        pool.shutdown();
        return b.build();
    }

    private LinkedHashMap<String, Stats> fetchPlayerRecentWindows(Player player, int season) {
        LinkedHashMap<String, Stats> out = new LinkedHashMap<>();
        ArrayList<GameLogEntry> logs = fetchPlayerGameLogs(player, season);
        if (logs.isEmpty()) return out;
        Date latest = logs.get(logs.size() - 1).date;
        addRecentWindow(out, logs, latest, 7, "Last 7d");
        addRecentWindow(out, logs, latest, 15, "Last 15d");
        addRecentWindow(out, logs, latest, 30, "Last 30d");
        return out;
    }

    private void addRecentWindow(LinkedHashMap<String, Stats> out, ArrayList<GameLogEntry> logs, Date latest, int days, String label) {
        if (latest == null) return;
        long cutoff = latest.getTime() - (long) Math.max(0, days - 1) * 24L * 60L * 60L * 1000L;
        WeightedStatsBuilder b = new WeightedStatsBuilder(metrics, true);
        int games = 0;
        for (GameLogEntry g : logs) {
            if (g.date != null && g.date.getTime() >= cutoff) { b.add(g.stats); games++; }
        }
        if (games > 0) out.put(label, b.build());
    }

    private Map<String, ArrayList<TrendPoint>> fetchTeamSeasonTrendMap(Team team, int season) {
        LinkedHashMap<String, ArrayList<TrendPoint>> out = new LinkedHashMap<>();
        ArrayList<GameLogEntry> logs = dailyGameLogs(fetchTeamGameLogs(team, season));
        if (logs.size() < 2) return out;
        addSeasonTrend(out, logs);
        addWindowTrend(out, logs, 7);
        addWindowTrend(out, logs, 15);
        addWindowTrend(out, logs, 30);
        return out;
    }

    private ArrayList<GameLogEntry> fetchTeamGameLogs(Team team, int season) {
        String cacheKey = "team:" + (team == null ? 0 : team.id) + ":" + season;
        ArrayList<GameLogEntry> cached = gameLogCache.get(cacheKey);
        if (cached != null) return cached;
        ArrayList<GameLogEntry> out = new ArrayList<>();
        if (team == null || team.id <= 0) return out;
        fetchTeamGameLogsForGroup(team, season, "hitting", out);
        fetchTeamGameLogsForGroup(team, season, "pitching", out);
        out.sort((a, b) -> a.date.compareTo(b.date));
        gameLogCache.put(cacheKey, out);
        return out;
    }

    private void fetchTeamGameLogsForGroup(Team team, int season, String group, ArrayList<GameLogEntry> out) {
        try {
            String url = "https://statsapi.mlb.com/api/v1/teams/" + team.id + "/stats?stats=gameLog&group=" + group + "&season=" + season;
            String text = httpGet(url);
            JSONArray statsArr = new JSONObject(text).optJSONArray("stats");
            if (statsArr != null && statsArr.length() > 0) {
                JSONArray splits = statsArr.getJSONObject(0).optJSONArray("splits");
                if (splits != null) {
                    for (int i = 0; i < splits.length(); i++) {
                        JSONObject split = splits.getJSONObject(i);
                        JSONObject stat = split.optJSONObject("stat");
                        if (stat == null) continue;
                        Date date = parseMlbDate(split.optString("date", ""));
                        Stats s = "pitching".equals(group) ? statsFromPitchingJson(stat) : statsFromHittingJson(stat);
                        if (date != null && s != null && (s.anyValue() || s.pa > 0 || s.ip > 0)) out.add(new GameLogEntry(date, shortDate(date), s));
                    }
                }
            }
        } catch (Exception ignored) {}
    }

    private Map<String, ArrayList<TrendPoint>> fetchPlayerSeasonTrendMap(Player player, int season) {
        LinkedHashMap<String, ArrayList<TrendPoint>> out = new LinkedHashMap<>();
        ArrayList<GameLogEntry> logs = dailyGameLogs(fetchPlayerGameLogs(player, season));
        if (logs.size() < 2) return out;
        addSeasonTrend(out, logs);
        addWindowTrend(out, logs, 7);
        addWindowTrend(out, logs, 15);
        addWindowTrend(out, logs, 30);
        return out;
    }

    private ArrayList<GameLogEntry> dailyGameLogs(ArrayList<GameLogEntry> logs) {
        ArrayList<GameLogEntry> out = new ArrayList<>();
        if (logs == null || logs.isEmpty()) return out;
        LinkedHashMap<String, WeightedStatsBuilder> byDay = new LinkedHashMap<>();
        LinkedHashMap<String, Date> dates = new LinkedHashMap<>();
        SimpleDateFormat keyFmt = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        ArrayList<GameLogEntry> sorted = new ArrayList<>(logs);
        sorted.sort((a, b) -> a.date.compareTo(b.date));
        for (GameLogEntry g : sorted) {
            if (g == null || g.date == null || g.stats == null) continue;
            String key = keyFmt.format(g.date);
            WeightedStatsBuilder b = byDay.get(key);
            if (b == null) { b = new WeightedStatsBuilder(metrics, true); byDay.put(key, b); dates.put(key, g.date); }
            b.add(g.stats);
        }
        for (String key : byDay.keySet()) out.add(new GameLogEntry(dates.get(key), shortDate(dates.get(key)), byDay.get(key).build()));
        return out;
    }

    private void addSeasonTrend(Map<String, ArrayList<TrendPoint>> out, ArrayList<GameLogEntry> logs) {
        WeightedStatsBuilder cumulative = new WeightedStatsBuilder(metrics, true);
        int target = Math.min(14, Math.max(5, logs.size()));
        int step = Math.max(1, (int) Math.ceil(logs.size() / (double) target));
        for (int i = 0; i < logs.size(); i++) {
            GameLogEntry g = logs.get(i);
            cumulative.add(g.stats);
            boolean checkpoint = i == logs.size() - 1 || i == 0 || ((i + 1) % step == 0);
            if (checkpoint) addTrendSnapshot(out, "", shortDate(g.date), cumulative.build());
        }
    }

    private void addWindowTrend(Map<String, ArrayList<TrendPoint>> out, ArrayList<GameLogEntry> logs, int days) {
        if (logs == null || logs.size() < 2) return;
        Date latest = logs.get(logs.size() - 1).date;
        if (latest == null) return;
        long oneDay = 24L * 60L * 60L * 1000L;
        long start = latest.getTime() - (long) Math.max(0, days - 1) * oneDay;
        WeightedStatsBuilder running = new WeightedStatsBuilder(metrics, true);
        int points = 0;
        for (GameLogEntry g : logs) {
            if (g == null || g.date == null || g.stats == null) continue;
            long t = g.date.getTime();
            if (t < start || t > latest.getTime()) continue;
            running.add(g.stats);
            addTrendSnapshot(out, "__" + days + "d", shortDate(g.date), running.build());
            points++;
        }
        // If there was only one game in the window, the line is intentionally hidden.
        // The value cards/recent-form strip still show the final window total/rate.
    }

    private void addTrendSnapshot(Map<String, ArrayList<TrendPoint>> out, String suffix, String label, Stats snapshot) {
        if (snapshot == null) return;
        for (Metric m : metrics) {
            Double v = snapshot.get(m.key);
            if (v == null || Double.isNaN(v)) continue;
            String key = m.key + (suffix == null ? "" : suffix);
            ArrayList<TrendPoint> pts = out.get(key);
            if (pts == null) { pts = new ArrayList<>(); out.put(key, pts); }
            pts.add(new TrendPoint(label, v));
        }
    }

    private Stats statsForWindowEnding(ArrayList<GameLogEntry> logs, Date end, int days) {
        if (logs == null || logs.isEmpty() || end == null) return null;
        ArrayList<GameLogEntry> daily = dailyGameLogs(logs);
        long cutoff = end.getTime() - (long) Math.max(0, days - 1) * 24L * 60L * 60L * 1000L;
        WeightedStatsBuilder b = new WeightedStatsBuilder(metrics, true);
        int games = 0;
        for (GameLogEntry g : daily) {
            if (g == null || g.date == null) continue;
            long t = g.date.getTime();
            if (t <= end.getTime() && t >= cutoff) { b.add(g.stats); games++; }
        }
        return games == 0 ? null : b.build();
    }

    private ArrayList<GameLogEntry> fetchPlayerGameLogs(Player player, int season) {
        ArrayList<GameLogEntry> cached = gameLogCache.get(player.id + ":" + season + ":" + (isPitcher(player) ? "pitch" : "hit"));
        if (cached != null) return cached;
        ArrayList<GameLogEntry> out = new ArrayList<>();
        try {
            boolean pitching = isPitcher(player);
            String group = pitching ? "pitching" : "hitting";
            String url = "https://statsapi.mlb.com/api/v1/people/" + player.id + "/stats?stats=gameLog&group=" + group + "&season=" + season;
            String text = httpGet(url);
            JSONArray statsArr = new JSONObject(text).optJSONArray("stats");
            if (statsArr != null && statsArr.length() > 0) {
                JSONArray splits = statsArr.getJSONObject(0).optJSONArray("splits");
                if (splits != null) {
                    for (int i = 0; i < splits.length(); i++) {
                        JSONObject split = splits.getJSONObject(i);
                        JSONObject stat = split.optJSONObject("stat");
                        if (stat == null) continue;
                        Date date = parseMlbDate(split.optString("date", ""));
                        Stats s = pitching ? statsFromPitchingJson(stat) : statsFromHittingJson(stat);
                        if (date != null && s != null && (s.anyValue() || s.pa > 0 || s.ip > 0)) out.add(new GameLogEntry(date, shortDate(date), s));
                    }
                }
            }
        } catch (Exception ignored) {}
        out.sort((a, b) -> a.date.compareTo(b.date));
        gameLogCache.put(player.id + ":" + season + ":" + (isPitcher(player) ? "pitch" : "hit"), out);
        return out;
    }

    private Date parseMlbDate(String value) {
        try { return new SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(value); } catch (Exception e) { return null; }
    }

    private String shortDate(Date d) {
        if (d == null) return "";
        try { return new SimpleDateFormat("M/d", Locale.US).format(d); } catch (Exception e) { return ""; }
    }

    private Map<String, Stats> aggregateTeamStats(ArrayList<LeaderboardEntry> entries) {
        LinkedHashMap<String, WeightedStatsBuilder> builders = new LinkedHashMap<>();
        for (LeaderboardEntry e : entries) {
            String key = teamKeyFromEntry(e);
            if (key.isEmpty()) continue;
            WeightedStatsBuilder b = builders.get(key);
            if (b == null) {
                b = new WeightedStatsBuilder(metrics, true);
                builders.put(key, b);
            }
            b.add(e.stats);
        }
        LinkedHashMap<String, Stats> out = new LinkedHashMap<>();
        for (Map.Entry<String, WeightedStatsBuilder> e : builders.entrySet()) out.put(e.getKey(), e.getValue().build());
        return out;
    }

    private LeaderboardEntry findPlayerEntry(ArrayList<LeaderboardEntry> entries, Player player) {
        for (LeaderboardEntry e : entries) if (e.playerId > 0 && e.playerId == player.id) return e;
        String target = normalizeNameKey(player.fullName);
        for (LeaderboardEntry e : entries) if (normalizeNameKey(e.name).equals(target)) return e;
        return null;
    }

    private Player playerById(int id) {
        for (Player p : allPlayers) if (p.id == id) return p;
        return null;
    }

    private String teamKeyFromEntry(LeaderboardEntry e) {
        String abbr = safe(e.teamAbbr).toUpperCase(Locale.US).trim();
        if (!abbr.isEmpty()) {
            for (Team t : allTeams) if (abbr.equals(t.abbr.toUpperCase(Locale.US))) return t.key();
        }
        String name = normalizeNameKey(e.teamName);
        if (!name.isEmpty()) {
            for (Team t : allTeams) if (normalizeNameKey(t.name).equals(name)) return t.key();
        }
        return abbr;
    }

    private void sortEntries(ArrayList<LeaderboardEntry> entries, Metric metric) {
        entries.sort((a, b) -> compareMetricValues(a.stats.get(metric.key), b.stats.get(metric.key), metric));
    }

    private int compareMetricValues(Double av, Double bv, Metric metric) {
        if (av == null && bv == null) return 0;
        if (av == null) return 1;
        if (bv == null) return -1;
        int cmp = Double.compare(bv, av); // default: high to low
        if (metric.higherGood != null && !metric.higherGood) cmp = Double.compare(av, bv);
        return cmp;
    }

    private View teamLogoView(Team team, int sizeDp) {
        TeamPalette palette = paletteForTeam(team);
        FrameLayout frame = new FrameLayout(this);
        frame.setPadding(dp(4), dp(4), dp(4), dp(4));
        frame.setBackground(roundedGradient(new int[] { softColor(palette.primary, 0.35f), softColor(palette.secondary, 0.55f) }, Math.max(14, sizeDp / 2)));

        ImageView logo = new ImageView(this);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        logo.setAdjustViewBounds(true);
        logo.setPadding(dp(2), dp(2), dp(2), dp(2));
        frame.addView(logo, new FrameLayout.LayoutParams(-1, -1));
        loadTeamLogo(team, logo);
        return frame;
    }

    private TextView teamBadge(String abbr, int sizeDp, int sp, TeamPalette palette) {
        // Kept only for older fallback references. Team logo surfaces now use a logo/shape without text.
        TextView badge = text("", sp, Color.WHITE, true);
        badge.setGravity(Gravity.CENTER);
        badge.setBackground(roundedGradient(new int[] { palette.primary, palette.secondary }, Math.max(12, sizeDp / 2)));
        return badge;
    }

    private void loadPlayerImage(int playerId, ImageView imageView) {
        if (playerId <= 0) return;
        imageView.setImageDrawable(rounded(Color.rgb(235, 241, 248), 24));
        imageView.setContentDescription("Player headshot");
        loadPlayerImageBitmap(playerId, bitmap -> {
            imageView.setImageBitmap(bitmap);
            imageView.setContentDescription("Player headshot");
        });
    }

    private void loadTeamLogo(Team team, ImageView imageView) {
        if (team == null || team.id <= 0) return;
        loadTeamLogoBitmap(team, bitmap -> imageView.setImageBitmap(bitmap));
    }

    private void loadPlayerImageBitmap(int playerId, BitmapCallback callback) {
        if (playerId <= 0 || callback == null) return;
        String[] urls = new String[] {
                // v40: try larger spot/headshot assets first so the share card portraits do not get enlarged from 120px sources.
                "https://midfield.mlbstatic.com/v1/people/" + playerId + "/spots/720",
                "https://midfield.mlbstatic.com/v1/people/" + playerId + "/spots/360",
                "https://img.mlbstatic.com/mlb-photos/image/upload/w_720,q_auto:best/v1/people/" + playerId + "/headshot/current",
                "https://img.mlbstatic.com/mlb-photos/image/upload/w_360,q_auto:best/v1/people/" + playerId + "/headshot/current",
                "https://img.mlbstatic.com/mlb-photos/image/upload/w_240,d_people:generic:headshot:silo:current.png,q_auto:best/v1/people/" + playerId + "/headshot/67/current"
        };
        loadBitmapFromUrls(urls, callback);
    }

    private void loadTeamLogoBitmap(Team team, BitmapCallback callback) {
        if (team == null || callback == null) return;
        String code = espnTeamCode(team);
        ArrayList<String> urls = new ArrayList<>();
        if (!code.isEmpty()) {
            urls.add("https://a.espncdn.com/i/teamlogos/mlb/500/" + code + ".png");
            urls.add("https://a.espncdn.com/i/teamlogos/mlb/500-dark/" + code + ".png");
            urls.add("https://a.espncdn.com/i/teamlogos/mlb/500-light/" + code + ".png");
        }
        // If ESPN changes a code, the UI falls back to a team-colored shape without text instead of showing duplicate lettering.
        loadBitmapFromUrls(urls.toArray(new String[0]), callback);
    }

    private void loadBitmapFromUrls(String[] urls, BitmapCallback callback) {
        if (urls == null || urls.length == 0 || callback == null) return;
        for (String url : urls) {
            Bitmap cached = imageCache.get(url);
            if (cached != null) { callback.onBitmap(cached); return; }
        }
        String primary = urls[0];
        // Check disk cache
        File imgDir = new File(getCacheDir(), "img");
        imgDir.mkdirs();
        String diskKey = "img_" + Integer.toHexString(primary.hashCode()) + ".webp";
        File diskFile = new File(imgDir, diskKey);
        if (diskFile.exists()) {
            io.execute(() -> {
                Bitmap b = BitmapFactory.decodeFile(diskFile.getAbsolutePath());
                if (b != null) {
                    imageCache.put(primary, b);
                    main.post(() -> callback.onBitmap(b));
                    return;
                }
                fetchAndCacheBitmap(urls, primary, diskFile, callback);
            });
            return;
        }
        synchronized (imageWaiters) {
            ArrayList<BitmapCallback> waiters = imageWaiters.get(primary);
            if (waiters != null) { waiters.add(callback); return; }
            waiters = new ArrayList<>();
            waiters.add(callback);
            imageWaiters.put(primary, waiters);
        }
        io.execute(() -> fetchAndCacheBitmap(urls, primary, diskFile, null));
    }

    private void fetchAndCacheBitmap(String[] urls, String primary, File diskFile, BitmapCallback directCallback) {
        Bitmap bitmap = null;
        for (String url : urls) {
            if (url == null || url.isEmpty()) continue;
            try {
                HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
                conn.setConnectTimeout(7000);
                conn.setReadTimeout(12000);
                conn.setRequestProperty("User-Agent", "Mozilla/5.0 Statcast Compare Android");
                Bitmap b = BitmapFactory.decodeStream(conn.getInputStream());
                if (b != null) {
                    bitmap = b;
                    imageCache.put(url, b);
                    try (FileOutputStream fos = new FileOutputStream(diskFile)) {
                        b.compress(Bitmap.CompressFormat.WEBP, 85, fos);
                    } catch (Exception ignored) {}
                    break;
                }
            } catch (Exception ignored) {}
        }
        Bitmap finalBitmap = bitmap;
        if (directCallback != null) {
            if (finalBitmap != null) main.post(() -> directCallback.onBitmap(finalBitmap));
            return;
        }
        ArrayList<BitmapCallback> callbacks;
        synchronized (imageWaiters) { callbacks = imageWaiters.remove(primary); }
        if (finalBitmap != null && callbacks != null) {
            main.post(() -> { for (BitmapCallback cb : callbacks) cb.onBitmap(finalBitmap); });
        }
    }

    private String espnTeamCode(Team team) {
        String abbr = team == null ? "" : safe(team.abbr).toUpperCase(Locale.US).replaceAll("[^A-Z]", "");
        String teamName = team == null ? "" : safe(team.name).toLowerCase(Locale.US);
        if (abbr.equals("ARI") || abbr.equals("AZ") || teamName.contains("diamondback")) return "ari";
        if (abbr.equals("ATL")) return "atl";
        if (abbr.equals("BAL")) return "bal";
        if (abbr.equals("BOS")) return "bos";
        if (abbr.equals("CHC")) return "chc";
        if (abbr.equals("CWS") || abbr.equals("CHW")) return "chw";
        if (abbr.equals("CIN")) return "cin";
        if (abbr.equals("CLE")) return "cle";
        if (abbr.equals("COL")) return "col";
        if (abbr.equals("DET")) return "det";
        if (abbr.equals("HOU")) return "hou";
        if (abbr.equals("KC") || abbr.equals("KCR")) return "kc";
        if (abbr.equals("LAA")) return "laa";
        if (abbr.equals("LAD")) return "lad";
        if (abbr.equals("MIA")) return "mia";
        if (abbr.equals("MIL")) return "mil";
        if (abbr.equals("MIN")) return "min";
        if (abbr.equals("NYM")) return "nym";
        if (abbr.equals("NYY")) return "nyy";
        if (abbr.equals("ATH") || abbr.equals("OAK")) return "ath";
        if (abbr.equals("PHI")) return "phi";
        if (abbr.equals("PIT")) return "pit";
        if (abbr.equals("SD") || abbr.equals("SDP")) return "sd";
        if (abbr.equals("SF") || abbr.equals("SFG")) return "sf";
        if (abbr.equals("SEA")) return "sea";
        if (abbr.equals("STL")) return "stl";
        if (abbr.equals("TB") || abbr.equals("TBR")) return "tb";
        if (abbr.equals("TEX")) return "tex";
        if (abbr.equals("TOR")) return "tor";
        if (abbr.equals("WSH") || abbr.equals("WSN")) return "wsh";
        return abbr.toLowerCase(Locale.US);
    }

    private TeamPalette paletteForComparison(Comparison c) {
        if (c == null) return defaultPalette();
        if (c.isTeam) return paletteForTeam(c.team);
        String abbr = c.player == null ? "" : c.player.teamAbbr;
        return paletteForAbbr(abbr);
    }

    private TeamPalette paletteForTeam(Team team) {
        return paletteForAbbr(team == null ? "" : team.abbr);
    }

    private TeamPalette paletteForAbbr(String rawAbbr) {
        String a = safe(rawAbbr).toUpperCase(Locale.US).replaceAll("[^A-Z]", "");
        if (a.equals("ARI") || a.equals("AZ")) return new TeamPalette(Color.rgb(167, 25, 48), Color.rgb(48, 108, 146));
        if (a.equals("ATL")) return new TeamPalette(Color.rgb(19, 39, 79), Color.rgb(206, 17, 65));
        if (a.equals("BAL")) return new TeamPalette(Color.rgb(223, 70, 1), Color.rgb(39, 37, 31));
        if (a.equals("BOS")) return new TeamPalette(Color.rgb(189, 48, 57), Color.rgb(12, 35, 64));
        if (a.equals("CHC")) return new TeamPalette(Color.rgb(14, 51, 134), Color.rgb(204, 52, 51));
        if (a.equals("CWS") || a.equals("CHW")) return new TeamPalette(Color.rgb(39, 37, 31), Color.rgb(196, 206, 212));
        if (a.equals("CIN")) return new TeamPalette(Color.rgb(198, 1, 31), Color.rgb(20, 20, 20));
        if (a.equals("CLE")) return new TeamPalette(Color.rgb(0, 43, 92), Color.rgb(229, 24, 55));
        if (a.equals("COL")) return new TeamPalette(Color.rgb(51, 0, 111), Color.rgb(196, 206, 212));
        if (a.equals("DET")) return new TeamPalette(Color.rgb(12, 35, 64), Color.rgb(250, 70, 22));
        if (a.equals("HOU")) return new TeamPalette(Color.rgb(0, 45, 98), Color.rgb(235, 110, 31));
        if (a.equals("KC") || a.equals("KCR")) return new TeamPalette(Color.rgb(0, 70, 135), Color.rgb(189, 155, 96));
        if (a.equals("LAA")) return new TeamPalette(Color.rgb(186, 0, 33), Color.rgb(0, 50, 99));
        if (a.equals("LAD")) return new TeamPalette(Color.rgb(0, 90, 156), Color.rgb(24, 74, 130));
        if (a.equals("MIA")) return new TeamPalette(Color.rgb(0, 163, 224), Color.rgb(239, 51, 64));
        if (a.equals("MIL")) return new TeamPalette(Color.rgb(18, 40, 75), Color.rgb(255, 197, 47));
        if (a.equals("MIN")) return new TeamPalette(Color.rgb(0, 43, 92), Color.rgb(211, 17, 69));
        if (a.equals("NYM")) return new TeamPalette(Color.rgb(0, 45, 114), Color.rgb(255, 89, 16));
        if (a.equals("NYY")) return new TeamPalette(Color.rgb(12, 35, 64), Color.rgb(196, 206, 212));
        if (a.equals("ATH") || a.equals("OAK")) return new TeamPalette(Color.rgb(0, 56, 49), Color.rgb(239, 178, 30));
        if (a.equals("PHI")) return new TeamPalette(Color.rgb(232, 24, 40), Color.rgb(0, 45, 114));
        if (a.equals("PIT")) return new TeamPalette(Color.rgb(39, 37, 31), Color.rgb(253, 184, 39));
        if (a.equals("SD") || a.equals("SDP")) return new TeamPalette(Color.rgb(47, 36, 29), Color.rgb(255, 196, 37));
        if (a.equals("SF") || a.equals("SFG")) return new TeamPalette(Color.rgb(253, 90, 30), Color.rgb(39, 37, 31));
        if (a.equals("SEA")) return new TeamPalette(Color.rgb(0, 92, 92), Color.rgb(12, 44, 86));
        if (a.equals("STL")) return new TeamPalette(Color.rgb(196, 30, 58), Color.rgb(12, 35, 64));
        if (a.equals("TB") || a.equals("TBR")) return new TeamPalette(Color.rgb(9, 44, 92), Color.rgb(143, 188, 230));
        if (a.equals("TEX")) return new TeamPalette(Color.rgb(0, 50, 120), Color.rgb(192, 17, 31));
        if (a.equals("TOR")) return new TeamPalette(Color.rgb(19, 74, 142), Color.rgb(232, 41, 28));
        if (a.equals("WSH") || a.equals("WSN")) return new TeamPalette(Color.rgb(171, 0, 3), Color.rgb(20, 34, 90));
        return defaultPalette();
    }

    private TeamPalette defaultPalette() { return new TeamPalette(NAVY, TEAL_DARK); }

    private int softColor(int color, float amountWhite) {
        int r = Math.round(Color.red(color) * (1f - amountWhite) + 255 * amountWhite);
        int g = Math.round(Color.green(color) * (1f - amountWhite) + 255 * amountWhite);
        int b = Math.round(Color.blue(color) * (1f - amountWhite) + 255 * amountWhite);
        return Color.rgb(r, g, b);
    }

    private String initials(String value) {
        String cleaned = safe(value).replaceAll("[^A-Za-z0-9 ]", " ").trim();
        if (cleaned.isEmpty()) return "•";
        String[] parts = cleaned.split("\\s+");
        if (parts.length == 1) return parts[0].substring(0, Math.min(2, parts[0].length())).toUpperCase(Locale.US);
        return (parts[0].substring(0, 1) + parts[parts.length - 1].substring(0, 1)).toUpperCase(Locale.US);
    }

    private String httpGet(String urlString) throws Exception {
        String cached = textCache.get(urlString);
        if (cached != null) return cached;

        String fileKey = "hc_" + Integer.toHexString(urlString.hashCode()) + ".txt";
        File cacheFile = new File(getHttpCacheDir(), fileKey);
        long now = System.currentTimeMillis();
        long ttl = cacheTtlMs(urlString);
        if (cacheFile.exists() && now - cacheFile.lastModified() < ttl) {
            String diskText = readCacheFile(cacheFile);
            if (diskText != null && !diskText.isEmpty()) {
                textCache.put(urlString, diskText);
                return diskText;
            }
        }

        HttpURLConnection conn = (HttpURLConnection) new URL(urlString).openConnection();
        conn.setConnectTimeout(12000);
        conn.setReadTimeout(25000);
        conn.setRequestMethod("GET");
        conn.setRequestProperty("User-Agent", "Mozilla/5.0 Statcast Compare Android");
        conn.setRequestProperty("Accept", "text/csv,text/plain,application/json,text/html,*/*");
        int code = conn.getResponseCode();
        InputStream stream = code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream();
        BufferedReader br = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line).append('\n');
        String text = sb.toString();
        if (code < 200 || code >= 300) throw new Exception("HTTP " + code);
        textCache.put(urlString, text);
        writeCacheFile(cacheFile, text);
        return text;
    }

    private File getHttpCacheDir() {
        File dir = new File(getCacheDir(), "http");
        dir.mkdirs();
        return dir;
    }

    private String readCacheFile(File f) {
        try (FileInputStream fis = new FileInputStream(f);
             BufferedReader br = new BufferedReader(new InputStreamReader(fis, StandardCharsets.UTF_8))) {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line).append('\n');
            return sb.toString();
        } catch (Exception e) { return null; }
    }

    private void writeCacheFile(File f, String text) {
        try (OutputStreamWriter w = new OutputStreamWriter(new FileOutputStream(f), StandardCharsets.UTF_8)) {
            w.write(text);
        } catch (Exception ignored) {}
    }

    private long cacheTtlMs(String urlString) {
        int currentYear = Calendar.getInstance().get(Calendar.YEAR);
        String currentYearText = "year=" + currentYear;
        if (urlString.contains("/roster/") || urlString.contains("/sports/1/players") || urlString.contains("/teams?")) return 12L * 60L * 60L * 1000L;
        if (urlString.contains(currentYearText)) return 6L * 60L * 60L * 1000L;
        return 21L * 24L * 60L * 60L * 1000L;
    }

    // CSV/format helpers -----------------------------------------------------------------------

    private List<Map<String, String>> parseCsv(String text) {
        ArrayList<ArrayList<String>> rows = new ArrayList<>();
        ArrayList<String> row = new ArrayList<>();
        StringBuilder field = new StringBuilder();
        boolean inQuotes = false;
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            char next = i + 1 < text.length() ? text.charAt(i + 1) : '\0';
            if (c == '"') {
                if (inQuotes && next == '"') { field.append('"'); i++; }
                else inQuotes = !inQuotes;
            } else if (c == ',' && !inQuotes) {
                row.add(field.toString()); field.setLength(0);
            } else if ((c == '\n' || c == '\r') && !inQuotes) {
                if (c == '\r' && next == '\n') i++;
                row.add(field.toString()); field.setLength(0);
                boolean nonEmpty = false; for (String v : row) if (!v.isEmpty()) { nonEmpty = true; break; }
                if (nonEmpty) rows.add(row);
                row = new ArrayList<>();
            } else field.append(c);
        }
        if (field.length() > 0 || !row.isEmpty()) {
            row.add(field.toString());
            rows.add(row);
        }
        ArrayList<Map<String, String>> out = new ArrayList<>();
        if (rows.size() < 2) return out;
        ArrayList<String> headers = rows.get(0);
        for (int r = 1; r < rows.size(); r++) {
            HashMap<String, String> map = new HashMap<>();
            ArrayList<String> vals = rows.get(r);
            for (int h = 0; h < headers.size(); h++) map.put(headers.get(h).trim(), h < vals.size() ? vals.get(h) : "");
            out.add(map);
        }
        return out;
    }

    private String toQuery(LinkedHashMap<String, String> params) throws Exception {
        StringBuilder sb = new StringBuilder("?");
        boolean first = true;
        for (Map.Entry<String, String> e : params.entrySet()) {
            if (!first) sb.append('&');
            sb.append(enc(e.getKey())).append('=').append(enc(e.getValue()));
            first = false;
        }
        return sb.toString();
    }

    private String enc(String s) throws Exception { return URLEncoder.encode(s == null ? "" : s, "UTF-8"); }
    private String safe(String s) { return s == null ? "" : s; }
    private Double pick(Map<String, String> row, String... names) {
        for (String n : names) if (row.containsKey(n)) return num(row.get(n));
        HashMap<String, String> lowerMap = new HashMap<>();
        for (String k : row.keySet()) lowerMap.put(k.toLowerCase(Locale.US).replaceAll("[^a-z0-9]", ""), k);
        for (String n : names) {
            String k = lowerMap.get(n.toLowerCase(Locale.US).replaceAll("[^a-z0-9]", ""));
            if (k != null) return num(row.get(k));
        }
        return null;
    }
    private String pickString(Map<String, String> row, String... names) {
        for (String n : names) if (row.containsKey(n) && row.get(n) != null && !row.get(n).trim().isEmpty()) return row.get(n).trim();
        HashMap<String, String> lowerMap = new HashMap<>();
        for (String k : row.keySet()) lowerMap.put(k.toLowerCase(Locale.US).replaceAll("[^a-z0-9]", ""), k);
        for (String n : names) {
            String k = lowerMap.get(n.toLowerCase(Locale.US).replaceAll("[^a-z0-9]", ""));
            if (k != null && row.get(k) != null && !row.get(k).trim().isEmpty()) return row.get(k).trim();
        }
        return "";
    }
    private String buildNameFromColumns(Map<String, String> row) {
        String first = pickString(row, "first_name", "first name");
        String last = pickString(row, "last_name", "last name");
        return (first + " " + last).trim();
    }
    private String normalizePlayerName(String name) {
        String n = safe(name).trim();
        if (n.contains(",")) {
            String[] parts = n.split(",");
            if (parts.length >= 2) n = parts[1].trim() + " " + parts[0].trim();
        }
        return n.replaceAll("\\s+", " ").trim();
    }
    private String normalizeNameKey(String value) {
        return safe(value).toLowerCase(Locale.US).replaceAll("[^a-z0-9]", "");
    }
    private Double num(String value) {
        if (value == null) return null;
        String cleaned = value.replace("%", "").replace(",", "").trim();
        if (cleaned.isEmpty() || cleaned.equals("-")) return null;
        try { return Double.parseDouble(cleaned); } catch (Exception e) { return null; }
    }
    private int intVal(Double d) { return d == null || Double.isNaN(d) ? 0 : (int) Math.round(d); }
    private Double diff(Double a, Double b) { return a == null || b == null ? null : a - b; }
    private String fmtCount(int v) { return String.format(Locale.US, "%,d", v); }

    private String statLineSummary(Stats s) {
        if (s == null) return "—";
        if (s.ip > 0 && (s.get("era") != null || s.get("whip") != null)) return new DecimalFormat("0.0").format(s.ip) + " IP" + (s.pa > 0 ? " · " + fmtCount(s.pa) + " BF" : "");
        return fmtCount(s.pa) + " PA · " + fmtCount(s.bbe) + " BBE";
    }

    private String format(Double v, Metric m) {
        if (v == null || Double.isNaN(v)) return "—";
        String pattern = m.decimals <= 0 ? "0" : (m.decimals == 1 ? "0.0" : (m.decimals == 2 ? "0.00" : "0.000"));
        DecimalFormat df = new DecimalFormat(pattern);
        return df.format(v) + m.unit;
    }
    private String signedFormat(Double v, Metric m) {
        if (v == null || Double.isNaN(v)) return "—";
        return (v > 0 ? "+" : "") + format(v, m);
    }
    private double[] scaleValues(Double[] values, Metric m) {
        ArrayList<Double> valid = new ArrayList<>();
        for (Double v : values) if (v != null && !Double.isNaN(v)) valid.add(v);
        double[] out = new double[values.length];
        if (valid.isEmpty()) return out;
        double[] domain = metricScaleDomain(m, values);
        double lo = domain[0], hi = domain[1];
        if (hi <= lo) { lo -= 1; hi += 1; }
        for (int i = 0; i < values.length; i++) {
            Double v = values[i];
            if (v == null || Double.isNaN(v)) out[i] = 0;
            else out[i] = Math.max(7, Math.min(100, ((v - lo) / (hi - lo)) * 100));
        }
        return out;
    }

    private double[] metricScaleDomain(Metric m, Double[] values) {
        ArrayList<Double> valid = new ArrayList<>();
        for (Double v : values) if (v != null && !Double.isNaN(v)) valid.add(v);
        if (valid.isEmpty()) return new double[] {0, 1};

        double min = Collections.min(valid);
        double max = Collections.max(valid);
        double lo;
        double hi;

        switch (m.key) {
            case "avg":
            case "xBA":
                lo = 0.180; hi = 0.360; break;
            case "obp":
                lo = 0.240; hi = 0.460; break;
            case "slg":
            case "xSLG":
                lo = 0.280; hi = 0.700; break;
            case "ops":
                lo = 0.500; hi = 1.100; break;
            case "wOBA":
            case "xwOBA":
                lo = 0.240; hi = 0.460; break;
            case "luck":
                lo = -0.060; hi = 0.060; break;
            case "avgEV":
                lo = 82.0; hi = 98.0; break;
            case "avgLA":
                lo = -10.0; hi = 35.0; break;
            case "hardHitPct":
                lo = 20.0; hi = 65.0; break;
            case "barrelPct":
                lo = 0.0; hi = 25.0; break;
            case "sweetSpotPct":
                lo = 20.0; hi = 45.0; break;
            case "kPct":
                lo = 5.0; hi = 40.0; break;
            case "bbPct":
                lo = 2.0; hi = 20.0; break;
            case "era":
                lo = 1.50; hi = 7.50; break;
            case "whip":
                lo = 0.80; hi = 1.80; break;
            case "k9":
                lo = 5.0; hi = 14.0; break;
            case "bb9":
                lo = 1.0; hi = 6.0; break;
            case "kbb":
                lo = 1.0; hi = 8.0; break;
            case "ip":
                lo = 0.0; hi = max > 400 ? 1600.0 : 220.0; break;
            case "hr":
                lo = 0.0; hi = max > 120 ? 320.0 : 60.0; break;
            case "rbi":
            case "r":
                lo = 0.0; hi = max > 200 ? 950.0 : 150.0; break;
            case "sb":
                lo = 0.0; hi = max > 120 ? 220.0 : 80.0; break;
            case "pitchK":
                lo = 0.0; hi = max > 400 ? 1600.0 : 320.0; break;
            case "pitchBB":
                lo = 0.0; hi = max > 180 ? 700.0 : 110.0; break;
            case "saves":
                lo = 0.0; hi = max > 90 ? 90.0 : 55.0; break;
            default:
                if (m.isCount()) {
                    lo = 0.0;
                    hi = Math.max(10.0, max * 1.18);
                } else if ("expected".equals(m.type)) {
                    lo = min - 0.010; hi = max + 0.010;
                } else if ("rate".equals(m.type)) {
                    lo = min - 1.5; hi = max + 1.5;
                } else {
                    lo = min - 0.5; hi = max + 0.5;
                }
                break;
        }

        double span = hi - lo;
        double extra = Math.max(span * 0.04, m.isCount() ? 1.0 : ("luck".equals(m.key) ? 0.003 : 0.0));
        lo = Math.min(lo, min - extra);
        hi = Math.max(hi, max + extra);

        if ("luck".equals(m.key)) {
            double abs = Math.max(Math.abs(lo), Math.abs(hi));
            lo = -abs;
            hi = abs;
        }

        return new double[] { lo, hi };
    }


    private void drawBitmapFitCenter(Canvas canvas, Bitmap bitmap, RectF box, boolean roundedClip, float cornerRadius) {
        if (bitmap == null || bitmap.getWidth() <= 0 || bitmap.getHeight() <= 0) return;
        float bw = bitmap.getWidth();
        float bh = bitmap.getHeight();
        float scale = Math.min(box.width() / bw, box.height() / bh);
        float w = bw * scale;
        float h = bh * scale;
        Rect src = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());
        RectF dst = new RectF(box.centerX() - w / 2f, box.centerY() - h / 2f, box.centerX() + w / 2f, box.centerY() + h / 2f);
        if (roundedClip) {
            Path clip = new Path();
            clip.addRoundRect(box, cornerRadius, cornerRadius, Path.Direction.CW);
            int save = canvas.save();
            canvas.clipPath(clip);
            canvas.drawBitmap(bitmap, src, dst, paintForBitmap());
            canvas.restoreToCount(save);
        } else {
            canvas.drawBitmap(bitmap, src, dst, paintForBitmap());
        }
    }

    private Paint paintForBitmap() {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG | Paint.DITHER_FLAG);
        p.setStyle(Paint.Style.FILL);
        return p;
    }


    class PercentileMiniBarView extends View {
        final int color;
        final Double pct;
        final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        PercentileMiniBarView(Context context, int color, Double pct) {
            super(context);
            this.color = color;
            this.pct = pct;
        }
        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float left = 0, right = getWidth(), midY = getHeight() / 2f;
            RectF track = new RectF(left, midY - dp(3), right, midY + dp(3));
            paint.setStyle(Paint.Style.FILL);
            paint.setShader(null);
            paint.setColor(Color.rgb(228, 235, 245));
            canvas.drawRoundRect(track, dp(8), dp(8), paint);
            if (pct != null && !Double.isNaN(pct)) {
                float x = (float) (left + (Math.max(0, Math.min(100, pct)) / 100.0) * (right - left));
                RectF fill = new RectF(left, track.top, x, track.bottom);
                paint.setColor(color);
                canvas.drawRoundRect(fill, dp(8), dp(8), paint);
                paint.setColor(Color.WHITE);
                canvas.drawCircle(x, midY, dp(4), paint);
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(dp(2));
                paint.setColor(color);
                canvas.drawCircle(x, midY, dp(4), paint);
                paint.setStyle(Paint.Style.FILL);
            }
        }
    }

    class ExpectedActualBarView extends View {
        final Metric metric;
        final Double actual, expected, actualPct, expectedPct;
        final TeamPalette palette;
        final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        ExpectedActualBarView(Context context, Metric metric, Double actual, Double expected, Double actualPct, Double expectedPct, TeamPalette palette) {
            super(context);
            this.metric = metric;
            this.actual = actual;
            this.expected = expected;
            this.actualPct = actualPct;
            this.expectedPct = expectedPct;
            this.palette = palette == null ? defaultPalette() : palette;
        }
        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float left = dp(18);
            float right = getWidth() - dp(18);
            float y = dp(20);
            float h = dp(10);
            RectF track = new RectF(left, y, right, y + h);
            paint.setStyle(Paint.Style.FILL);
            paint.setShader(null);
            paint.setColor(Color.rgb(229, 235, 245));
            canvas.drawRoundRect(track, dp(10), dp(10), paint);
            paint.setColor(softColor(palette.primary, 0.78f));
            canvas.drawRoundRect(track, dp(10), dp(10), paint);
            drawPercentTick(canvas, left, y + h + dp(14), "0%");
            drawPercentTick(canvas, left + (right - left) / 2f, y + h + dp(14), "50%");
            drawPercentTick(canvas, right, y + h + dp(14), "100%");

            float actualX = markerX(actual, actualPct, left, right);
            float expectedX = markerX(expected, expectedPct, left, right);
            if (actualX >= 0 && expectedX >= 0) {
                paint.setStrokeWidth(dp(3));
                paint.setColor(Color.argb(150, 42, 47, 61));
                canvas.drawLine(actualX, y + h / 2f, expectedX, y + h / 2f, paint);
            }
            if (expectedX >= 0) drawMarker(canvas, expectedX, y + h / 2f, palette.secondary, "x");
            if (actualX >= 0) drawMarker(canvas, actualX, y + h / 2f, palette.primary, "A");
        }
        private float markerX(Double value, Double pct, float left, float right) {
            if (pct != null && !Double.isNaN(pct)) return (float) (left + (Math.max(0, Math.min(100, pct)) / 100.0) * (right - left));
            if (value == null || Double.isNaN(value)) return -1;
            double[] domain = metricScaleDomain(metric, new Double[] { actual, expected });
            double lo = domain[0], hi = domain[1];
            if (hi <= lo) return -1;
            return (float) Math.max(left + dp(10), Math.min(right - dp(10), left + ((value - lo) / (hi - lo)) * (right - left)));
        }
        private void drawPercentTick(Canvas canvas, float x, float y, String label) {
            paint.setShader(null);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.rgb(112, 123, 142));
            paint.setTextAlign(Paint.Align.CENTER);
            paint.setTextSize(dp(10));
            paint.setTypeface(Typeface.DEFAULT_BOLD);
            canvas.drawText(label, x, y, paint);
        }
        private void drawMarker(Canvas canvas, float cx, float cy, int color, String label) {
            paint.setShader(null);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.WHITE);
            canvas.drawCircle(cx, cy, dp(13), paint);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dp(3));
            paint.setColor(color);
            canvas.drawCircle(cx, cy, dp(12), paint);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(color);
            paint.setTextAlign(Paint.Align.CENTER);
            paint.setTextSize(dp(10));
            paint.setTypeface(Typeface.DEFAULT_BOLD);
            canvas.drawText(label, cx, cy + dp(4), paint);
        }
    }


    class HeadToHeadBarView extends View {
        final Metric metric;
        final Double[] values;
        final Double[] percentiles;
        final TeamPalette paletteA;
        final TeamPalette paletteB;
        final String labelA;
        final String labelB;
        Bitmap iconA;
        Bitmap iconB;
        final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private float animProgress = 0f;    // v29: marker animation (0 → 1)
        private boolean animStarted = false;

        HeadToHeadBarView(Context context, Metric metric, Double[] values, Double[] percentiles, TeamPalette paletteA, TeamPalette paletteB, String labelA, String labelB) {
            super(context);
            this.metric = metric;
            this.values = values;
            this.percentiles = percentiles;
            this.paletteA = paletteA == null ? defaultPalette() : paletteA;
            this.paletteB = paletteB == null ? defaultPalette() : paletteB;
            this.labelA = labelA == null ? "A" : labelA;
            this.labelB = labelB == null ? "B" : labelB;
        }

        void setIconA(Bitmap bitmap) { this.iconA = bitmap; invalidate(); }
        void setIconB(Bitmap bitmap) { this.iconB = bitmap; invalidate(); }

        @Override
        protected void onAttachedToWindow() {
            super.onAttachedToWindow();
            if (!animStarted) {
                animStarted = true;
                ValueAnimator anim = ValueAnimator.ofFloat(0f, 1f);
                anim.setDuration(420);
                anim.setInterpolator(new DecelerateInterpolator(2.0f));
                anim.addUpdateListener(a -> {
                    animProgress = (float) a.getAnimatedValue();
                    invalidate();
                });
                anim.start();
            }
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            ArrayList<Double> valid = new ArrayList<>();
            for (Double v : values) if (v != null && !Double.isNaN(v)) valid.add(v);
            if (valid.isEmpty()) return;

            double[] domain = metricScaleDomain(metric, values);
            double lo = domain[0];
            double hi = domain[1];
            if (hi <= lo) { lo -= 1; hi += 1; }

            float left = dp(18);
            float right = getWidth() - dp(18);
            float y = dp(22);
            float h = dp(10);
            RectF track = new RectF(left, y, right, y + h);

            paint.setStyle(Paint.Style.FILL);
            paint.setShader(null);
            paint.setColor(Color.rgb(229, 235, 245));
            canvas.drawRoundRect(track, dp(10), dp(10), paint);
            LinearGradient gradient = new LinearGradient(left, y, right, y + h,
                    new int[] { softColor(paletteA.primary, 0.18f), softColor(Color.rgb(70, 88, 125), 0.18f), softColor(paletteB.primary, 0.18f) },
                    new float[] { 0f, 0.50f, 1f }, Shader.TileMode.CLAMP);
            paint.setShader(gradient);
            canvas.drawRoundRect(track, dp(10), dp(10), paint);
            paint.setShader(null);

            paint.setColor(Color.argb(105, 255, 255, 255));
            for (int i = 1; i < 4; i++) {
                float gx = left + (right - left) * i / 4f;
                canvas.drawRoundRect(new RectF(gx - dp(1), y - dp(3), gx + dp(1), y + h + dp(3)), dp(1), dp(1), paint);
            }

            if (lo < 0 && hi > 0 && metric.key.equals("luck")) {
                float zx = (float) (left + ((0 - lo) / (hi - lo)) * (right - left));
                paint.setColor(Color.argb(200, 45, 54, 74));
                canvas.drawRoundRect(new RectF(zx - dp(1), y - dp(8), zx + dp(1), y + h + dp(8)), dp(2), dp(2), paint);
            }

            drawPercentileScale(canvas, left, right, y + h + dp(20));

            float[] xs = new float[values.length];
            for (int i = 0; i < values.length; i++) {
                Double v = values[i];
                if (v == null || Double.isNaN(v)) { xs[i] = -1; continue; }
                float x;
                if (percentiles != null && i < percentiles.length && percentiles[i] != null && !Double.isNaN(percentiles[i])) {
                    x = (float) (left + (Math.max(0, Math.min(100, percentiles[i])) / 100.0) * (right - left));
                } else {
                    x = (float) (left + ((v - lo) / (hi - lo)) * (right - left));
                }
                xs[i] = Math.max(left + dp(14), Math.min(right - dp(14), x));
            }

            // v29: Ease markers from league-average (50%) out to their final percentile
            float centerX = left + (right - left) * 0.5f;
            for (int i = 0; i < xs.length; i++) {
                if (xs[i] >= 0) xs[i] = centerX + (xs[i] - centerX) * animProgress;
            }

            if (xs.length > 2 && xs[2] >= 0) drawLeagueMarker(canvas, xs[2], y + h / 2);
            if (xs.length > 0 && xs[0] >= 0) drawSideMarker(canvas, xs[0], y + h / 2, iconA, paletteA, labelA, true);
            if (xs.length > 1 && xs[1] >= 0) drawSideMarker(canvas, xs[1], y + h / 2, iconB, paletteB, labelB, false);
        }

        private void drawPercentileScale(Canvas canvas, float left, float right, float baseline) {
            paint.setShader(null);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.rgb(112, 123, 142));
            paint.setTextSize(dp(8));
            paint.setTypeface(tfBold);                  // v29: weight ladder
            paint.setFontFeatureSettings("'tnum' 1");   // v29: tabular figures
            paint.setTextAlign(Paint.Align.LEFT);
            canvas.drawText("0%", left, baseline, paint);
            paint.setTextAlign(Paint.Align.CENTER);
            canvas.drawText("50%", (left + right) / 2f, baseline, paint);
            paint.setTextAlign(Paint.Align.RIGHT);
            canvas.drawText("100%", right, baseline, paint);
        }

        private void drawSideMarker(Canvas canvas, float cx, float cy, Bitmap icon, TeamPalette palette, String label, boolean leftSide) {
            float w = dp(32), h = dp(28);
            RectF outer = new RectF(cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2);
            paint.setShader(null);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.WHITE);
            canvas.drawRoundRect(outer, dp(9), dp(9), paint);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dp(2));
            paint.setColor(palette.primary);
            canvas.drawRoundRect(outer, dp(9), dp(9), paint);
            paint.setStyle(Paint.Style.FILL);
            RectF inner = new RectF(outer.left + dp(3), outer.top + dp(3), outer.right - dp(3), outer.bottom - dp(3));
            if (icon != null) {
                drawBitmapFitCenter(canvas, icon, inner, true, dp(6));
            } else {
                paint.setColor(palette.primary);
                canvas.drawRoundRect(inner, dp(6), dp(6), paint);
                paint.setColor(Color.WHITE);
                paint.setTextAlign(Paint.Align.CENTER);
                paint.setTextSize(dp(8));
                paint.setTypeface(tfBold);  // v29
                canvas.drawText(leftSide ? "A" : "B", inner.centerX(), inner.centerY() + dp(3), paint);
            }
        }

        private void drawLeagueMarker(Canvas canvas, float cx, float cy) {
            float w = dp(38), h = dp(22);
            RectF pill = new RectF(cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2);
            paint.setShader(null);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.WHITE);
            canvas.drawRoundRect(new RectF(pill.left - dp(2), pill.top - dp(2), pill.right + dp(2), pill.bottom + dp(2)), dp(10), dp(10), paint);
            LinearGradient lg = new LinearGradient(pill.left, pill.top, pill.right, pill.bottom,
                    new int[] { Color.rgb(21, 53, 97), Color.rgb(198, 45, 58) }, null, Shader.TileMode.CLAMP);
            paint.setShader(lg);
            canvas.drawRoundRect(pill, dp(10), dp(10), paint);
            paint.setShader(null);
            paint.setColor(Color.WHITE);
            paint.setTextAlign(Paint.Align.CENTER);
            paint.setTextSize(dp(8));
            paint.setTypeface(tfBold);  // v29
            canvas.drawText("MLB", cx, cy + dp(3), paint);
        }
    }

    class ComparisonBarView extends View {
        final Metric metric;
        final Double[] values;
        final Double[] percentiles;
        final String thirdLabel;
        final TeamPalette palette;
        final String currentLabel;
        Bitmap currentIcon;
        final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private float animProgress = 0f;    // v29: marker animation (0 → 1)
        private boolean animStarted = false;

        ComparisonBarView(Context context, Metric metric, Double[] values, Double[] percentiles, String thirdLabel, TeamPalette palette, String currentLabel) {
            super(context);
            this.metric = metric;
            this.values = values;
            this.percentiles = percentiles;
            this.thirdLabel = thirdLabel == null ? "Career" : thirdLabel;
            this.palette = palette == null ? defaultPalette() : palette;
            this.currentLabel = currentLabel == null ? "" : currentLabel;
        }

        void setCurrentIcon(Bitmap bitmap) {
            this.currentIcon = bitmap;
            invalidate();
        }

        @Override
        protected void onAttachedToWindow() {
            super.onAttachedToWindow();
            if (!animStarted) {
                animStarted = true;
                ValueAnimator anim = ValueAnimator.ofFloat(0f, 1f);
                anim.setDuration(420);
                anim.setInterpolator(new DecelerateInterpolator(2.0f));
                anim.addUpdateListener(a -> {
                    animProgress = (float) a.getAnimatedValue();
                    invalidate();
                });
                anim.start();
            }
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            ArrayList<Double> valid = new ArrayList<>();
            for (Double v : values) if (v != null && !Double.isNaN(v)) valid.add(v);
            if (valid.isEmpty()) return;

            double[] domain = metricScaleDomain(metric, values);
            double lo = domain[0];
            double hi = domain[1];
            if (hi <= lo) { lo -= 1; hi += 1; }

            float left = dp(18);
            float right = getWidth() - dp(18);
            float y = dp(24);
            float h = dp(12);
            RectF track = new RectF(left, y, right, y + h);

            paint.setStyle(Paint.Style.FILL);
            paint.setShader(null);
            paint.setColor(Color.rgb(229, 235, 245));
            canvas.drawRoundRect(track, dp(10), dp(10), paint);

            LinearGradient gradient = new LinearGradient(left, y, right, y + h,
                    new int[] { softColor(palette.secondary, 0.28f), softColor(palette.primary, 0.10f), softColor(palette.secondary, 0.20f) },
                    new float[] { 0f, 0.55f, 1f }, Shader.TileMode.CLAMP);
            paint.setShader(gradient);
            canvas.drawRoundRect(track, dp(10), dp(10), paint);
            paint.setShader(null);

            paint.setColor(Color.argb(105, 255, 255, 255));
            for (int i = 1; i < 4; i++) {
                float gx = left + (right - left) * i / 4f;
                canvas.drawRoundRect(new RectF(gx - dp(1), y - dp(3), gx + dp(1), y + h + dp(3)), dp(1), dp(1), paint);
            }

            if (lo < 0 && hi > 0 && metric.key.equals("luck")) {
                float zx = (float) (left + ((0 - lo) / (hi - lo)) * (right - left));
                paint.setColor(Color.argb(210, 45, 54, 74));
                canvas.drawRoundRect(new RectF(zx - dp(1), y - dp(8), zx + dp(1), y + h + dp(8)), dp(2), dp(2), paint);
            }

            drawPercentileScale(canvas, left, right, y + h + dp(20));

            float[] xs = new float[values.length];
            for (int i = 0; i < values.length; i++) {
                Double v = values[i];
                if (v == null || Double.isNaN(v)) { xs[i] = -1; continue; }
                float x;
                if (percentiles != null && i < percentiles.length && percentiles[i] != null && !Double.isNaN(percentiles[i])) {
                    x = (float) (left + (Math.max(0, Math.min(100, percentiles[i])) / 100.0) * (right - left));
                } else {
                    x = (float) (left + ((v - lo) / (hi - lo)) * (right - left));
                }
                xs[i] = Math.max(left + dp(12), Math.min(right - dp(12), x));
            }

            // v29: Ease markers from league-average (50%) out to their final percentile
            float centerX = left + (right - left) * 0.5f;
            for (int i = 0; i < xs.length; i++) {
                if (xs[i] >= 0) xs[i] = centerX + (xs[i] - centerX) * animProgress;
            }

            if (xs.length > 1 && xs[1] >= 0) drawLeagueMarker(canvas, xs[1], y + h / 2);
            if (xs.length > 2 && xs[2] >= 0) drawCareerMarker(canvas, xs[2], y + h / 2);
            if (xs.length > 0 && xs[0] >= 0) drawCurrentMarker(canvas, xs[0], y + h / 2);
        }

        private void drawPercentileScale(Canvas canvas, float left, float right, float baseline) {
            paint.setShader(null);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.rgb(112, 123, 142));
            paint.setTextSize(dp(8));
            paint.setTypeface(tfBold);                  // v29: weight ladder
            paint.setFontFeatureSettings("'tnum' 1");   // v29: tabular figures
            paint.setTextAlign(Paint.Align.LEFT);
            canvas.drawText("0%", left, baseline, paint);
            paint.setTextAlign(Paint.Align.CENTER);
            canvas.drawText("50%", (left + right) / 2f, baseline, paint);
            paint.setTextAlign(Paint.Align.RIGHT);
            canvas.drawText("100%", right, baseline, paint);
        }

        private void drawCurrentMarker(Canvas canvas, float cx, float cy) {
            float w = dp(38), h = dp(34);
            RectF outer = new RectF(cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2);
            paint.setShader(null);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.WHITE);
            canvas.drawRoundRect(outer, dp(9), dp(9), paint);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dp(2));
            paint.setColor(palette.primary);
            canvas.drawRoundRect(outer, dp(9), dp(9), paint);
            paint.setStyle(Paint.Style.FILL);
            RectF inner = new RectF(outer.left + dp(3), outer.top + dp(3), outer.right - dp(3), outer.bottom - dp(3));
            if (currentIcon != null) {
                drawBitmapFitCenter(canvas, currentIcon, inner, true, dp(6));
            } else {
                paint.setColor(palette.primary);
                canvas.drawRoundRect(inner, dp(6), dp(6), paint);
                paint.setColor(Color.WHITE);
                paint.setTextAlign(Paint.Align.CENTER);
                paint.setTextSize(dp(8));
                paint.setTypeface(tfBold);  // v29
                canvas.drawText(initials(currentLabel), inner.centerX(), inner.centerY() + dp(3), paint);
            }
        }

        private void drawLeagueMarker(Canvas canvas, float cx, float cy) {
            float w = dp(31), h = dp(18);
            RectF pill = new RectF(cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2);
            paint.setShader(null);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.WHITE);
            canvas.drawRoundRect(new RectF(pill.left - dp(2), pill.top - dp(2), pill.right + dp(2), pill.bottom + dp(2)), dp(10), dp(10), paint);
            LinearGradient lg = new LinearGradient(pill.left, pill.top, pill.right, pill.bottom,
                    new int[] { Color.rgb(21, 53, 97), Color.rgb(198, 45, 58) }, null, Shader.TileMode.CLAMP);
            paint.setShader(lg);
            canvas.drawRoundRect(pill, dp(10), dp(10), paint);
            paint.setShader(null);
            paint.setColor(Color.WHITE);
            paint.setTextAlign(Paint.Align.CENTER);
            paint.setTextSize(dp(7));
            paint.setTypeface(tfBold);  // v29
            canvas.drawText("MLB", cx, cy + dp(3), paint);
        }

        private void drawCareerMarker(Canvas canvas, float cx, float cy) {
            float r = dp(13);
            paint.setShader(null);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.WHITE);
            canvas.drawCircle(cx, cy, r + dp(2), paint);
            paint.setColor(softColor(palette.secondary, 0.05f));
            canvas.drawCircle(cx, cy, r + dp(1), paint);
            paint.setColor(Color.WHITE);
            canvas.drawCircle(cx, cy, r - dp(1), paint);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dp(2));
            paint.setColor(palette.secondary);
            canvas.drawCircle(cx, cy, r - dp(1), paint);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(palette.secondary);
            paint.setTextAlign(Paint.Align.CENTER);
            paint.setTextSize(dp(13));
            paint.setTypeface(tfBold);  // v29
            canvas.drawText(thirdLabel.equals("Hist") ? "H" : "★", cx, cy + dp(4), paint);
        }
    }


    // ── v30.1: Advantage bar — proportional split showing stat-win ratio ──────────────────────────

    class AdvantageBarView extends View {
        final int aWins, bWins;
        final TeamPalette paletteA, paletteB;
        final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        AdvantageBarView(Context ctx, int aWins, int bWins, TeamPalette paletteA, TeamPalette paletteB) {
            super(ctx);
            this.aWins = aWins; this.bWins = bWins;
            this.paletteA = paletteA; this.paletteB = paletteB;
        }
        @Override
        protected void onDraw(Canvas canvas) {
            float w = getWidth(), h = getHeight();
            int total = aWins + bWins;
            paint.setStyle(Paint.Style.FILL);
            if (total == 0) {
                paint.setColor(Color.argb(50, 200, 215, 235));
                canvas.drawRoundRect(new RectF(0, 0, w, h), h / 2, h / 2, paint);
                return;
            }
            float split = w * ((float) aWins / total);
            if (split > dp(4)) { paint.setColor(paletteA.primary); canvas.drawRoundRect(new RectF(0, 0, split, h), h / 2, h / 2, paint); }
            if (split < w - dp(4)) { paint.setColor(paletteB.primary); canvas.drawRoundRect(new RectF(split, 0, w, h), h / 2, h / 2, paint); }
        }
    }

    // ── v30: Stat Duel overview — animated outward-fill bars per stat ─────────────────────────────

    class StatDuelView extends View {
        final HeadToHeadComparison h;
        final Metric[] rowMetrics;
        final TeamPalette paletteA, paletteB;
        final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private float animProgress = 0f;
        private boolean animStarted = false;

        StatDuelView(Context context, HeadToHeadComparison h, Metric[] rowMetrics, TeamPalette paletteA, TeamPalette paletteB) {
            super(context);
            this.h = h;
            this.rowMetrics = rowMetrics;
            this.paletteA = paletteA == null ? defaultPalette() : paletteA;
            this.paletteB = paletteB == null ? defaultPalette() : paletteB;
        }

        @Override
        protected void onAttachedToWindow() {
            super.onAttachedToWindow();
            if (!animStarted) {
                animStarted = true;
                ValueAnimator anim = ValueAnimator.ofFloat(0f, 1f);
                anim.setDuration(540);
                anim.setInterpolator(new DecelerateInterpolator(2.0f));
                anim.addUpdateListener(a -> { animProgress = (float) a.getAnimatedValue(); invalidate(); });
                anim.start();
            }
        }

        @Override
        protected void onMeasure(int widthSpec, int heightSpec) {
            setMeasuredDimension(MeasureSpec.getSize(widthSpec), rowMetrics.length * dp(50) + dp(6));
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth();
            float padH = dp(4);
            float trackLeft  = padH;
            float trackRight = w - padH;
            float halfW = (trackRight - trackLeft) / 2f;
            float cx = trackLeft + halfW;

            for (int i = 0; i < rowMetrics.length; i++) {
                Metric m = rowMetrics[i];
                Double pctA = h.percentileA == null ? null : h.percentileA.get(m.key);
                Double pctB = h.percentileB == null ? null : h.percentileB.get(m.key);
                Double valA = h.statsA.get(m.key);
                Double valB = h.statsB.get(m.key);

                float rowTop = i * dp(50);
                float textY  = rowTop + dp(17);
                float trackY = rowTop + dp(27);
                float trackH = dp(6);
                float pctY   = rowTop + dp(43);

                boolean aLeads = false, bLeads = false;
                if (valA != null && valB != null) {
                    double d = valA - valB;
                    if (Math.abs(d) > 0.000001) {
                        aLeads = m.higherGood == null ? d > 0 : (m.higherGood ? d > 0 : d < 0);
                        bLeads = !aLeads;
                    }
                }

                // Track background — subtle on dark card
                paint.setShader(null);
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(Color.argb(45, 200, 215, 240));
                canvas.drawRoundRect(new RectF(trackLeft, trackY, trackRight, trackY + trackH), dp(3), dp(3), paint);

                int aC = paletteA.primary;
                int bC = paletteB.primary;

                // A fill: LEFT edge → pctA% of left half, alpha-fading start
                if (pctA != null) {
                    float pN = (float) Math.max(0, Math.min(100, pctA));
                    float fillEnd = trackLeft + (pN / 100f) * halfW * animProgress;
                    if (fillEnd > trackLeft + dp(2)) {
                        LinearGradient ga = new LinearGradient(trackLeft, 0, fillEnd, 0,
                            new int[] { Color.argb(80, Color.red(aC), Color.green(aC), Color.blue(aC)),
                                        Color.argb(255, Color.red(aC), Color.green(aC), Color.blue(aC)) },
                            null, Shader.TileMode.CLAMP);
                        paint.setShader(ga);
                        canvas.drawRoundRect(new RectF(trackLeft, trackY, fillEnd, trackY + trackH), dp(3), dp(3), paint);
                        paint.setShader(null);
                    }
                }

                // B fill: RIGHT edge ← pctB% of right half, alpha-fading end
                if (pctB != null) {
                    float pN = (float) Math.max(0, Math.min(100, pctB));
                    float fillStart = trackRight - (pN / 100f) * halfW * animProgress;
                    if (fillStart < trackRight - dp(2)) {
                        LinearGradient gb = new LinearGradient(fillStart, 0, trackRight, 0,
                            new int[] { Color.argb(255, Color.red(bC), Color.green(bC), Color.blue(bC)),
                                        Color.argb(80, Color.red(bC), Color.green(bC), Color.blue(bC)) },
                            null, Shader.TileMode.CLAMP);
                        paint.setShader(gb);
                        canvas.drawRoundRect(new RectF(fillStart, trackY, trackRight, trackY + trackH), dp(3), dp(3), paint);
                        paint.setShader(null);
                    }
                }

                // Center tick
                paint.setColor(Color.argb(130, 200, 215, 240));
                canvas.drawRoundRect(new RectF(cx - dp(1), trackY - dp(2), cx + dp(1), trackY + trackH + dp(2)), dp(1), dp(1), paint);

                // A value — full color if winning, 100 alpha if losing
                paint.setShader(null);
                paint.setStyle(Paint.Style.FILL);
                paint.setTypeface(tfBold);
                paint.setFontFeatureSettings("'tnum' 1");
                paint.setTextSize(dp(aLeads ? 15 : 12));
                paint.setTextAlign(Paint.Align.LEFT);
                paint.setColor(aLeads ? aC : Color.argb(100, Color.red(aC), Color.green(aC), Color.blue(aC)));
                canvas.drawText(valA == null ? "—" : format(valA, m), trackLeft + dp(2), textY, paint);

                // Metric label — muted white on dark background
                paint.setTypeface(tfBold);
                paint.setTextSize(dp(9));
                paint.setTextAlign(Paint.Align.CENTER);
                paint.setColor(Color.argb(100, 200, 212, 232));
                paint.setLetterSpacing(0.06f);
                canvas.drawText(m.label.toUpperCase(Locale.US), cx, textY, paint);
                paint.setLetterSpacing(0f);

                // B value — full color if winning, 100 alpha if losing
                paint.setTextSize(dp(bLeads ? 15 : 12));
                paint.setTypeface(tfBold);
                paint.setTextAlign(Paint.Align.RIGHT);
                paint.setColor(bLeads ? bC : Color.argb(100, Color.red(bC), Color.green(bC), Color.blue(bC)));
                canvas.drawText(valB == null ? "—" : format(valB, m), trackRight - dp(2), textY, paint);

                // Percentile % — visible for winner, subdued for loser
                paint.setTypeface(tfRegular);
                paint.setTextSize(dp(8));
                paint.setTextAlign(Paint.Align.LEFT);
                paint.setColor(aLeads ? Color.argb(200, Color.red(aC), Color.green(aC), Color.blue(aC))
                                      : Color.argb(80, Color.red(aC), Color.green(aC), Color.blue(aC)));
                if (pctA != null) canvas.drawText(Math.round(pctA) + "%", trackLeft + dp(2), pctY, paint);

                paint.setTextAlign(Paint.Align.RIGHT);
                paint.setColor(bLeads ? Color.argb(200, Color.red(bC), Color.green(bC), Color.blue(bC))
                                      : Color.argb(80, Color.red(bC), Color.green(bC), Color.blue(bC)));
                if (pctB != null) canvas.drawText(Math.round(pctB) + "%", trackRight - dp(2), pctY, paint);

                // Row divider — very subtle on dark
                if (i < rowMetrics.length - 1) {
                    paint.setShader(null);
                    paint.setColor(Color.argb(25, 200, 215, 240));
                    canvas.drawLine(trackLeft + dp(8), rowTop + dp(49), trackRight - dp(8), rowTop + dp(49), paint);
                }
            }
        }
    }

    // ── v29: Shimmer skeleton loading view ────────────────────────────────────────────────────────

    class SkeletonLoadingView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private float shimmerPhase = 0f;
        private ValueAnimator shimmerAnim;

        SkeletonLoadingView(Context context) { super(context); }

        @Override
        protected void onAttachedToWindow() {
            super.onAttachedToWindow();
            shimmerAnim = ValueAnimator.ofFloat(0f, 1f);
            shimmerAnim.setDuration(1300);
            shimmerAnim.setRepeatCount(ValueAnimator.INFINITE);
            shimmerAnim.setInterpolator(new LinearInterpolator());
            shimmerAnim.addUpdateListener(a -> {
                shimmerPhase = (float) a.getAnimatedValue();
                invalidate();
            });
            shimmerAnim.start();
        }

        @Override
        protected void onDetachedFromWindow() {
            super.onDetachedFromWindow();
            if (shimmerAnim != null) { shimmerAnim.cancel(); shimmerAnim = null; }
        }

        @Override
        protected void onMeasure(int widthSpec, int heightSpec) {
            setMeasuredDimension(MeasureSpec.getSize(widthSpec), dp(560));
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth();
            if (w <= 0) return;

            // Shimmer band sweeps left-to-right, repeating
            float bandW = w * 0.55f;
            float bandStart = -bandW + (w + bandW) * shimmerPhase;
            LinearGradient shimmer = new LinearGradient(
                bandStart, 0, bandStart + bandW, 0,
                new int[] {
                    Color.argb(0,   255, 255, 255),
                    Color.argb(130, 255, 255, 255),
                    Color.argb(0,   255, 255, 255)
                },
                new float[] { 0f, 0.5f, 1f },
                Shader.TileMode.CLAMP
            );

            float px  = dp(4);   // horizontal padding matching form card
            float iy  = dp(8);   // current y cursor

            // ── Header card placeholder ──────────────────────────────────────────
            float cardBot = iy + dp(198);
            skelCard(canvas, px, iy, w - px, cardBot, dp(20), shimmer);

            float ax = px + dp(14);  // avatar / content left edge
            float tx = px + dp(84);  // text column x

            // Avatar circle
            skelItem(canvas, ax, iy + dp(14), ax + dp(60), iy + dp(74), dp(30), shimmer);

            // Name bar
            skelItem(canvas, tx, iy + dp(18), tx + dp(155), iy + dp(32), dp(7), shimmer);
            // Meta bar
            skelItem(canvas, tx, iy + dp(38), tx + dp(105), iy + dp(48), dp(5), shimmer);
            // Stat pills row
            skelItem(canvas, tx,         iy + dp(55), tx + dp(68),  iy + dp(74), dp(11), shimmer);
            skelItem(canvas, tx + dp(76), iy + dp(55), tx + dp(144), iy + dp(74), dp(11), shimmer);

            // Accent bar (like the gradient stripe on baseball card)
            skelItem(canvas, ax, iy + dp(90), w - px - dp(14), iy + dp(95), dp(4), shimmer);

            // Card table section header
            skelItem(canvas, ax, iy + dp(103), ax + dp(115), iy + dp(113), dp(5), shimmer);

            // Three table rows
            float rh = dp(22), rg = dp(5);
            for (int i = 0; i < 3; i++) {
                float ry = iy + dp(120) + (rh + rg) * i;
                skelItem(canvas, ax, ry, w - px - dp(14), ry + rh, dp(10), shimmer);
            }

            iy = cardBot + dp(10);

            // ── 4 metric row placeholders ────────────────────────────────────────
            for (int r = 0; r < 4; r++) {
                float rt  = iy;
                float rb  = rt + dp(84);
                float il  = px + dp(10);
                float ir  = w - px - dp(10);
                float mid = rt;

                skelCard(canvas, px, rt, w - px, rb, dp(16), shimmer);

                // Metric label
                skelItem(canvas, il, mid + dp(10), il + dp(115), mid + dp(23), dp(6), shimmer);
                // Percentile badge (top right)
                skelItem(canvas, ir - dp(54), mid + dp(8), ir, mid + dp(26), dp(9), shimmer);
                // Rank text
                skelItem(canvas, il, mid + dp(30), il + dp(165), mid + dp(40), dp(5), shimmer);
                // Percentile track bar
                skelItem(canvas, il, mid + dp(46), ir, mid + dp(58), dp(9), shimmer);
                // Three value columns
                float cw = (ir - il - dp(8)) / 3f;
                for (int c = 0; c < 3; c++) {
                    float cx = il + c * (cw + dp(4));
                    skelItem(canvas, cx, mid + dp(63), cx + cw, mid + dp(80), dp(8), shimmer);
                }

                iy = rb + dp(8);
            }
        }

        /** Full-card background (slightly darker base) */
        private void skelCard(Canvas canvas, float l, float t, float r, float b, float radius, LinearGradient shimmer) {
            paint.setShader(null);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.rgb(232, 238, 249));
            canvas.drawRoundRect(new RectF(l, t, r, b), radius, radius, paint);
            paint.setShader(shimmer);
            canvas.drawRoundRect(new RectF(l, t, r, b), radius, radius, paint);
            paint.setShader(null);
        }

        /** Inner element (slightly lighter) */
        private void skelItem(Canvas canvas, float l, float t, float r, float b, float radius, LinearGradient shimmer) {
            paint.setShader(null);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.rgb(214, 222, 237));
            canvas.drawRoundRect(new RectF(l, t, r, b), radius, radius, paint);
            paint.setShader(shimmer);
            canvas.drawRoundRect(new RectF(l, t, r, b), radius, radius, paint);
            paint.setShader(null);
        }
    }

    class PlayerSuggestionAdapter extends BaseAdapter {
        final ArrayList<Player> data;
        PlayerSuggestionAdapter(ArrayList<Player> data) { this.data = data; }
        @Override public int getCount() { return data.size(); }
        @Override public Object getItem(int position) { return data.get(position); }
        @Override public long getItemId(int position) { return data.get(position).id; }
        @Override public View getView(int position, View convertView, android.view.ViewGroup parent) {
            Player p = data.get(position);
            LinearLayout row;
            if (convertView instanceof LinearLayout) row = (LinearLayout) convertView;
            else {
                row = new LinearLayout(MainActivity.this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(dp(9), dp(7), dp(9), dp(7));
            }
            row.removeAllViews();
            ImageView img = new ImageView(MainActivity.this);
            img.setScaleType(ImageView.ScaleType.FIT_CENTER);
            img.setBackground(roundedStroke(Color.rgb(235, 241, 248), LINE, 16, 1));
            LinearLayout.LayoutParams imgLp = new LinearLayout.LayoutParams(dp(36), dp(36));
            imgLp.setMargins(0, 0, dp(9), 0);
            row.addView(img, imgLp);
            loadPlayerImage(p.id, img);
            LinearLayout col = new LinearLayout(MainActivity.this);
            col.setOrientation(LinearLayout.VERTICAL);
            col.addView(text(p.fullName, 14, INK, true));
            col.addView(text(p.teamAbbr + " · " + p.position + (isPitcher(p) ? " · Pitcher" : " · Hitter"), 11, MUTED, false));
            row.addView(col, new LinearLayout.LayoutParams(0, -2, 1));
            TextView chip = text(isPitcher(p) ? "P" : "BAT", 10, isPitcher(p) ? NAVY : TEAL_DARK, true);
            chip.setGravity(Gravity.CENTER);
            chip.setPadding(dp(7), dp(3), dp(7), dp(3));
            chip.setBackground(roundedStroke(Color.WHITE, Color.rgb(218, 227, 239), 12, 1));
            row.addView(chip);
            return row;
        }
    }

    // UI helpers -------------------------------------------------------------------------------

    private boolean isBusy() {
        // v29: skeleton also counts as busy (blocks double-loads)
        return skeletonView != null || (loading != null && loading.getVisibility() == View.VISIBLE);
    }

    /** v29: Show shimmer skeleton in results area while profile data loads. */
    private void showProfileSkeleton() {
        if (headerBox != null) headerBox.removeAllViews();
        if (metricBox != null) metricBox.removeAllViews();
        if (skeletonView == null) {
            skeletonView = new SkeletonLoadingView(this);
            resultsBox.addView(skeletonView, 0, new LinearLayout.LayoutParams(-1, -2));
        }
        resultsBox.setVisibility(View.VISIBLE);
    }

    /** v29: Remove shimmer skeleton when real content is ready. */
    private void hideProfileSkeleton() {
        if (skeletonView != null) {
            resultsBox.removeView(skeletonView);
            skeletonView = null;
        }
    }

    private void setBusy(boolean busy, String message) {
        loading.setVisibility(busy ? View.VISIBLE : View.GONE);
        compareButton.setEnabled(!busy);
        standingsButton.setEnabled(!busy);
        if (singleViewButton != null) singleViewButton.setEnabled(!busy);
        if (headToHeadButton != null) headToHeadButton.setEnabled(!busy);
        if (message != null) statusView.setText(message);
    }
    private void showError(String message) {
        boolean hasMsg = message != null && !message.isEmpty();
        errorView.setText(hasMsg ? message : "");
        errorView.setVisibility(hasMsg ? View.VISIBLE : View.GONE);
        if (retryButton != null) retryButton.setVisibility(hasMsg ? View.VISIBLE : View.GONE);
    }
    private void hideKeyboard() {
        try {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(searchInput.getWindowToken(), 0);
        } catch (Exception ignored) {}
    }
    private TextView text(String value, int sp, int color, boolean bold) {
        TextView tv = new TextView(this);
        tv.setText(value);
        tv.setTextSize(sp);
        tv.setTextColor(color);
        tv.setTypeface(bold ? tfBold : tfRegular);  // v29: explicit weight ladder
        return tv;
    }
    private LinearLayout verticalCard(int radius, int[] gradientColors) {
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.VERTICAL);
        v.setBackground(gradientColors == null ? rounded(CARD, radius) : roundedGradient(gradientColors, radius));
        v.setElevation(dp(2));
        return v;
    }
    private LinearLayout.LayoutParams matchWrap() { return new LinearLayout.LayoutParams(-1, -2); }
    private LinearLayout.LayoutParams weightLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
        lp.setMargins(dp(3), dp(3), dp(3), dp(3));
        return lp;
    }
    private GradientDrawable rounded(int color, int radius) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(color);
        gd.setCornerRadius(dp(radius));
        return gd;
    }
    private GradientDrawable roundedStroke(int color, int stroke, int radius, int strokeDp) {
        GradientDrawable gd = rounded(color, radius);
        gd.setStroke(dp(strokeDp), stroke);
        return gd;
    }
    private GradientDrawable roundedGradient(int[] colors, int radius) {
        GradientDrawable gd = new GradientDrawable(GradientDrawable.Orientation.TL_BR, colors);
        gd.setCornerRadius(dp(radius));
        return gd;
    }
    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }
    private float dp(float v) { return v * getResources().getDisplayMetrics().density; }

    // ── Ripple helpers ──────────────────────────────────────────────────────────────────────────

    /** Returns a ripple drawable suitable for use as a view foreground. */
    private RippleDrawable ripple(boolean darkBackground) {
        int rippleColor = darkBackground
                ? Color.argb(56, 255, 255, 255)   // white ripple on dark bg
                : Color.argb(38, 10, 23, 55);      // navy ripple on light bg
        return new RippleDrawable(ColorStateList.valueOf(rippleColor), null, null);
    }

    // ── Today's games badge ─────────────────────────────────────────────────────────────────────

    private void fetchTodayGames() {
        io.execute(() -> {
            try {
                String today = new SimpleDateFormat("MM/dd/yyyy", Locale.US).format(new Date());
                String url = "https://statsapi.mlb.com/api/v1/schedule?sportId=1&date=" + today;
                String text = httpGet(url);
                JSONObject root = new JSONObject(text);
                JSONArray dates = root.optJSONArray("dates");
                int total = 0;
                if (dates != null && dates.length() > 0) {
                    JSONObject dateObj = dates.getJSONObject(0);
                    total = dateObj.optInt("totalGames", 0);
                }
                int gameCount = total;
                main.post(() -> {
                    if (liveBadge == null) return;
                    if (gameCount > 0) {
                        liveBadge.setText(gameCount + " games today");
                        liveBadge.setBackground(roundedStroke(Color.argb(60, 13, 178, 163), Color.argb(140, 13, 178, 163), 14, 1));
                    } else {
                        liveBadge.setText("Off day");
                        liveBadge.setBackground(roundedStroke(Color.argb(40, 255, 255, 255), Color.argb(92, 255, 255, 255), 14, 1));
                    }
                });
            } catch (Exception ignored) {}
        });
    }

    // ── Recent players ───────────────────────────────────────────────────────────────────────────

    private static final int MAX_RECENTS = 5;
    private static final String PREFS_RECENTS = "statcast_recents_v28";

    private void saveToRecents(Player p) {
        if (p == null) return;
        SharedPreferences prefs = getSharedPreferences(PREFS_RECENTS, MODE_PRIVATE);
        // Load existing as ordered list
        ArrayList<String> ids = new ArrayList<>();
        ArrayList<String> names = new ArrayList<>();
        for (int i = 0; i < MAX_RECENTS; i++) {
            String id = prefs.getString("rid_" + i, null);
            String name = prefs.getString("rname_" + i, null);
            if (id != null && !String.valueOf(p.id).equals(id)) { ids.add(id); names.add(name); }
        }
        ids.add(0, String.valueOf(p.id));
        names.add(0, p.fullName);
        SharedPreferences.Editor ed = prefs.edit();
        for (int i = 0; i < Math.min(MAX_RECENTS, ids.size()); i++) {
            ed.putString("rid_" + i, ids.get(i));
            ed.putString("rname_" + i, names.get(i));
        }
        ed.apply();
    }

    private void rebuildRecentsBox() {
        if (recentsBox == null || allPlayers.isEmpty()) return;
        SharedPreferences prefs = getSharedPreferences(PREFS_RECENTS, MODE_PRIVATE);
        ArrayList<Player> recents = new ArrayList<>();
        for (int i = 0; i < MAX_RECENTS; i++) {
            String idStr = prefs.getString("rid_" + i, null);
            if (idStr == null) break;
            try {
                int id = Integer.parseInt(idStr);
                Player p = playerById(id);
                if (p != null) recents.add(p);
            } catch (Exception ignored) {}
        }
        recentsBox.removeAllViews();
        if (recents.isEmpty()) { recentsBox.setVisibility(View.GONE); return; }
        recentsBox.setVisibility(View.VISIBLE);
        recentsBox.setOrientation(LinearLayout.VERTICAL);

        TextView recentLabel = text("Recent", 10, MUTED, true);
        recentLabel.setLetterSpacing(0.10f);
        recentLabel.setPadding(dp(2), 0, 0, dp(4));
        recentsBox.addView(recentLabel);

        LinearLayout chipRow = new LinearLayout(this);
        chipRow.setOrientation(LinearLayout.HORIZONTAL);
        for (Player p : recents) {
            Button chip = new Button(this);
            chip.setText(p.fullName.split(" ").length > 1 ? p.fullName.split(" ")[p.fullName.split(" ").length - 1] : p.fullName);
            chip.setAllCaps(false);
            chip.setTextSize(12);
            chip.setTypeface(Typeface.DEFAULT_BOLD);
            chip.setTextColor(NAVY);
            chip.setMinHeight(0); chip.setMinWidth(0);
            chip.setPadding(dp(10), dp(6), dp(10), dp(6));
            chip.setBackground(roundedStroke(isDark ? Color.rgb(26, 38, 62) : Color.WHITE, isDark ? TEAL_DARK : LINE, 16, 1));
            chip.setForeground(ripple(isDark));
            chip.setContentDescription("Recent: " + p.fullName);
            LinearLayout.LayoutParams chipLp = new LinearLayout.LayoutParams(-2, -2);
            chipLp.setMargins(0, 0, dp(7), 0);
            chip.setOnClickListener(v -> {
                selectedPlayer = p;
                searchInput.setText("");
                searchInput.clearFocus();
                suggestionsList.setVisibility(View.GONE);
                applySmartDefaultForSelection(p);
                renderSelectionPreview();
                hideKeyboard();
                refreshAfterPrimarySelection();
            });
            chipRow.addView(chip, chipLp);
        }
        recentsBox.addView(chipRow, matchWrap());
    }

    // ── Metric glossary ──────────────────────────────────────────────────────────────────────────

    private void showMetricGlossary(Metric m) {
        String desc = metricDescription(m.key);
        if (desc.isEmpty()) return;
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(18), dp(16), dp(18), dp(14));
        panel.setBackground(roundedGradient(new int[] { Color.WHITE, Color.rgb(248, 251, 254) }, 22));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text(m.label, 20, INK, true);
        top.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        TextView type = text(m.group == null ? "Stat" : m.group, 10, TEAL_DARK, true);
        type.setGravity(Gravity.CENTER);
        type.setPadding(dp(9), dp(4), dp(9), dp(4));
        type.setBackground(roundedStroke(softColor(TEAL_DARK, 0.92f), softColor(TEAL_DARK, 0.50f), 13, 1));
        top.addView(type);
        panel.addView(top, matchWrap());

        TextView body = text(desc, 14, Color.rgb(55, 65, 82), false);
        body.setLineSpacing(dp(3), 1.0f);
        body.setPadding(0, dp(10), 0, dp(14));
        panel.addView(body, matchWrap());

        TextView close = text("Done", 14, Color.WHITE, true);
        close.setGravity(Gravity.CENTER);
        close.setPadding(dp(12), dp(9), dp(12), dp(9));
        close.setBackground(roundedGradient(new int[] { TEAL, TEAL_DARK }, 16));
        panel.addView(close, matchWrap());

        final AlertDialog dialog = new AlertDialog.Builder(this).create();
        dialog.setView(panel);
        close.setOnClickListener(v -> dialog.dismiss());
        dialog.show();
    }

    private String metricDescription(String key) {
        switch (key) {
            case "avg":    return "Batting Average — hits divided by at-bats. The classic measure of how often a batter gets a hit.";
            case "obp":    return "On-Base Percentage — how often a batter reaches base via hit, walk, or hit-by-pitch. Better than AVG because walks matter.";
            case "slg":    return "Slugging Percentage — total bases divided by at-bats. Rewards extra-base hits more than AVG.";
            case "ops":    return "On-Base Plus Slugging — OBP + SLG. A quick all-in-one offensive metric. League average is around .720.";
            case "hr":     return "Home Runs — total home runs hit in the season.";
            case "rbi":    return "Runs Batted In — how many runs a batter drove in. Affected by teammates and lineup spot.";
            case "r":      return "Runs Scored — how many times the batter crossed home plate.";
            case "sb":     return "Stolen Bases — successful steals of a base.";
            case "wOBA":   return "Weighted On-Base Average — like OBP but weights each way of reaching base by its run value. League average is around .320. One of the best offensive rate stats.";
            case "xwOBA":  return "Expected wOBA — what wOBA would be based purely on exit velocity and launch angle, ignoring luck, defense, and ballpark. Predicts future performance better than actual wOBA.";
            case "luck":   return "Luck (wOBA − xwOBA) — the gap between what actually happened and what the contact quality predicted. Positive means outperforming the ball-tracking; negative means underperforming it.";
            case "xBA":    return "Expected Batting Average — what AVG should be based on exit velocity and launch angle. Filters out luck and defense.";
            case "xSLG":   return "Expected Slugging — what SLG should be based on contact quality. Great for spotting hitters due for a power surge or correction.";
            case "avgEV":  return "Average Exit Velocity — average speed off the bat in mph across all balls in play. Higher is harder contact. Elite is 92+ mph.";
            case "avgLA":  return "Average Launch Angle — average vertical angle off the bat in degrees. 10–30° is the ideal 'sweet spot' range for line drives and home runs.";
            case "hardHitPct": return "Hard-Hit % — share of batted balls hit at 95+ mph. A proxy for raw power and contact quality. League average ~38%.";
            case "barrelPct":  return "Barrel % — share of batted balls that were both hard (95+ mph) AND in the ideal launch angle range. Barrels produce a .900+ slugging rate. Elite is 10%+.";
            case "sweetSpotPct": return "Sweet-Spot % — balls hit at 8–32° launch angle. That window produces the most hits and extra bases. Roughly corresponds to line drives.";
            case "kPct":   return "Strikeout % — share of plate appearances ending in a strikeout. Lower is better for hitters. League average ~22%.";
            case "bbPct":  return "Walk % — share of plate appearances ending in a walk. Higher is better. League average ~8.5%.";
            case "era":    return "Earned Run Average — earned runs allowed per 9 innings. The classic pitching summary stat. League average ~4.20.";
            case "whip":   return "Walks + Hits per Inning Pitched — measures baserunner traffic allowed. Lower is better. League average ~1.30.";
            case "k9":     return "Strikeouts per 9 innings — how often a pitcher misses bats. Elite starters reach 10+.";
            case "bb9":    return "Walks per 9 innings — control and command. Lower is better.";
            case "kbb":    return "K/BB ratio — strikeouts per walk. Combines stuff and command. Anything above 3.0 is excellent.";
            case "pitchK": return "Strikeouts — total batters struck out in the season.";
            case "pitchBB": return "Walks issued — total batters walked in the season.";
            case "saves":  return "Saves — a reliever earns a save by finishing a close win under specific conditions. Primarily tracks closers.";
            case "ip":     return "Innings Pitched — total innings a pitcher worked. Reflects workload and durability.";
            default:       return "";
        }
    }

    // ── Sparkline (season trend) ─────────────────────────────────────────────────────────────────

    private void renderSparklineRow(LinearLayout parent, LinkedHashMap<Integer, Stats> seasons, Metric m, TeamPalette palette) {
        ArrayList<Integer> years = new ArrayList<>(seasons.keySet());
        if (years.size() > 1 && years.get(0) > years.get(years.size() - 1)) {
            Collections.reverse(years); // sparklines read oldest → newest, left to right
        }
        ArrayList<TrendPoint> pts = new ArrayList<>();
        for (int y : years) {
            Double v = seasons.get(y) == null ? null : seasons.get(y).get(m.key);
            pts.add(new TrendPoint(String.valueOf(y), v));
        }
        renderTrendPointRow(parent, "Trend · seasons", pts, m, palette, "years");
    }

    class SparklineView extends View {
        final ArrayList<Double> values;
        final ArrayList<String> labels;
        final Metric metric;
        final int lineColor;
        final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

        SparklineView(Context ctx, ArrayList<Double> values, ArrayList<String> labels, Metric metric, int lineColor) {
            super(ctx);
            this.values = values;
            this.labels = labels;
            this.metric = metric;
            this.lineColor = lineColor;
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            int n = values.size();
            if (n < 2) return;
            float w = getWidth(), h = getHeight();
            float padL = dp(8), padR = dp(54), padT = dp(12), padB = dp(20);

            double min = Double.MAX_VALUE, max = -Double.MAX_VALUE;
            for (Double v : values) {
                if (v != null && !Double.isNaN(v)) {
                    min = Math.min(min, v);
                    max = Math.max(max, v);
                }
            }
            if (min == Double.MAX_VALUE) return;
            if (max == min) { max = min + Math.max(Math.abs(min) * 0.02, 0.001); min = min - Math.max(Math.abs(min) * 0.02, 0.001); }
            double span = max - min;
            min -= span * 0.08;
            max += span * 0.08;
            double mid = (min + max) / 2.0;

            float plotW = w - padL - padR;
            float plotH = h - padT - padB;

            paint.setShader(null);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dp(1));
            paint.setColor(Color.rgb(232, 237, 246));
            for (int i = 0; i < 3; i++) {
                float y = padT + plotH * i / 2f;
                canvas.drawLine(padL, y, padL + plotW, y, paint);
            }

            paint.setStyle(Paint.Style.FILL);
            paint.setTextSize(dp(8));
            paint.setTypeface(tfBold);                 // v29: weight ladder
            paint.setFontFeatureSettings("'tnum' 1");  // v29: tabular figures for axis values
            paint.setColor(Color.rgb(116, 128, 146));
            paint.setTextAlign(Paint.Align.LEFT);
            canvas.drawText(format(max, metric), padL + plotW + dp(5), padT + dp(3), paint);
            canvas.drawText(format(mid, metric), padL + plotW + dp(5), padT + plotH / 2f + dp(3), paint);
            canvas.drawText(format(min, metric), padL + plotW + dp(5), padT + plotH + dp(3), paint);

            ArrayList<float[]> pts = new ArrayList<>();
            for (int i = 0; i < n; i++) {
                Double v = values.get(i);
                if (v == null || Double.isNaN(v)) continue;
                float x = padL + plotW * i / (n - 1);
                float y = padT + plotH - (float) ((v - min) / (max - min)) * plotH;
                pts.add(new float[]{x, y});
            }
            if (pts.size() < 2) return;

            Path area = new Path();
            area.moveTo(pts.get(0)[0], padT + plotH);
            for (float[] p : pts) area.lineTo(p[0], p[1]);
            area.lineTo(pts.get(pts.size() - 1)[0], padT + plotH);
            area.close();
            paint.setStyle(Paint.Style.FILL);
            paint.setShader(new LinearGradient(0, padT, 0, padT + plotH, Color.argb(52, Color.red(lineColor), Color.green(lineColor), Color.blue(lineColor)), Color.TRANSPARENT, Shader.TileMode.CLAMP));
            canvas.drawPath(area, paint);
            paint.setShader(null);

            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dp(2));
            paint.setColor(lineColor);
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStrokeJoin(Paint.Join.ROUND);
            Path line = new Path();
            line.moveTo(pts.get(0)[0], pts.get(0)[1]);
            for (int i = 1; i < pts.size(); i++) line.lineTo(pts.get(i)[0], pts.get(i)[1]);
            canvas.drawPath(line, paint);

            // No point markers: the line represents a continuous rolling/cumulative trend.

            paint.setTextSize(dp(9));
            paint.setTypeface(tfBold);  // v29
            paint.setColor(Color.rgb(112, 123, 142));
            paint.setTextAlign(Paint.Align.LEFT);
            if (labels != null && !labels.isEmpty()) canvas.drawText(safe(labels.get(0)), padL, h - dp(3), paint);
            paint.setTextAlign(Paint.Align.RIGHT);
            if (labels != null && !labels.isEmpty()) canvas.drawText(safe(labels.get(labels.size() - 1)), padL + plotW, h - dp(3), paint);
        }
    }

    // ── Share as image ───────────────────────────────────────────────────────────────────────────

    private void shareComparisonAsImage() {
        if (headerBox == null || headerBox.getChildCount() == 0) {
            Toast.makeText(this, "Run a profile first", Toast.LENGTH_SHORT).show();
            return;
        }
        // Render the profile card to a bitmap
        View card = headerBox.getChildAt(0);
        if (card.getWidth() <= 0) { copyCurrentTable(); return; }
        card.setDrawingCacheEnabled(true);
        card.buildDrawingCache(true);
        Bitmap src = card.getDrawingCache();
        if (src == null) { copyCurrentTable(); return; }
        Bitmap bmp = Bitmap.createBitmap(src);
        card.setDrawingCacheEnabled(false);

        try {
            // Write to app cache dir and share via file:// URI (API 24+ allows this for our own files)
            File shareDir = new File(getCacheDir(), "share");
            shareDir.mkdirs();
            File f = new File(shareDir, "statcast_card.png");
            FileOutputStream fos = new FileOutputStream(f);
            bmp.compress(Bitmap.CompressFormat.PNG, 100, fos);
            fos.close();

            // For sharing we use MediaStore to get a content URI without needing FileProvider
            String inserted = android.provider.MediaStore.Images.Media.insertImage(
                    getContentResolver(), bmp,
                    "Statcast_" + (lastComparison != null ? lastComparison.name.replaceAll("[^A-Za-z0-9]", "_") : "card"),
                    "Statcast Compare card");
            Uri shareUri = inserted != null ? Uri.parse(inserted) : null;

            if (shareUri != null) {
                String caption = lastHeadToHead != null
                        ? lastHeadToHead.nameA + " vs " + lastHeadToHead.nameB + " · " + lastHeadToHead.season + " Statcast"
                        : (lastComparison != null ? lastComparison.name + " · " + lastComparison.season + " Statcast" : "Statcast Compare");
                Intent share = new Intent(Intent.ACTION_SEND);
                share.setType("image/*");
                share.putExtra(Intent.EXTRA_STREAM, shareUri);
                share.putExtra(Intent.EXTRA_TEXT, caption);
                share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(Intent.createChooser(share, "Share stat card"));
            } else {
                copyCurrentTable();
                Toast.makeText(this, "Copied as text instead", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            copyCurrentTable();
            Toast.makeText(this, "Copied comparison as text", Toast.LENGTH_SHORT).show();
        }
    }

    // ─────────────────────────────────────────────────────────────────────────────────────────────

    static class TeamPalette {
        final int primary; final int secondary;
        TeamPalette(int primary, int secondary) { this.primary = primary; this.secondary = secondary; }
    }

    static class LoadedData {
        final ArrayList<Team> teams; final ArrayList<Player> players;
        LoadedData(ArrayList<Team> teams, ArrayList<Player> players) { this.teams = teams; this.players = players; }
    }
    static class Team {
        final int id; final String name; final String abbr;
        Team(int id, String name, String abbr) { this.id = id; this.name = name; this.abbr = abbr == null || abbr.isEmpty() ? name : abbr; }
        String key() { return abbr.toUpperCase(Locale.US); }
    }
    static class Player {
        final int id; final String fullName; final String teamName; final String teamAbbr; final String position;
        final String searchKey; // pre-lowercased for fast filtering
        Player(int id, String fullName, String teamName, String teamAbbr, String position) {
            this.id = id; this.fullName = fullName; this.teamName = teamName; this.teamAbbr = teamAbbr; this.position = position;
            this.searchKey = (fullName + " " + teamAbbr + " " + position).toLowerCase(Locale.US);
        }
    }
    static class LeaderboardEntry {
        final int playerId; final String name; final String teamName; final String teamAbbr; final Stats stats;
        LeaderboardEntry(int playerId, String name, String teamName, String teamAbbr, Stats stats) { this.playerId = playerId; this.name = name; this.teamName = teamName; this.teamAbbr = teamAbbr; this.stats = stats; }
        String teamAbbrOrName() { return teamAbbr == null || teamAbbr.isEmpty() ? teamName : teamAbbr; }
    }
    static class TeamStanding {
        final Team team; final Stats stats;
        TeamStanding(Team team, Stats stats) { this.team = team; this.stats = stats; }
    }
    static class Stats {
        int pa = 0; int bbe = 0; double ip = 0; final Map<String, Double> vals = new HashMap<>();
        void put(String key, Double value) { vals.put(key, value); }
        void mergeFrom(Stats other) { if (other == null) return; if (other.pa > 0) pa = Math.max(pa, other.pa); if (other.bbe > 0) bbe = Math.max(bbe, other.bbe); if (other.ip > 0) ip = Math.max(ip, other.ip); vals.putAll(other.vals); }
        Double get(String key) {
            if ("luck".equals(key)) {
                Double woba = vals.get("wOBA");
                Double xwoba = vals.get("xwOBA");
                return woba == null || xwoba == null ? null : woba - xwoba;
            }
            return vals.get(key);
        }
        boolean anyValue() { for (Double d : vals.values()) if (d != null && !Double.isNaN(d)) return true; return false; }
    }
    static class Metric {
        final String key, label, unit, type, group, side; final int decimals; final Boolean higherGood;
        Metric(String key, String label, String unit, int decimals, Boolean higherGood, String type, String group) {
            this(key, label, unit, decimals, higherGood, type, group, "hit");
        }
        Metric(String key, String label, String unit, int decimals, Boolean higherGood, String type, String group, String side) {
            this.key = key; this.label = label; this.unit = unit; this.decimals = decimals; this.higherGood = higherGood; this.type = type; this.group = group; this.side = side == null ? "hit" : side;
        }
        boolean isCount() { return "count".equals(type); }
    }
    static class Comparison {
        final boolean isTeam; final String name, meta; final int mlbId, season; final Stats seasonStats, careerStats, leagueStats; final Date updated; final String thirdLabel; final Player player; final Team team;
        final Map<String, Integer> rank, rankTotal; final Map<String, Double> percentile, thirdPercentile; final LinkedHashMap<Integer, Stats> recentSeasons; final Map<String, ArrayList<TrendPoint>> seasonTrends; final LinkedHashMap<String, Stats> recentWindows;
        Comparison(boolean isTeam, String name, String meta, String role, int mlbId, int season, Stats seasonStats, Stats careerStats, Stats leagueStats, Date updated, String thirdLabel, Player player, Team team) {
            this(isTeam, name, meta, role, mlbId, season, seasonStats, careerStats, leagueStats, updated, thirdLabel, player, team, new HashMap<>(), new HashMap<>(), new HashMap<>(), new HashMap<>(), new LinkedHashMap<>(), new HashMap<>(), new LinkedHashMap<>());
        }
        Comparison(boolean isTeam, String name, String meta, String role, int mlbId, int season, Stats seasonStats, Stats careerStats, Stats leagueStats, Date updated, String thirdLabel, Player player, Team team, Map<String, Integer> rank, Map<String, Integer> rankTotal, Map<String, Double> percentile, Map<String, Double> thirdPercentile) {
            this(isTeam, name, meta, role, mlbId, season, seasonStats, careerStats, leagueStats, updated, thirdLabel, player, team, rank, rankTotal, percentile, thirdPercentile, new LinkedHashMap<>(), new HashMap<>(), new LinkedHashMap<>());
        }
        Comparison(boolean isTeam, String name, String meta, String role, int mlbId, int season, Stats seasonStats, Stats careerStats, Stats leagueStats, Date updated, String thirdLabel, Player player, Team team, Map<String, Integer> rank, Map<String, Integer> rankTotal, Map<String, Double> percentile, Map<String, Double> thirdPercentile, LinkedHashMap<Integer, Stats> recentSeasons) {
            this(isTeam, name, meta, role, mlbId, season, seasonStats, careerStats, leagueStats, updated, thirdLabel, player, team, rank, rankTotal, percentile, thirdPercentile, recentSeasons, new HashMap<>(), new LinkedHashMap<>());
        }
        Comparison(boolean isTeam, String name, String meta, String role, int mlbId, int season, Stats seasonStats, Stats careerStats, Stats leagueStats, Date updated, String thirdLabel, Player player, Team team, Map<String, Integer> rank, Map<String, Integer> rankTotal, Map<String, Double> percentile, Map<String, Double> thirdPercentile, LinkedHashMap<Integer, Stats> recentSeasons, Map<String, ArrayList<TrendPoint>> seasonTrends, LinkedHashMap<String, Stats> recentWindows) {
            this.isTeam = isTeam; this.name = name; this.meta = meta + (role == null || role.isEmpty() ? "" : " · " + role); this.mlbId = mlbId; this.season = season; this.seasonStats = seasonStats; this.careerStats = careerStats; this.leagueStats = leagueStats; this.updated = updated; this.thirdLabel = thirdLabel; this.player = player; this.team = team; this.rank = rank == null ? new HashMap<>() : rank; this.rankTotal = rankTotal == null ? new HashMap<>() : rankTotal; this.percentile = percentile == null ? new HashMap<>() : percentile; this.thirdPercentile = thirdPercentile == null ? new HashMap<>() : thirdPercentile; this.recentSeasons = recentSeasons == null ? new LinkedHashMap<>() : recentSeasons; this.seasonTrends = seasonTrends == null ? new HashMap<>() : seasonTrends; this.recentWindows = recentWindows == null ? new LinkedHashMap<>() : recentWindows;
        }
        String thirdLabelShort() { return isTeam ? "2015+" : "Career"; }
    }
    static class HeadToHeadComparison {
        final boolean isTeam; final String nameA, nameB, metaA, metaB; final int idA, idB, season; final Stats statsA, statsB, leagueStats; final Player playerA, playerB; final Team teamA, teamB; final Map<String, Integer> rankA, rankB, rankTotalA, rankTotalB; final Map<String, Double> percentileA, percentileB;
        HeadToHeadComparison(boolean isTeam, String nameA, String nameB, String metaA, String metaB, int idA, int idB, int season, Stats statsA, Stats statsB, Stats leagueStats, Player playerA, Player playerB, Team teamA, Team teamB, Map<String, Integer> rankA, Map<String, Integer> rankB) {
            this(isTeam, nameA, nameB, metaA, metaB, idA, idB, season, statsA, statsB, leagueStats, playerA, playerB, teamA, teamB, rankA, rankB, new HashMap<>(), new HashMap<>(), new HashMap<>(), new HashMap<>());
        }
        HeadToHeadComparison(boolean isTeam, String nameA, String nameB, String metaA, String metaB, int idA, int idB, int season, Stats statsA, Stats statsB, Stats leagueStats, Player playerA, Player playerB, Team teamA, Team teamB, Map<String, Integer> rankA, Map<String, Integer> rankB, Map<String, Integer> rankTotalA, Map<String, Integer> rankTotalB, Map<String, Double> percentileA, Map<String, Double> percentileB) {
            this.isTeam = isTeam; this.nameA = nameA; this.nameB = nameB; this.metaA = metaA; this.metaB = metaB; this.idA = idA; this.idB = idB; this.season = season; this.statsA = statsA; this.statsB = statsB; this.leagueStats = leagueStats; this.playerA = playerA; this.playerB = playerB; this.teamA = teamA; this.teamB = teamB; this.rankA = rankA == null ? new HashMap<>() : rankA; this.rankB = rankB == null ? new HashMap<>() : rankB; this.rankTotalA = rankTotalA == null ? new HashMap<>() : rankTotalA; this.rankTotalB = rankTotalB == null ? new HashMap<>() : rankTotalB; this.percentileA = percentileA == null ? new HashMap<>() : percentileA; this.percentileB = percentileB == null ? new HashMap<>() : percentileB;
        }
    }
    static class AllRankRow {
        final Metric metric; final int rank, total, playerId; final String subjectName, leaderName; final Double value, leaderValue; final Team team;
        AllRankRow(Metric metric, int rank, int total, String subjectName, Double value, String leaderName, Double leaderValue, int playerId, Team team) {
            this.metric = metric; this.rank = rank; this.total = total; this.subjectName = subjectName; this.value = value; this.leaderName = leaderName; this.leaderValue = leaderValue; this.playerId = playerId; this.team = team;
        }
    }
    static class TrendPoint {
        final String label; final Double value;
        TrendPoint(String label, Double value) { this.label = label; this.value = value; }
    }
    static class GameLogEntry {
        final Date date; final String label; final Stats stats;
        GameLogEntry(Date date, String label, Stats stats) { this.date = date; this.label = label; this.stats = stats; }
    }
    static class WeightedStatsBuilder {
        final Metric[] metrics; final boolean sumCounts; int pa = 0; int bbe = 0; double ip = 0; final Map<String, Double> sums = new HashMap<>(); final Map<String, Double> weights = new HashMap<>();
        static final String[] RAW_KEYS = new String[] { "__ab", "__h", "__tb", "__bb", "__hbp", "__sf", "__so", "__pip", "__bf", "__pk", "__pbb", "__ph", "__er" };
        WeightedStatsBuilder(Metric[] metrics) { this(metrics, false); }
        WeightedStatsBuilder(Metric[] metrics, boolean sumCounts) { this.metrics = metrics; this.sumCounts = sumCounts; }
        void add(Stats s) {
            if (s == null) return;
            pa += s.pa; bbe += s.bbe; ip += s.ip;

            // Raw totals let game-log windows produce true period stats:
            // AVG = hits in window / AB in window, OPS = OBP+SLG for the window,
            // ERA/WHIP/K9/etc. use only the innings/events inside that window.
            for (String raw : RAW_KEYS) {
                Double rawVal = s.vals.get(raw);
                if (rawVal != null && !Double.isNaN(rawVal)) sums.put(raw, sums.getOrDefault(raw, 0.0) + rawVal);
            }

            for (Metric m : metrics) {
                if (m.key.equals("luck")) continue;
                Double val = s.get(m.key);
                if (val == null || Double.isNaN(val)) continue;
                if (m.isCount()) {
                    sums.put(m.key, sums.getOrDefault(m.key, 0.0) + val);
                    weights.put(m.key, weights.getOrDefault(m.key, 0.0) + (sumCounts ? 1.0 : 1.0));
                    continue;
                }
                double w;
                if ("pitch".equals(m.side)) w = s.ip > 0 ? s.ip : (s.pa > 0 ? s.pa : s.bbe);
                else w = (m.type.equals("expected") || m.key.equals("kPct") || m.key.equals("bbPct") || m.type.equals("standard")) ? s.pa : s.bbe;
                if (w <= 0) w = s.pa > 0 ? s.pa : (s.bbe > 0 ? s.bbe : s.ip);
                if (w <= 0) continue;
                sums.put(m.key, sums.getOrDefault(m.key, 0.0) + val * w);
                weights.put(m.key, weights.getOrDefault(m.key, 0.0) + w);
            }
        }
        private double raw(String key) { return sums.getOrDefault(key, 0.0); }
        Stats build() {
            Stats s = new Stats(); s.pa = pa; s.bbe = bbe; s.ip = ip;
            for (String raw : RAW_KEYS) if (sums.containsKey(raw)) s.put(raw, sums.get(raw));

            double ab = raw("__ab"), hits = raw("__h"), tb = raw("__tb"), bb = raw("__bb"), hbp = raw("__hbp"), sf = raw("__sf"), so = raw("__so");
            double obpDen = ab + bb + hbp + sf;
            if (ab > 0) {
                s.put("avg", hits / ab);
                s.put("slg", tb / ab);
            }
            if (obpDen > 0) s.put("obp", (hits + bb + hbp) / obpDen);
            Double obp = s.get("obp"), slg = s.get("slg");
            if (obp != null && slg != null) s.put("ops", obp + slg);
            if (pa > 0) {
                s.put("kPct", so * 100.0 / pa);
                s.put("bbPct", bb * 100.0 / pa);
            }

            double pip = raw("__pip"), pk = raw("__pk"), pbb = raw("__pbb"), ph = raw("__ph"), er = raw("__er");
            if (pip > 0) {
                s.put("era", er * 9.0 / pip);
                s.put("whip", (ph + pbb) / pip);
                s.put("k9", pk * 9.0 / pip);
                s.put("bb9", pbb * 9.0 / pip);
                s.put("ip", pip);
            }
            if (pbb > 0) s.put("kbb", pk / pbb);
            else if (pk > 0) s.put("kbb", pk);

            for (Metric m : metrics) {
                // Prefer raw-derived period rates when available.
                if (s.get(m.key) != null && (m.type.equals("standard") || m.type.equals("pitching") || m.key.equals("kPct") || m.key.equals("bbPct") || m.key.equals("ops"))) continue;
                Double w = weights.get(m.key);
                if (w == null || w <= 0) {
                    if (s.get(m.key) == null) s.put(m.key, null);
                } else if (m.isCount() && sumCounts) s.put(m.key, sums.get(m.key));
                else s.put(m.key, sums.get(m.key) / w);
            }
            return s;
        }
    }
    interface BitmapCallback { void onBitmap(Bitmap bitmap); }

}
